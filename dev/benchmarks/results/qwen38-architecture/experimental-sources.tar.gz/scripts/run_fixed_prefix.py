import os,json,subprocess,time,re
from pathlib import Path
R=Path.cwd();O=R/'build/qwen38-architecture';M=R/'install/models/mlx-community/Qwen3.8-27B-4bit';records=[]
variants={'skip4':{'SPLASH_ARCH_SKIP_TARGET_FFN':'3,4,5,9'},'surrogate4':{'SPLASH_ARCH_SURROGATE_LAYERS':'3,4,5,9','SPLASH_ARCH_SURROGATE_DIRECTORY':str(O/'surrogate-model')}}
def snapshot():
 d={'utc':time.time()}
 for k,cmd in {'power':['pmset','-g','batt'],'thermal':['pmset','-g','therm'],'swap':['sysctl','vm.swapusage'],'pressure':['sysctl','kern.memorystatus_vm_pressure_level']}.items():d[k]=subprocess.run(cmd,capture_output=True,text=True).stdout
 return d
for block,(variant,settings) in enumerate(variants.items()):
 for index,arm in enumerate('ABBA'):
  name=f'{variant}-{index}-{arm}';env={k:v for k,v in os.environ.items() if not k.startswith('SPLASH_ARCH_')};selected={} if arm=='A' else settings;env.update(selected)
  before=snapshot();assert 'AC Power' in before['power']
  cmd=[str(O/'native/architecture-teacher'),str(O/'native/splash.metallib'),str(M),str(O/'heldout.u32'),str(O/f'fixed-{name}'),'--window','2176:128','--kv-format','int8','--state-format','fp32']
  started=time.time()
  with (O/f'fixed-{name}.log').open('w') as log:r=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
  assert r.returncode==0,(name,r.returncode)
  text=(O/f'fixed-{name}.log').read_text();line=re.search(r'architecture_cycles end=2176 ms=([\d.,]+)',text);assert line,name
  ms=[float(n) for n in line[1].strip(',').split(',')];assert len(ms)==16
  record={'name':name,'variant':variant,'arm':arm,'index':index,'settings':selected,'command':cmd,'before':before,'after':snapshot(),'decode_call_ms':ms,'excluded_first_cycles':2,'retained_rows_per_cycle':8,'seconds':time.time()-started,'exit_code':r.returncode}
  records.append(record);(O/'fixed-prefix-records.json').write_text(json.dumps(records,indent=2)+'\n');print(name,round(sum(ms[2:])/len(ms[2:]),4),flush=True)

import json,math,statistics
from pathlib import Path
P=Path(__file__).resolve().parent

def gm(xs):return math.exp(statistics.mean(map(math.log,xs)))
def measurements(d):return {r['domain']:r for r in d['measurements']}
def metric(r,key='latency'):
 if key=='latency':return r['full_cycle_ms_per_emitted_token']
 if key=='cycle':return r['native_delta']['decode_cycle_ms']/r['response']['metrics']['speculation']['cycles']
 if key=='tau':return r['native_delta']['decode_output_tokens']/r['response']['metrics']['speculation']['cycles']
summary={}
for family in ['screen','target-screen','surrogate-screen']:
 first='control' if family=='screen' else 'control-before';last='control-repeat' if family=='screen' else 'control-after'
 a=P/f'{family}-{first}.json';b=P/f'{family}-{last}.json'
 if not a.exists() or not b.exists():continue
 da,db=json.loads(a.read_text()),json.loads(b.read_text())
 if not da.get('after') or not db.get('after'):continue
 aa,bb=measurements(da),measurements(db);out={'qualification':'screening only; arithmetic of bracket geometric mean is descriptive and does not correct unknown drift','controls_ms_per_token':{d:[metric(aa[d]),metric(bb[d])] for d in aa},'control_latency_drift_pct':{d:100*(metric(bb[d])/metric(aa[d])-1) for d in aa},'variants':{}}
 for file in sorted(P.glob(f'{family}-*.json')):
  doc=json.loads(file.read_text())
  if not isinstance(doc,dict) or 'measurements' not in doc or len(doc['measurements'])!=4 or not doc.get('after'):continue
  name=doc['name'];ratios=[];domains={}
  for row in doc['measurements']:
   d=row['domain'];ref=math.sqrt(metric(aa[d])*metric(bb[d]));ratios.append(ref/metric(row))
   domains[d]={'ms_per_emitted_token':metric(row),'tokens_per_cycle':metric(row,'tau'),'ms_per_cycle':metric(row,'cycle'),'cycle_count':row['response']['metrics']['speculation']['cycles'],'actual_emitted_tokens':row['native_delta']['decode_output_tokens'],'bracket_tps_delta_pct':100*(ref/metric(row)-1),'same_message_as_first_control':row['message_sha256']==aa[d]['message_sha256']}
  out['variants'][name]={'bracket_tps_delta_pct':100*(gm(ratios)-1),'domains':domains,'draft_weight_bytes':doc['memory_plan']['model']['memory']['draft_weights_bytes']}
 summary[family]=out
files=list(P.glob('draft-middle-confirm-*-*-?.json'))
if len(files)==8 and all(json.loads(f.read_text()).get('complete') for f in files):
 out={'method':'two repeated fresh-process ABBA blocks, four heldout prompt domains,192 output tokens each','blocks':[],'qualified_speedup':False}
 domainvalues={};allratios=[];allcycle=[];allt=[]
 for block in range(2):
  ds=[json.loads((P/f'draft-middle-confirm-{block}-{i}-{kind}.json').read_text()) for i,kind in enumerate('ABBA')];ms=list(map(measurements,ds));ratios=[];costs=[];taus=[];domains={}
  for dom in ms[0]:
   a=[metric(ms[i][dom]) for i in [0,3]];b=[metric(ms[i][dom]) for i in [1,2]];ratio=gm(a)/gm(b);ratios.append(ratio);allratios.append(ratio);domainvalues.setdefault(dom,[]).append(ratio)
   cost=gm([metric(ms[i][dom],'cycle') for i in [0,3]])/gm([metric(ms[i][dom],'cycle') for i in [1,2]]);allcycle.append(cost)
   tau=gm([metric(ms[i][dom],'tau') for i in [1,2]])/gm([metric(ms[i][dom],'tau') for i in [0,3]]);allt.append(tau)
   domains[dom]={'tps_delta_pct':100*(ratio-1),'cycle_time_reduction_pct':100*(1-1/cost),'tau_change_pct':100*(tau-1),'baseline_ms_per_token':a,'candidate_ms_per_token':b,'baseline_cycles':[ms[i][dom]['response']['metrics']['speculation']['cycles'] for i in [0,3]],'candidate_cycles':[ms[i][dom]['response']['metrics']['speculation']['cycles'] for i in [1,2]],'all_messages_equal':len({ms[i][dom]['message_sha256'] for i in range(4)})==1,'baseline_spread_pct':100*(max(a)/min(a)-1),'candidate_spread_pct':100*(max(b)/min(b)-1)}
  out['blocks'].append({'block':block,'geometric_mean_tps_delta_pct':100*(gm(ratios)-1),'domains':domains})
 out['geometric_mean_tps_delta_pct']=100*(gm(allratios)-1);out['geometric_mean_cycle_time_reduction_pct']=100*(1-1/gm(allcycle));out['geometric_mean_tau_change_pct']=100*(gm(allt)-1);out['domain_geometric_mean_tps_delta_pct']={d:100*(gm(v)-1) for d,v in domainvalues.items()};summary['draft-middle-confirm']=out
(P/'serving-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
for family,result in summary.items():
 print(family)
 if 'variants' in result:
  for n,v in result['variants'].items():print(n,round(v['bracket_tps_delta_pct'],2))
 else:print(json.dumps(result,indent=2))

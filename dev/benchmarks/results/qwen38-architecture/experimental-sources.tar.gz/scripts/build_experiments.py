from pathlib import Path
import concurrent.futures,json,subprocess,shutil
ROOT=Path.cwd();W=Path('/private/tmp/splash-qwen38-architecture');O=ROOT/'build/qwen38-architecture';B=O/'native';B.mkdir(exist_ok=True)
base=['xcrun','-sdk','macosx','clang++','-std=c++20','-O3','-Wall','-Wextra','-Werror','-I'+str(W/'runtime'),'-I'+str(W/'dev'),'-mmacosx-version-min=26.4']
files=['runtime/model/ModelDescriptor.mm','runtime/model/DraftCheckpoint.cpp','runtime/model/GgufPreparation.cpp','runtime/model/DFlashDraft.cpp','runtime/model/QwenTarget.cpp']
def compile(source):
 dest=B/(Path(source).stem+'.o');cmd=base+(['-fobjc-arc'] if source.endswith('.mm') else [])+['-c',str(W/source),'-o',str(dest)]
 with (O/(Path(source).stem+'-build.log')).open('w') as log:subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,check=True)
 return str(dest)
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:objects=list(pool.map(compile,files))
main=base+['-fobjc-arc','-include',str(O/'BuildIdentity.hpp'),'-c',str(W/'runtime/main.mm'),'-o',str(B/'main.o')]
subprocess.run(main,check=True)
frameworks=['-framework','Foundation','-framework','Metal','-framework','IOKit','-framework','IOSurface']
subprocess.run(base+['-fobjc-arc',str(B/'main.o'),*objects,str(ROOT/'build/engine/libsplash.a'),*frameworks,'-o',str(B/'splash')],check=True)
subprocess.run(base+['-fobjc-arc',str(ROOT/'dev/benchmarks/teacher_logits.mm'),str(ROOT/'build/engine/model/RuntimeInstrumented.o'),*objects,str(ROOT/'build/engine/libsplash.a'),*frameworks,'-o',str(B/'teacher-logits')],check=True)
subprocess.run(['xcrun','-sdk','macosx','metal','-std=metal4.0','-O3','-Wall','-Wextra','-Werror','-I'+str(ROOT/'runtime'),'-mmacosx-version-min=26.4','-c',str(O/'architecture.metal'),'-o',str(B/'architecture.air')],check=True)
airs=[ROOT/'build/metal'/f.relative_to(ROOT/'runtime/metal/kernels').with_suffix('.air') for f in sorted((ROOT/'runtime/metal/kernels').glob('*/*.metal'))]
assert all(p.is_file() for p in airs)
subprocess.run(['xcrun','-sdk','macosx','metallib',*[str(p) for p in airs],str(B/'architecture.air'),'-o',str(B/'splash.metallib')],check=True)
shutil.copy2(ROOT/'build/host-step.metallib',B/'host-step.metallib')
print('architecture experimental splash and teacher-logits built',flush=True)

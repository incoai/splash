"""Serial structural ablations. Screening only; confirmation uses held-out ABBA."""
import argparse,hashlib,json,os,statistics,subprocess,time
from pathlib import Path
from dev.tests import smoke_real as smoke
ROOT=Path.cwd();OUT=ROOT/'build/qwen38-architecture'
parser=argparse.ArgumentParser();smoke.add_server_arguments(parser)
parser.add_argument('--start',type=int,default=0);parser.add_argument('--stop',type=int)
parser.add_argument('--allow-battery',action='store_true')
args=smoke.resolve_server_arguments(parser.parse_args());smoke.hold_model_root(args)
probes={
 'code':'Implement a Python function that merges overlapping intervals with negative endpoints. Give the complete implementation, tests, invariants, and complexity.',
 'math':'Explain the Euclidean algorithm with a loop invariant and a proof of termination. Work through the gcd of 252 and 198, then explain how to obtain a Bezout identity.',
 'chinese':'请详细解释城市植树如何影响夏天的温度、雨水和居民生活。讨论实际维护问题，避免夸大效果，用自然的段落组织内容。',
 'json':'Return a JSON array of twenty fictional service alerts, each with id, severity, title, and a nested remediation object with owner and actions. Use internally consistent varied values.'}
variants=[
 ('control',{}),
 ('draft4-no-last',{'SPLASH_ARCH_DRAFT_LAYERS':'0,1,2,3'}),
 ('draft4-no-middle',{'SPLASH_ARCH_DRAFT_LAYERS':'0,1,3,4'}),
 ('draft4-no-first',{'SPLASH_ARCH_DRAFT_LAYERS':'1,2,3,4'}),
 ('draft3-spaced',{'SPLASH_ARCH_DRAFT_LAYERS':'0,2,4'}),
 ('draft-mlp-no-middle',{'SPLASH_ARCH_SKIP_DRAFT_MLP':'2'}),
 ('draft-mlp-no-last',{'SPLASH_ARCH_SKIP_DRAFT_MLP':'4'}),
 ('draft-mlp-no-two',{'SPLASH_ARCH_SKIP_DRAFT_MLP':'1,3'}),
 ('draft-ffn16384',{'SPLASH_ARCH_DRAFT_INTERMEDIATE':'16384'}),
 ('draft-ffn12288',{'SPLASH_ARCH_DRAFT_INTERMEDIATE':'12288'}),
 ('draft-ffn8704',{'SPLASH_ARCH_DRAFT_INTERMEDIATE':'8704'}),
 ('draft-no-convs',{'SPLASH_ARCH_SKIP_CONV':'both'}),
 ('control-repeat',{})]
(OUT/'screen-variants.json').write_text(json.dumps(variants,indent=2)+'\n')

def snapshot():
 result={'utc':time.time()}
 for name,cmd in {'power':['pmset','-g','batt'],'thermal':['pmset','-g','therm'],'pressure':['sysctl','kern.memorystatus_vm_pressure_level'],'swap':['sysctl','vm.swapusage']}.items():
  p=subprocess.run(cmd,capture_output=True,text=True);result[name]=p.stdout+p.stderr
 return result

for index,(name,settings) in enumerate(variants):
 if index<args.start or (args.stop is not None and index>=args.stop):continue
 for key in list(os.environ):
  if key.startswith('SPLASH_ARCH_'):del os.environ[key]
 os.environ.update(settings)
 before=snapshot()
 if not args.allow_battery and 'AC Power' not in before['power']:raise RuntimeError('AC power required unless --allow-battery')
 document={'name':name,'settings':settings,'before':before,'measurements':[],'method':'one authored prompt/domain, sequential screening; not paired confirmation or a quality benchmark'}
 server=smoke.RealServer(args)
 try:
  status=server.wait_ready(args.startup_timeout);smoke.validate_status(status,args.kv_format)
  document['identity']=status['identity'];document['memory_plan']=status['memory_plan'];document['startup_ready_utc']=time.time()
  smoke.request(server.port,'POST','/v1/chat/completions',smoke.chat_body(args.model,'Warmup. Count from one to thirty.',max_completion_tokens=32),timeout=300)
  for domain,prompt in probes.items():
   content=hashlib.sha256(('architecture-screen-v1-'+domain).encode()).hexdigest()[:12]+'\n'+prompt
   _,start=smoke.request(server.port,'GET','/status');started=time.monotonic()
   code,response=smoke.request(server.port,'POST','/v1/chat/completions',smoke.chat_body(args.model,content,max_completion_tokens=128),timeout=600)
   elapsed=(time.monotonic()-started)*1000
   smoke.require(code==200,f'{name}/{domain}: {code}: {response}')
   _,end=smoke.request(server.port,'GET','/status')
   delta={k:end['metrics'][k]-start['metrics'][k] for k in ['decode_cycle_ms','decode_wall_ms','decode_output_tokens','drafted_tokens','accepted_draft_tokens']}
   smoke.require(delta['decode_output_tokens']>0,'no actual emitted decode tokens')
   smoke.require(response['metrics']['cache']['matched_tokens']==0,'screening prompt reused cache')
   row={'domain':domain,'response':response,'native_delta':delta,'http_wall_ms':elapsed,
        'message_sha256':hashlib.sha256(json.dumps(response['choices'][0]['message'],sort_keys=True).encode()).hexdigest(),
        'full_cycle_ms_per_emitted_token':delta['decode_cycle_ms']/delta['decode_output_tokens']}
   document['measurements'].append(row)
   (OUT/f'screen-{name}.json').write_text(json.dumps(document,indent=2,ensure_ascii=False)+'\n')
   print(name,domain,'tokens',delta['decode_output_tokens'],'cycles',response['metrics']['speculation']['cycles'],'ms/token',round(row['full_cycle_ms_per_emitted_token'],3),flush=True)
 finally:
  document['server_log_tail']=server.tail();server.close();document['after']=snapshot()
  (OUT/f'screen-{name}.json').write_text(json.dumps(document,indent=2,ensure_ascii=False)+'\n')
 print('FINISHED',name,flush=True)

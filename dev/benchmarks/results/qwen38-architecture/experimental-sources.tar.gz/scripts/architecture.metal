#include "metal/abi/KernelABI.h"
kernel void architecture_add_residual(device const bfloat *a [[buffer(0)]], device const bfloat *b [[buffer(1)]], device bfloat *out [[buffer(2)]], constant uint &n [[buffer(3)]], uint i [[thread_position_in_grid]]) {
  if(i<n) out[i]=bfloat(float(a[i])+float(b[i]));
}

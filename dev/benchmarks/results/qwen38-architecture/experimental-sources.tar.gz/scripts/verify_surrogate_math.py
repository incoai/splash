import os,subprocess,json,hashlib
from pathlib import Path
import numpy as np
R=Path.cwd();O=R/'build/qwen38-architecture';prefix=O/'surrogate-math'
env={k:v for k,v in os.environ.items() if not k.startswith('SPLASH_ARCH_')};env.update(SPLASH_ARCH_SURROGATE_LAYERS='4',SPLASH_ARCH_SURROGATE_DIRECTORY=str(O/'surrogate-model'),SPLASH_ARCH_CAPTURE_FFN=str(prefix),SPLASH_ARCH_CAPTURE_ROWS='32')
cmd=[str(O/'native/teacher-logits'),str(O/'native/splash.metallib'),str(R/'install/models/mlx-community/Qwen3.8-27B-4bit'),str(R/'build/qwen38-investigation/numerical-probe.u32'),str(prefix)+'-logits','--window','2176:128','--kv-format','int8','--state-format','fp32']
with Path(str(prefix)+'.log').open('w') as log:result=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
assert result.returncode==0

def get(path,stride,part):return np.memmap(str(path)+'-'+part+'.bf16',dtype='<u2',mode='r',shape=(64,stride,5120))[4,-32:].copy()
def w(x):return (x.astype(np.uint32)<<16).view(np.float32).astype(np.float64)
def bf(x):
 u=np.asarray(x,dtype=np.float32).view(np.uint32);return ((u+0x7fff+((u>>16)&1))>>16).astype(np.uint16)
ref=O/'surrogate-calibration-0';before=get(prefix,32,'before');normal=get(prefix,32,'normalized');after=get(prefix,32,'after')
assert np.array_equal(before,get(ref,512,'before'));assert np.array_equal(normal,get(ref,512,'normalized'))
A=np.fromfile(O/'surrogate-model/layer-4-A.f32',dtype='<f4').reshape(64,5120).astype(np.float64);B=np.fromfile(O/'surrogate-model/layer-4-B.f32',dtype='<f4').reshape(5120,64).astype(np.float64)
expected=bf(w(bf(w(normal)@A.T))@B.T);expected=bf(w(expected)+w(before))
actual=w(after);prediction=w(expected);error=float(np.linalg.norm(actual-prediction)/np.linalg.norm(prediction));match=float(np.mean(after==expected));assert error<1e-4,(error,match)
record={'exit_code':0,'command':cmd,'fixed_layer4_inputs_bitwise_equal_original':True,'math':'BF16(BF16(BF16(Xnorm @ A.T) @ B.T) + residual), fp64 CPU sums vs fp32 Metal sums','output_BF16_match_fraction':match,'output_relative_L2_error':error,'output_sha256':hashlib.sha256(after.tobytes()).hexdigest()}
(O/'surrogate-math-validation.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record,indent=2))

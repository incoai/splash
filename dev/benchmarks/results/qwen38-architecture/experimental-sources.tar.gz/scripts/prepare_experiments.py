from pathlib import Path
import hashlib,json,shutil
ROOT=Path.cwd();W=Path('/private/tmp/splash-qwen38-architecture');OUT=ROOT/'build/qwen38-architecture';OUT.mkdir(exist_ok=True)
(W/'.venv').symlink_to(ROOT/'.venv',target_is_directory=True)
header=r'''#pragma once
// Private architecture ablations. No installed tensor/config is modified.
#include "metal/CommandGraph.hpp"
#include "ops/RowCopy.hpp"
#include <CommonCrypto/CommonDigest.h>
#include <algorithm>
#include <array>
#include <cstdlib>
#include <fstream>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>
namespace splash::architecture {
struct Options {
  std::vector<uint32_t> layers{0,1,2,3,4};
  uint32_t intermediate = 17408;
  std::array<bool,5> skipMlp{};
  std::array<bool,64> skipTargetFfn{};
  bool skipAttentionConv=false, skipMlpConv=false;
  std::string capture;
  static std::vector<uint32_t> list(const char *value, uint32_t maximum) {
    std::vector<uint32_t> result; std::stringstream input(value); std::string part;
    while (std::getline(input,part,',')) {
      size_t read=0; const auto n=std::stoul(part,&read);
      if(read!=part.size() || n>=maximum || std::find(result.begin(),result.end(),n)!=result.end())
        throw std::invalid_argument("invalid architecture layer list");
      result.push_back(static_cast<uint32_t>(n));
    }
    if(result.empty()) throw std::invalid_argument("empty architecture layer list");
    return result;
  }
  Options() {
    if(const char *x=std::getenv("SPLASH_ARCH_DRAFT_LAYERS")) {
      layers=list(x,5); if(!std::is_sorted(layers.begin(),layers.end())) throw std::invalid_argument("draft source layers must ascend");
    }
    if(const char *x=std::getenv("SPLASH_ARCH_DRAFT_INTERMEDIATE")) {
      intermediate=static_cast<uint32_t>(std::stoul(x));
      if(intermediate<2048 || intermediate>17408 || intermediate%256) throw std::invalid_argument("invalid draft FFN width");
    }
    if(const char *x=std::getenv("SPLASH_ARCH_SKIP_DRAFT_MLP")) for(auto n:list(x,5)) skipMlp[n]=true;
    if(const char *x=std::getenv("SPLASH_ARCH_SKIP_TARGET_FFN")) for(auto n:list(x,64)) skipTargetFfn[n]=true;
    if(const char *x=std::getenv("SPLASH_ARCH_SKIP_CONV")) {
      const std::string mode=x;
      if(mode!="attention" && mode!="mlp" && mode!="both") throw std::invalid_argument("invalid convolution ablation");
      skipAttentionConv=mode!="mlp"; skipMlpConv=mode!="attention";
    }
    if(const char *x=std::getenv("SPLASH_ARCH_CAPTURE_FFN")) capture=x;
  }
  std::string canonical() const {
    std::string out="draft="; for(auto n:layers) out+=std::to_string(n)+",";
    out+=";I="+std::to_string(intermediate)+";mlp=";
    for(bool x:skipMlp) out+=x?'1':'0'; out+=";target=";
    for(bool x:skipTargetFfn) out+=x?'1':'0';
    return out+";conv="+std::to_string(skipAttentionConv)+std::to_string(skipMlpConv)+";capture="+std::to_string(!capture.empty());
  }
};
inline const Options &options() { static const Options value; return value; }
inline std::string sourceTensor(const std::string &name) {
  if(name.rfind("layers.",0)!=0) return name;
  const size_t end=name.find('.',7); const auto index=std::stoul(name.substr(7,end-7));
  return "layers."+std::to_string(options().layers.at(index))+name.substr(end);
}
inline void copy(metal::CommandGraph &g,metal::MetalBuffer a,metal::MetalBuffer b,uint32_t rows,uint32_t width) {
  ops::RowCopy::add(g,a,{0,width,0},b,{0,width,0},rows,width);
}
inline void residual(metal::CommandGraph &g,metal::MetalBuffer a,metal::MetalBuffer b,metal::MetalBuffer out,uint32_t rows,uint32_t width) {
  const uint32_t count=rows*width;
  g.add("architecture_add_residual",{a,b,out},count,{(count+255)/256,1,1},{256,1,1});
}
inline std::string identity(const std::string &compiled) {
  const std::string data=compiled+options().canonical(); unsigned char bytes[CC_SHA256_DIGEST_LENGTH];
  CC_SHA256(data.data(),static_cast<CC_LONG>(data.size()),bytes); const char *hex="0123456789abcdef";
  std::string result="src-"; for(auto b:bytes) {result+=hex[b>>4];result+=hex[b&15];} return result;
}
}
'''
helper=W/'dev/benchmarks/ArchitectureExperiment.hpp';helper.write_text(header)
def source(name):return (ROOT/name).read_text()
def write(name,text):
 p=W/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text)
# True reduced draft topology and resized rings/arenas/weight images.
s=source('runtime/model/ModelDescriptor.mm');s='#include "benchmarks/ArchitectureExperiment.hpp"\n'+s
old='requireWhole(draft[@"num_hidden_layers"], "draft config num_hidden_layers"),\n                  requireWhole(draft[@"intermediate_size"], "draft config intermediate_size"),'
new='static_cast<uint32_t>(architecture::options().layers.size()),\n                  architecture::options().intermediate,'
assert s.count(old)==1;s=s.replace(old,new)
anchor='  const DFlashDraftLayout layout =\n      draftLayout(target.hiddenSize'
s=s.replace(anchor,'  if (target.hiddenSize != 5120 || target.vocabularySize != 248320 ||\n      requireWhole(draft[@"num_hidden_layers"], "original draft layers") != 5 ||\n      requireWhole(draft[@"intermediate_size"], "original draft FFN") != 17408)\n    throw std::invalid_argument("architecture experiment requires the pinned 27B draft");\n'+anchor)
write('runtime/model/ModelDescriptor.mm',s)
s=source('runtime/model/DraftCheckpoint.cpp');s='#include "benchmarks/ArchitectureExperiment.hpp"\n'+s
old='''    const SourceTensor &tensor = checkpoint_.require(name);
    if (tensor.dtype != "BF16" || tensor.shape != shape)'''
new='''    const SourceTensor &tensor = checkpoint_.require(architecture::sourceTensor(name));
    const bool prefix = name.find(".mlp.") != std::string::npos && shape.size() == 2 && tensor.shape.size() == 2 &&
                        shape[0] <= tensor.shape[0] && shape[1] <= tensor.shape[1];
    if (tensor.dtype != "BF16" || (tensor.shape != shape && !prefix))'''
assert old in s;s=s.replace(old,new);write('runtime/model/DraftCheckpoint.cpp',s)
# Prefix channel pruning must keep the original source-row stride in down weights.
s=source('runtime/model/GgufPreparation.cpp')
s=s.replace('''  const uint64_t perRead = span == rows.rowBytes ? count : 1, spanGroups = span / format.block_bytes;
  std::vector<uint8_t> weights(perRead * spanGroups * groupBytes);
  for (uint64_t row = 0; row < count; row += perRead) {
    rows.safetensors.bfloat16->read(((start + row) * groups + column / format.block_bytes) * groupBytes, weights);''','''  const uint64_t sourceGroups = rows.safetensors.bfloat16->shape.back() / format.block_elements;
  const uint64_t perRead = span == rows.rowBytes && sourceGroups == groups ? count : 1;
  const uint64_t spanGroups = span / format.block_bytes;
  std::vector<uint8_t> weights(perRead * spanGroups * groupBytes);
  for (uint64_t row = 0; row < count; row += perRead) {
    rows.safetensors.bfloat16->read(((start + row) * sourceGroups + column / format.block_bytes) * groupBytes, weights);''')
assert 'const uint64_t sourceGroups' in s;write('runtime/model/GgufPreparation.cpp',s)
# Drop FFNs or local convolutions while retaining ordinary residual paths.
s=source('runtime/model/DFlashDraft.cpp');s='#include "benchmarks/ArchitectureExperiment.hpp"\n'+s
start=s.index('  for (uint32_t layer = 0; layer < layout.layers; ++layer) {',s.index('void DFlashDraft::addDecode('));end=s.index('\n  // The final norm',start)
loop=s[start:end]
loop=loop.replace('const ops::LinearPlan attentionDynamicPlan = linear.decodePlan(weights.attentionDynamic, lanes);','''const uint32_t originalLayer = architecture::options().layers.at(layer);
    const bool attentionConv = !architecture::options().skipAttentionConv;
    const bool mlpConv = !architecture::options().skipMlpConv;
    const ops::LinearPlan attentionDynamicPlan = linear.decodePlan(attentionConv ? weights.attentionDynamic : weights.qkvProjection, lanes);''')
a=loop.index('    linear.add(graph,\n               {.input = buffers.normalized');b=loop.index('    linear.add(graph, {.input = buffers.convolved',a)
part=loop[a:b];loop=loop[:a]+'    if (attentionConv) {\n'+part+'    } else architecture::copy(graph,buffers.normalized,buffers.convolved,rows,layout.hiddenSize);\n'+loop[b:]
a=loop.index('    ops::DraftAttention::addConvolution(',loop.index('weights.outputProjection'));b=loop.index('    const ops::LinearPlan mlpDynamicPlan',a)
part=loop[a:b];loop=loop[:a]+'    if (attentionConv) {\n'+part+'''    } else architecture::residual(graph,buffers.projected,buffers.hidden[current],buffers.residual,rows,layout.hiddenSize);
    if (architecture::options().skipMlp[originalLayer]) {
      architecture::copy(graph,buffers.residual,buffers.hidden[next],rows,layout.hiddenSize); continue;
    }
'''+loop[b:]
loop=loop.replace('linear.decodePlan(weights.mlpDynamic, lanes);','linear.decodePlan(mlpConv ? weights.mlpDynamic : weights.upProjection, lanes);')
a=loop.index('    linear.add(graph,\n               {.input = buffers.normalized',loop.index('mlpNormalized'));b=loop.index('    linear.add(graph,\n               {.input = buffers.convolved',a)
part=loop[a:b];loop=loop[:a]+'    if (mlpConv) {\n'+part+'    } else architecture::copy(graph,buffers.normalized,buffers.convolved,rows,layout.hiddenSize);\n'+loop[b:]
a=loop.index('    ops::DraftAttention::addConvolution(',loop.index('weights.downProjection'));b=loop.index('\n  }',a)
part=loop[a:b];loop=loop[:a]+'    if (mlpConv) {\n'+part+'    } else architecture::residual(graph,buffers.projected,buffers.residual,buffers.hidden[next],rows,layout.hiddenSize);'+loop[b:]
s=s[:start]+loop+s[end:];write('runtime/model/DFlashDraft.cpp',s)
# Target FFN removal is approximate. Capture its residual influence for calibration.
s=source('runtime/model/QwenTarget.cpp');s='#include "benchmarks/ArchitectureExperiment.hpp"\n'+s
s=s.replace('      addVerifyFfn(step, layer, residual, output);','      addVerifyFfn(step, index, layer, residual, output);')
s=s.replace('void addVerifyFfn(VerifyStep &step, const Qwen3_8LayerWeights &layer,','void addVerifyFfn(VerifyStep &step, uint32_t index, const Qwen3_8LayerWeights &layer,')
s=s.replace('void addVerifyFfn(VerifyStep &step, const Qwen3_6MoeLayerWeights &layer,','void addVerifyFfn(VerifyStep &step, uint32_t, const Qwen3_6MoeLayerWeights &layer,')
anchor='''    const QwenTargetVerifyBuffers &b = step.buffers;
    const ops::Linear &linear = operators_.linear();
    const ops::LinearPlan gateUpPlan ='''
s=s.replace(anchor,'''    if (architecture::options().skipTargetFfn[index]) {
      architecture::copy(step.graph,residual,output,step.rows,geometry_.hiddenSize); return;
    }
'''+anchor)
anchor='''    ops::Normalization::addRms(step.graph, residual, layer.postAttentionNorm, step.buffers.normalized,
                               geometry_.hiddenSize, step.rows);'''
assert s.count(anchor)==1
s=s.replace(anchor,'''    if (architecture::options().skipTargetFfn[index]) {
      architecture::copy(step.graph,residual,output,step.rows,geometry_.hiddenSize); return;
    }
'''+anchor)
# Capture after each target FFN before scratch gets reused. Prefill only, last32 rows.
needle='''    addPrefillFfn(step, index, layer, residual, b.hidden[(index & 1) ^ 1]);'''
s=s.replace(needle,needle+'''
    if (!architecture::options().capture.empty()) {
      const uint32_t count = std::min(step.rows,32U), width=geometry_.hiddenSize;
      const uint64_t bytes=uint64_t{geometry_.layers}*32*width*2;
      if (!archBefore_) {
        archBefore_=backend_.allocateBuffer(bytes,metal::BufferStorage::Shared,"arch-ffn-before");
        archAfter_=backend_.allocateBuffer(bytes,metal::BufferStorage::Shared,"arch-ffn-after");
      }
      archRows_=count;
      ops::RowCopy::add(step.graph,residual,{step.rows-count,width,0},archBefore_,{index*32,width,0},count,width);
      ops::RowCopy::add(step.graph,b.hidden[(index&1)^1],{step.rows-count,width,0},archAfter_,{index*32,width,0},count,width);
    }''')
needle='''  std::vector<metal::MetalBuffer> addPrefill(metal::CommandGraph &graph,'''
pos=s.index(needle,s.index('template <class Layout, class Layer> class Qwen3_5Target'))
s=s[:pos]+'''  ~Qwen3_5Target() override {
    if (archBefore_) {
      const std::string prefix=architecture::options().capture;
      for (const auto &[suffix,buffer]: {std::pair{"-before.bf16",archBefore_},std::pair{"-after.bf16",archAfter_}}) {
        std::ofstream out(prefix+suffix,std::ios::binary);
        out.write(static_cast<const char *>(buffer.contents()),static_cast<std::streamsize>(buffer.sizeBytes()));
      }
      std::ofstream metadata(prefix+".json");
      metadata << "{\\"layers\\":" << geometry_.layers << ",\\"width\\":" << geometry_.hiddenSize
               << ",\\"stride\\":32,\\"valid_rows\\":" << archRows_ << "}\\n";
    }
  }

'''+s[pos:]
needle='''  const QwenTargetWeights<Layout, Layer> &weights_;
};'''
assert needle in s;s=s.replace(needle,'''  mutable metal::MetalBuffer archBefore_, archAfter_;
  mutable uint32_t archRows_=0;
'''+needle)
write('runtime/model/QwenTarget.cpp',s)
# A single ordinary residual-add kernel for convolution ablations.
metal='''#include "metal/abi/KernelABI.h"
kernel void architecture_add_residual(device const bfloat *a [[buffer(0)]], device const bfloat *b [[buffer(1)]], device bfloat *out [[buffer(2)]], constant uint &n [[buffer(3)]], uint i [[thread_position_in_grid]]) {
  if(i<n) out[i]=bfloat(float(a[i])+float(b[i]));
}
'''
(OUT/'architecture.metal').write_text(metal)
# Distinguish architecture flags in the native cache/build identity.
s=source('runtime/main.mm');s='#include "benchmarks/ArchitectureExperiment.hpp"\n'+s
s=s.replace('config.resources.buildId = SPLASH_BUILD_ID;','config.resources.buildId = splash::architecture::identity(SPLASH_BUILD_ID);')
write('runtime/main.mm',s)
files=['runtime/model/ModelDescriptor.mm','runtime/model/DraftCheckpoint.cpp','runtime/model/GgufPreparation.cpp','runtime/model/DFlashDraft.cpp','runtime/model/QwenTarget.cpp','runtime/main.mm','dev/benchmarks/ArchitectureExperiment.hpp']
digest=hashlib.sha256(b''.join((W/f).read_bytes() for f in files)+(OUT/'architecture.metal').read_bytes()).hexdigest()
(OUT/'BuildIdentity.hpp').write_text(f'#pragma once\n#define SPLASH_BUILD_ID "src-{digest}"\n#define SPLASH_BUILD_SOURCE_SHA256 "{digest}"\n')
(OUT/'source-manifest.json').write_text(json.dumps({'experimental_source_sha256':digest,'base':'original combined M16+short-prefill production code','files':{f:hashlib.sha256((W/f).read_bytes()).hexdigest() for f in files},'identity':'sha256(experimental compiled source identity plus canonical architecture flags); not standard source identity'},indent=2)+'\n')
print(digest)

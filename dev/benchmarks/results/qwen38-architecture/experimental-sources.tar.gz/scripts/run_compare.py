"""Serial architecture experiments with explicit reusable protocol and provenance."""
import argparse,hashlib,json,os,subprocess,time
from pathlib import Path
from dev.tests import smoke_real as smoke
ROOT=Path.cwd();OUT=ROOT/'build/qwen38-architecture'
p=argparse.ArgumentParser();smoke.add_server_arguments(p);p.add_argument('--protocol',type=Path,required=True)
a=smoke.resolve_server_arguments(p.parse_args());smoke.hold_model_root(a)
protocol=json.loads(a.protocol.read_text())
def snapshot():
 r={'utc':time.time()}
 for name,cmd in {'power':['pmset','-g','batt'],'thermal':['pmset','-g','therm'],'pressure':['sysctl','kern.memorystatus_vm_pressure_level'],'swap':['sysctl','vm.swapusage']}.items():
  v=subprocess.run(cmd,capture_output=True,text=True);r[name]=v.stdout+v.stderr
 return r
for trial in protocol['trials']:
 name=trial['name'];env=trial['settings'];dest=OUT/(protocol['name']+'-'+name+'.json')
 if dest.exists() and json.loads(dest.read_text()).get('complete'):continue
 for k in list(os.environ):
  if k.startswith('SPLASH_ARCH_'):del os.environ[k]
 os.environ.update(env);before=snapshot();assert 'AC Power' in before['power'],before['power']
 doc={'name':name,'settings':env,'before':before,'protocol':protocol,'measurements':[]};server=smoke.RealServer(a)
 try:
  status=server.wait_ready(a.startup_timeout);smoke.validate_status(status,a.kv_format)
  doc['identity']=status['identity'];doc['memory_plan']=status['memory_plan']
  for _ in range(protocol.get('warmups',1)):
   code,resp=smoke.request(server.port,'POST','/v1/chat/completions',smoke.chat_body(a.model,'Warmup. Count from one to thirty.',max_completion_tokens=32),timeout=300)
   smoke.require(code==200,'warmup failed')
  for domain,prompt in protocol['probes'].items():
   content=hashlib.sha256((protocol['name']+'-'+domain).encode()).hexdigest()[:12]+'\n'+prompt
   _,start=smoke.request(server.port,'GET','/status');began=time.monotonic()
   code,resp=smoke.request(server.port,'POST','/v1/chat/completions',smoke.chat_body(a.model,content,max_completion_tokens=protocol['output_tokens']),timeout=600)
   elapsed=(time.monotonic()-began)*1000;smoke.require(code==200,f'{name}/{domain}: {code}: {resp}')
   _,end=smoke.request(server.port,'GET','/status');delta={k:end['metrics'][k]-start['metrics'][k] for k in ['decode_cycle_ms','decode_wall_ms','decode_output_tokens','drafted_tokens','accepted_draft_tokens']}
   smoke.require(delta['decode_output_tokens']>0,'no emitted tokens');smoke.require(resp['metrics']['cache']['matched_tokens']==0,'unexpected cache reuse')
   row={'domain':domain,'response':resp,'native_delta':delta,'http_wall_ms':elapsed,'message_sha256':hashlib.sha256(json.dumps(resp['choices'][0]['message'],sort_keys=True).encode()).hexdigest(),'full_cycle_ms_per_emitted_token':delta['decode_cycle_ms']/delta['decode_output_tokens']}
   doc['measurements'].append(row);dest.write_text(json.dumps(doc,indent=2,ensure_ascii=False)+'\n')
   print(name,domain,'tokens',delta['decode_output_tokens'],'cycles',resp['metrics']['speculation']['cycles'],'ms/token',round(row['full_cycle_ms_per_emitted_token'],3),flush=True)
  doc['complete']=True
 finally:
  doc['server_log_tail']=server.tail();server.close();doc['after']=snapshot();dest.write_text(json.dumps(doc,indent=2,ensure_ascii=False)+'\n')
 print('FINISHED',name,flush=True)

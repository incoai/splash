from pathlib import Path
import gzip,hashlib,io,json,subprocess,tarfile
R=Path.cwd();O=R/'build/qwen38-architecture';D=R/'dev/benchmarks/results/qwen38-architecture';W=Path('/private/tmp/splash-qwen38-architecture')
def digest(path):
 h=hashlib.sha256()
 with path.open('rb') as stream:
  for block in iter(lambda:stream.read(8*1024*1024),b''):h.update(block)
 return h.hexdigest()
def portable(value):
 if isinstance(value,str):return value.replace(str(R),'${SPLASH_ROOT}').replace(str(W),'${ARCH_WORKTREE}').replace('/Users/linson','${USER_HOME}')
 if isinstance(value,list):return [portable(v) for v in value]
 if isinstance(value,dict):return {k:portable(v) for k,v in value.items()}
 return value
manifest={'date':'2026-10-25','upstream_base':'3135ab45','combined_production_base':'950ffef9','experimental_branch':'experiment/qwen38-architecture','model_revisions':{'target':'10c35caafbb80f7dc6a7a432cdd11af10a6d4818','draft':'015e795645c74b1a0eeef3b570031fb62e769bc5'},'raw_files':{},'notes':['Large logits, captures, native binaries, and calibrated matrices remain local ignored artifacts.','Architecture changes are isolated from the production runtime and existing PRs.','Source archive includes exact overrides, production-base patch, scripts and token corpora; original model weights must be supplied separately.']}
files=[p for p in O.rglob('*') if p.is_file() and p.suffix in {'.json','.log','.py','.bf16','.f32','.u32','.hpp','.gz','.metal'} and '/native/' not in str(p)]
files += [O/'native'/n for n in ['splash','teacher-logits','architecture-teacher','splash.metallib','host-step.metallib']]
files += [O/'v1'/n for n in ['splash','teacher-logits','splash.metallib','host-step.metallib']]
for f in sorted(set(files)):
 manifest['raw_files'][str(f.relative_to(O))]={'bytes':f.stat().st_size,'sha256':digest(f)}
lines=[]
for f in sorted(O.rglob('*.json')):
 if '/native/' in str(f):continue
 lines.append(json.dumps({'source':str(f.relative_to(O)),'data':portable(json.loads(f.read_text()))},ensure_ascii=False,separators=(',',':'))+'\n')
(D/'measurements.jsonl.gz').write_bytes(gzip.compress(''.join(lines).encode(),mtime=0))
# Source archive intentionally omits model and captured/derived tensor data.
entries={}
for f in sorted(O.glob('*.py')):entries['scripts/'+f.name]=f.read_bytes()
for f in sorted(O.glob('*.metal')):entries['scripts/'+f.name]=f.read_bytes()
for version in ['v1','v2']:
 meta=O/'v1/source-manifest.json' if version=='v1' else O/'source-manifest.json'
 entries[version+'/source-manifest.json']=meta.read_bytes()
 entries[version+'/BuildIdentity.hpp']=(O/'v1/BuildIdentity.hpp' if version=='v1' else O/'BuildIdentity.hpp').read_bytes()
 if version=='v1':
  with tarfile.open(O/'v1/source.tar.gz','r:gz') as archive:
   for member in archive.getmembers():
    if member.isfile():entries['v1/'+member.name]=archive.extractfile(member).read()
 else:
  for name in json.loads(meta.read_text())['files']:entries['v2/'+name]=(W/name).read_bytes()
  entries['v2/dev/benchmarks/architecture_teacher_logits.mm']=(W/'dev/benchmarks/architecture_teacher_logits.mm').read_bytes()
for f in sorted(O.glob('*.u32')):entries['corpora/'+f.name]=f.read_bytes()
for name in ['numerical-probe.u32','numerical-probe-source.json']:
 entries['corpora/'+name]=(R/'build/qwen38-investigation'/name).read_bytes()
entries['production-base.patch']=subprocess.run(['git','diff','--binary','3135ab45','950ffef9','--','runtime','dev/native.mk','dev/tests','dev/benchmarks/backend_benchmark.mm','dev/benchmarks/gguf_projection_benchmark.mm'],check=True,capture_output=True).stdout
entries['installed-model-manifest.json']=(json.dumps(portable(json.loads((R/'install/models/mlx-community/Qwen3.8-27B-4bit/model.json').read_text())),indent=2)+'\n').encode()
raw=io.BytesIO()
with tarfile.open(fileobj=raw,mode='w') as archive:
 for name,contents in sorted(entries.items()):
  item=tarfile.TarInfo(name);item.size=len(contents);item.mtime=0;item.mode=0o644;archive.addfile(item,io.BytesIO(contents))
(D/'experimental-sources.tar.gz').write_bytes(gzip.compress(raw.getvalue(),mtime=0))
manifest['archive_members']={name:{'bytes':len(contents),'sha256':hashlib.sha256(contents).hexdigest()} for name,contents in entries.items()}
for name in ['summary.json','measurements.jsonl.gz','experimental-sources.tar.gz']:
 f=D/name;manifest[name]={'bytes':f.stat().st_size,'sha256':digest(f)}
manifest['control_validation']=json.loads((O/'control-validation.json').read_text());manifest['v2_control_validation']=json.loads((O/'v2-control-validation.json').read_text());manifest['surrogate_math_validation']=portable(json.loads((O/'surrogate-math-validation.json').read_text()))
(D/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('preserved',len(lines),'measurement/provenance documents;',len(manifest['raw_files']),'local file hashes;',len(entries),'source/corpus archive members')

import json,statistics,math,hashlib
from pathlib import Path
P=Path(__file__).resolve().parent;records=json.loads((P/'fixed-prefix-records.json').read_text());out={'method':'fresh-process ABBA per candidate; identical 2048-token held-out prefix and128 teacher-forced continuation tokens;16 complete Runtime::decode calls with all8 rows retained, first2 excluded; CPU logit scoring and file output outside timer','variants':{},'scope':'compute/traffic cost for this fixed input; not a natural-generation throughput or quality equivalence claim'}
for variant in ['skip4','surrogate4']:
 rs=[r for r in records if r['variant']==variant];assert len(rs)==4
 for r in rs:r['process_mean_ms']=statistics.mean(r['decode_call_ms'][r['excluded_first_cycles']:])
 a=[r['process_mean_ms'] for r in rs if r['arm']=='A'];b=[r['process_mean_ms'] for r in rs if r['arm']=='B'];ga=math.sqrt(math.prod(a));gb=math.sqrt(math.prod(b))
 hashes={r['name']:hashlib.sha256((P/f"fixed-{r['name']}-2176.f32").read_bytes()).hexdigest() for r in rs}
 assert hashes[rs[0]['name']]==hashes[rs[3]['name']];assert hashes[rs[1]['name']]==hashes[rs[2]['name']]
 out['variants'][variant]={'baseline_process_means_ms':a,'candidate_process_means_ms':b,'cycle_latency_reduction_pct':100*(1-gb/ga),'fixed_input_cycle_rate_gain_pct':100*(ga/gb-1),'baseline_spread_pct':100*(max(a)/min(a)-1),'candidate_spread_pct':100*(max(b)/min(b)-1),'logits_sha256':hashes,'control_and_candidate_repeat_bitwise':True}
(P/'fixed-prefix-summary.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))

from pathlib import Path
import subprocess,hashlib,json
R=Path.cwd();W=Path('/private/tmp/splash-qwen38-architecture');O=R/'build/qwen38-architecture';B=O/'native';s=(R/'dev/benchmarks/teacher_logits.mm').read_text()
s=s.replace('  uint32_t position = start;','  std::vector<double> architectureCycles;\n  uint32_t position = start;')
needle='''    const std::vector<ModelStepResult> results = executor.decode(plan, std::span(&item, 1));'''
s=s.replace(needle,'''    const auto architectureBegan=std::chrono::steady_clock::now();
'''+needle+'''
    architectureCycles.push_back(std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-architectureBegan).count());''')
needle='''  executor.end(id);
  const double totalSeconds'''
s=s.replace(needle,'''  std::printf("architecture_cycles end=%u ms=",window.end);
  for(double ms:architectureCycles) std::printf("%.9f,",ms);
  std::printf("\\n");
'''+needle)
p=W/'dev/benchmarks/architecture_teacher_logits.mm';p.write_text(s)
base=['xcrun','-sdk','macosx','clang++','-std=c++20','-O3','-Wall','-Wextra','-Werror','-fobjc-arc','-I'+str(W/'runtime'),'-I'+str(W/'dev'),'-mmacosx-version-min=26.4']
objects=[str(B/(n+'.o')) for n in ['ModelDescriptor','DraftCheckpoint','GgufPreparation','DFlashDraft','QwenTarget']]
cmd=base+[str(p),str(R/'build/engine/model/RuntimeInstrumented.o'),*objects,str(R/'build/engine/libsplash.a'),'-framework','Foundation','-framework','Metal','-framework','IOKit','-framework','IOSurface','-o',str(B/'architecture-teacher')]
subprocess.run(cmd,check=True)
(O/'fixed-prefix-build.json').write_text(json.dumps({'source_sha256':hashlib.sha256(s.encode()).hexdigest(),'binary_sha256':hashlib.sha256((B/'architecture-teacher').read_bytes()).hexdigest(),'command':cmd,'method':'steady clock around Runtime::decode only; excludes CPU logit scoring/copy and file output; all 8 teacher-forced rows retained; first two decode calls excluded from timing aggregation'},indent=2)+'\n')

from pathlib import Path
import os,json,subprocess,time,hashlib
R=Path.cwd();O=R/'build/qwen38-architecture';M=R/'install/models/mlx-community/Qwen3.8-27B-4bit'
records=[]
for i in range(3):
 corpus=R/'build/qwen38-investigation/numerical-probe.u32' if i==0 else O/f'calibration-{i}.u32'
 prefix=O/f'surrogate-calibration-{i}'
 env={k:v for k,v in os.environ.items() if not k.startswith('SPLASH_ARCH_')};env.update(SPLASH_ARCH_CAPTURE_FFN=str(prefix),SPLASH_ARCH_CAPTURE_ROWS='512')
 cmd=[str(O/'native/teacher-logits'),str(O/'native/splash.metallib'),str(M),str(corpus),str(prefix)+'-logits','--window','2176:128','--kv-format','int8','--state-format','fp32']
 started=time.time()
 with Path(str(prefix)+'.log').open('w') as log:run=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
 rec={'calibration':i,'command':cmd,'environment':{k:v for k,v in env.items() if k.startswith('SPLASH_ARCH_')},'exit_code':run.returncode,'seconds':time.time()-started}
 records.append(rec);(O/'surrogate-calibration-provenance.json').write_text(json.dumps(records,indent=2)+'\n');print(i,run.returncode,rec['seconds'],flush=True);assert run.returncode==0
 if i==0:
  ref=R/'build/qwen38-investigation/logits-int8-fp32-2176.f32';got=Path(str(prefix)+'-logits-2176.f32');assert got.read_bytes()==ref.read_bytes()
  (O/'v2-control-validation.json').write_text(json.dumps({'bitwise_equal':True,'control_sha256':hashlib.sha256(got.read_bytes()).hexdigest(),'rows':129,'vocabulary':248320},indent=2)+'\n')

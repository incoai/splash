from pathlib import Path
import hashlib,json
R=Path.cwd();W=Path('/private/tmp/splash-qwen38-architecture');O=R/'build/qwen38-architecture'
p=W/'dev/benchmarks/ArchitectureExperiment.hpp';s=p.read_text();s=s.replace('  std::string capture;','  std::string capture;\n  uint32_t captureRows=32;\n  std::string surrogateDirectory, surrogateDigest;\n  std::vector<uint32_t> surrogateLayers;')
s=s.replace('    if(const char *x=std::getenv("SPLASH_ARCH_CAPTURE_FFN")) capture=x;','''    if(const char *x=std::getenv("SPLASH_ARCH_CAPTURE_FFN")) capture=x;
    if(const char *x=std::getenv("SPLASH_ARCH_CAPTURE_ROWS")) {
      captureRows=static_cast<uint32_t>(std::stoul(x));
      if(captureRows<32 || captureRows>512) throw std::invalid_argument("capture rows outside 32..512");
    }
    if(const char *x=std::getenv("SPLASH_ARCH_SURROGATE_LAYERS")) surrogateLayers=list(x,64);
    if(const char *x=std::getenv("SPLASH_ARCH_SURROGATE_DIRECTORY")) surrogateDirectory=x;
    if(surrogateLayers.empty()!=surrogateDirectory.empty()) throw std::invalid_argument("surrogate directory and layers required together");
    if(!surrogateLayers.empty()) {
      CC_SHA256_CTX ctx; CC_SHA256_Init(&ctx);
      for(auto n:surrogateLayers) for(const char *part:{"A","B"}) {
        const std::string path=surrogateDirectory+"/layer-"+std::to_string(n)+"-"+part+".f32";
        std::ifstream in(path,std::ios::binary|std::ios::ate);
        if(!in || in.tellg()!=std::streamoff(64*5120*4)) throw std::invalid_argument("surrogate tensor size: "+path);
        std::vector<char> bytes(64*5120*4); in.seekg(0);in.read(bytes.data(),bytes.size());
        if(!in) throw std::invalid_argument("surrogate tensor read: "+path);
        CC_SHA256_Update(&ctx,bytes.data(),bytes.size());
      }
      unsigned char bytes[CC_SHA256_DIGEST_LENGTH];CC_SHA256_Final(bytes,&ctx);const char *hex="0123456789abcdef";
      for(auto b:bytes) {surrogateDigest+=hex[b>>4];surrogateDigest+=hex[b&15];}
    }''')
s=s.replace('+std::to_string(!capture.empty());','+std::to_string(!capture.empty())+":"+std::to_string(captureRows)+";surrogate="+surrogateDigest+":"+[&]{std::string s;for(auto n:surrogateLayers)s+=std::to_string(n)+",";return s;}();')
p.write_text(s)
(W/'dev/benchmarks/ArchitectureSurrogate.hpp').write_text(r'''#pragma once
#include "ArchitectureExperiment.hpp"
#include "ops/Linear.hpp"
#include <cmath>
#include <cstring>
namespace splash::architecture {
// Rank-64 calibrated residual surrogate; all original target weights remain resident.
class SurrogateFfn {
public:
  explicit SurrogateFfn(metal::MetalBackend &backend) {
    for(auto index:options().surrogateLayers) {
      for(uint32_t part=0;part<2;++part) {
        const std::string path=options().surrogateDirectory+"/layer-"+std::to_string(index)+(part?"-B.f32":"-A.f32");
        std::ifstream in(path,std::ios::binary);std::vector<float> values(64*5120);
        in.read(reinterpret_cast<char *>(values.data()),values.size()*4);
        if(!in || !std::ranges::all_of(values,[](float x){return std::isfinite(x);})) throw std::invalid_argument("invalid surrogate: "+path);
        auto buffer=backend.allocateBuffer(values.size()*4,metal::BufferStorage::Shared,"architecture-surrogate");
        std::memcpy(buffer.contents(),values.data(),values.size()*4);
        tensors_[index][part]=ops::QuantizedSegment::floats(part?5120:64,part?64:5120,std::move(buffer));
      }
      present_[index]=true;
    }
  }
  bool has(uint32_t index) const {return present_.at(index);}
  void add(metal::CommandGraph &graph,uint32_t index,metal::MetalBuffer input,metal::MetalBuffer latent,
           metal::MetalBuffer residualInput,metal::MetalBuffer output,uint32_t rows) const {
    const auto &t=tensors_.at(index);
    ops::addGgufFloat(graph,input,t[0],latent,rows,64,0,ops::FloatOutput::BFloat16,ops::FloatTile::Simdgroup);
    ops::addGgufFloat(graph,latent,t[1],output,rows,5120,0,ops::FloatOutput::BFloat16,ops::FloatTile::Simdgroup);
    residual(graph,output,residualInput,output,rows,5120);
  }
private:
  std::array<std::array<ops::QuantizedSegment,2>,64> tensors_{};
  std::array<bool,64> present_{};
};
}
''')
p=W/'runtime/model/QwenTarget.cpp';s=p.read_text();s='#include "benchmarks/ArchitectureSurrogate.hpp"\n'+s
s=s.replace('operators), weights_(weights) {','operators), surrogate_(backend), weights_(weights) {')
s=s.replace('std::pair{"-after.bf16",archAfter_}', 'std::pair{"-after.bf16",archAfter_},std::pair{"-normalized.bf16",archNormalized_}')
s=s.replace('<< ",\\\"stride\\\":32,\\\"valid_rows\\\":" << archRows_', '<< ",\\\"stride\\\":" << architecture::options().captureRows << ",\\\"valid_rows\\\":" << archRows_')
s=s.replace('const uint32_t count = std::min(step.rows,32U), width=geometry_.hiddenSize;','const uint32_t stride=architecture::options().captureRows;\n      const uint32_t count = std::min(step.rows,stride), width=geometry_.hiddenSize;')
s=s.replace('uint64_t{geometry_.layers}*32*width*2','uint64_t{geometry_.layers}*stride*width*2')
s=s.replace('archAfter_=backend_.allocateBuffer(bytes,metal::BufferStorage::Shared,"arch-ffn-after");','archAfter_=backend_.allocateBuffer(bytes,metal::BufferStorage::Shared,"arch-ffn-after");\n        archNormalized_=backend_.allocateBuffer(bytes,metal::BufferStorage::Shared,"arch-ffn-normalized");')
s=s.replace('{index*32,width,0}', '{index*stride,width,0}')
s=s.replace('ops::RowCopy::add(step.graph,residual,{step.rows-count,width,0},archBefore_,{index*stride,width,0},count,width);', 'ops::RowCopy::add(step.graph,residual,{step.rows-count,width,0},archBefore_,{index*stride,width,0},count,width);\n      ops::RowCopy::add(step.graph,b.normalized,{step.rows-count,width,0},archNormalized_,{index*stride,width,0},count,width);')
needle='''    const ops::PrefillFfnBuffers ffn = step.buffers.ffn();'''
s=s.replace(needle,'''    if(surrogate_.has(index)) {
      surrogate_.add(step.graph,index,step.buffers.normalized,step.buffers.denseIntermediate,residual,output,step.rows);return;
    }
'''+needle)
needle='''    const QwenTargetVerifyBuffers &b = step.buffers;
    const ops::Linear &linear = operators_.linear();
    const ops::LinearPlan gateUpPlan ='''
s=s.replace(needle,'''    const QwenTargetVerifyBuffers &b = step.buffers;
    if(surrogate_.has(index)) {
      ops::Normalization::addRms(step.graph,residual,layer.postAttentionNorm,b.normalized,geometry_.hiddenSize,step.rows);
      surrogate_.add(step.graph,index,b.normalized,b.denseIntermediate,residual,output,step.rows);return;
    }
    const ops::Linear &linear = operators_.linear();
    const ops::LinearPlan gateUpPlan =''')
s=s.replace('mutable metal::MetalBuffer archBefore_, archAfter_;','mutable metal::MetalBuffer archBefore_, archAfter_, archNormalized_;\n  architecture::SurrogateFfn surrogate_;')
assert 'stride\\\":32' not in s
p.write_text(s)
files=json.loads((O/'source-manifest.json').read_text())['files'];files['dev/benchmarks/ArchitectureSurrogate.hpp']=''
digest=hashlib.sha256(b''.join((W/f).read_bytes() for f in files)+(O/'architecture.metal').read_bytes()).hexdigest()
(O/'BuildIdentity.hpp').write_text(f'#pragma once\n#define SPLASH_BUILD_ID "src-{digest}"\n#define SPLASH_BUILD_SOURCE_SHA256 "{digest}"\n')
(O/'source-manifest.json').write_text(json.dumps({'experimental_source_sha256':digest,'base':'original combined M16+short-prefill production code','files':{f:hashlib.sha256((W/f).read_bytes()).hexdigest() for f in files},'identity':'sha256(experimental compiled source identity plus canonical architecture flags and loaded surrogate tensor hash)'},indent=2)+'\n')
print(digest)

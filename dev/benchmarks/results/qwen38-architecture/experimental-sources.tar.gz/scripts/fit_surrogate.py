"""Calibration-only low-rank residual regression; independent held-out source never read here."""
import hashlib,json,time
from pathlib import Path
import numpy as np
O=Path(__file__).resolve().parent;DEST=O/'surrogate-model';DEST.mkdir(exist_ok=True)
layers=[3,4,5,9];ranks=[16,32,64];strengths=[.001,.01,.1,1.]

def bf16(a):
 u=np.asarray(a,dtype=np.float32).view(np.uint32);return ((u+np.uint32(0x7fff)+((u>>16)&1))>>16).astype(np.uint16)
def widen(a):return (np.asarray(a,dtype=np.uint32)<<16).view(np.float32)
def get(i,part,layer):
 meta=json.loads((O/f'surrogate-calibration-{i}.json').read_text())
 m=np.memmap(O/f'surrogate-calibration-{i}-{part}.bf16',dtype='<u2',mode='r',shape=(64,meta['stride'],5120))
 return widen(m[layer,:meta['valid_rows']]).astype(np.float64)
def eig(a):
 v,u=np.linalg.eigh(a);return v[::-1],u[:,::-1]
def prepare(X,Y):
 ex,ux=eig(X@X.T);ey,uy=eig(Y@Y.T)
 basis=(Y.T@uy[:,:64])/np.sqrt(np.maximum(ey[:64],1e-20))[None,:]
 return ex,ux,basis,float(np.trace(X@X.T)/len(X))
def fit(X,Y,cache,r,strength):
 ex,ux,basis,scale=cache;basis=basis[:,:r];scores=Y@basis
 left=X.T@(ux@((ux.T@scores)/(np.maximum(ex,0)+scale*strength)[:,None]))
 return left,basis
summary={'method':'delta = Y_final_BF16 - residual_BF16; fit RMS-normalized BF16 X to delta with ridge regression and output PCA; three leave-one-calibration-prefix-out folds select rank and ridge; heldout source never used','layers':{},'tensor_format':'F32 A [64,5120], B [5120,64]; unused rank coordinates padded zero; runtime latent/output BF16 then residual add','calibration_sources':json.loads((O/'corpus-manifest.json').read_text())}
started=time.time()
for layer in layers:
 xs=[get(i,'normalized',layer) for i in range(3)];ys=[get(i,'after',layer)-get(i,'before',layer) for i in range(3)]
 scores={(r,s):[] for r in ranks for s in strengths}
 for held in range(3):
  X=np.concatenate([xs[i] for i in range(3) if i!=held]);Y=np.concatenate([ys[i] for i in range(3) if i!=held]);cache=prepare(X,Y);normalizer=np.square(ys[held]).sum()
  for r,s in scores:
   A,B=fit(X,Y,cache,r,s);latent=widen(bf16(xs[held]@A));pred=widen(bf16(latent@B.T));scores[(r,s)].append(float(np.square(pred-ys[held]).sum()/normalizer))
 choice=min(scores,key=lambda k:np.mean(scores[k]));rank,strength=choice
 X=np.concatenate(xs);Y=np.concatenate(ys);cache=prepare(X,Y);A,B=fit(X,Y,cache,rank,strength)
 ap=np.zeros((64,5120),dtype='<f4');bp=np.zeros((5120,64),dtype='<f4');ap[:rank]=A.T;bp[:,:rank]=B
 for label,t in [('A',ap),('B',bp)]:t.tofile(DEST/f'layer-{layer}-{label}.f32')
 train=widen(bf16(widen(bf16(X@A))@B.T))
 summary['layers'][layer]={'rank':rank,'ridge_relative':strength,'cv_relative_squared_error':float(np.mean(scores[choice])),'cv_by_prefix':scores[choice], 'training_relative_squared_error':float(np.square(train-Y).sum()/np.square(Y).sum()),'grid':[{'rank':r,'ridge_relative':s,'cv_relative_squared_error':float(np.mean(v)),'folds':v} for (r,s),v in scores.items()]}
 print('layer',layer,'rank',rank,'ridge',strength,'CV relative error',summary['layers'][layer]['cv_relative_squared_error'],'seconds',time.time()-started,flush=True)
 (O/'surrogate-fit.json').write_text(json.dumps(summary,indent=2)+'\n')
summary['tensor_sha256']={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted(DEST.glob('*.f32'))};summary['seconds']=time.time()-started
(O/'surrogate-fit.json').write_text(json.dumps(summary,indent=2)+'\n')

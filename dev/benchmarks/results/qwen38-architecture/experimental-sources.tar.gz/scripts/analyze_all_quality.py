import hashlib,json,numpy as np
from pathlib import Path
P=Path(__file__).resolve().parent;V=248320;ids=np.fromfile(P/'heldout.u32',dtype='<u4')
summary={'scope':'Same-prefix sensitivity to original quantized target, two held-out source-text prefixes,129 positions each; not broad task quality certification.','draft_verifier_controls':{},'target_variants':{}}
for end in [1152,4224]:
 ref=np.memmap(P/f'quality-control-{end}.f32',dtype='<f4',mode='r').reshape(-1,V)
 for name in ['draft3-verifier-control','width12288-verifier-control']:
  path=P/f'{name}-{end}.f32'
  equal=path.read_bytes()==(P/f'quality-control-{end}.f32').read_bytes()
  summary['draft_verifier_controls'][f'{name}/{end}']={'bitwise_equal':equal}
  assert equal,(name,end)
 for name in list(json.loads((P/'target-ffn-calibration.json').read_text())['variants'])+['surrogate1','surrogate4']:
  if name=='control':continue
  z=np.memmap(P/f'quality-{name}-{end}.f32',dtype='<f4',mode='r').reshape(-1,V)
  kls=[];tvs=[];agreements=0;nll=[];maxdiff=0.0;errors=0.0
  for i in range(0,129,4):
   a=np.array(ref[i:i+4],dtype=np.float64);b=np.array(z[i:i+4],dtype=np.float64)
   assert np.isfinite(a).all() and np.isfinite(b).all()
   agreements+=int(np.sum(a.argmax(1)==b.argmax(1)))
   def lp(x):
    maximum=x.max(1,keepdims=True)
    return x-maximum-np.log(np.exp(x-maximum).sum(1,keepdims=True))
   la,lb=lp(a),lp(b);p,q=np.exp(la),np.exp(lb)
   kls.extend(np.sum(p*(la-lb),1).tolist());tvs.extend((.5*np.abs(p-q).sum(1)).tolist())
   rr=np.arange(len(a));truth=ids[end-128+i:end-128+i+len(a)]
   nll.extend((la[rr,truth]-lb[rr,truth]).tolist())
   d=b-a;d-=d.mean(1,keepdims=True);errors+=float(np.square(d).sum());maxdiff=max(maxdiff,float(np.abs(d).max()))
  row={'rows':129,'top1_match':agreements,'mean_KL':float(np.mean(kls)),'max_KL':float(np.max(kls)),
       'mean_TV':float(np.mean(tvs)),'max_TV':float(np.max(tvs)),'true_token_NLL_delta':float(np.mean(nll)),
       'centered_RMSE':(errors/(129*V))**.5,'centered_max_abs':maxdiff}
  summary['target_variants'].setdefault(name,{})[end]=row
  print(name,end,'top1',agreements,'/129','KL',round(row['mean_KL'],5),'NLLdelta',round(row['true_token_NLL_delta'],5),flush=True)
(P/'all-quality-summary.json').write_text(json.dumps(summary,indent=2)+'\n')

import json,os,subprocess,time
from pathlib import Path
ROOT=Path.cwd();OUT=ROOT/'build/qwen38-architecture';MODEL=ROOT/'install/models/mlx-community/Qwen3.8-27B-4bit'
variants=json.loads((OUT/'target-ffn-calibration.json').read_text())['variants']
records=[]
# A shorter draft must leave verifier logits unchanged on an identical forced prefix.
cases=[('draft3-verifier-control',{'SPLASH_ARCH_DRAFT_LAYERS':'0,2,4'}),('width12288-verifier-control',{'SPLASH_ARCH_DRAFT_INTERMEDIATE':'12288'})]
for name,skips in variants.items():cases.append(('quality-'+name,{} if not skips else {'SPLASH_ARCH_SKIP_TARGET_FFN':','.join(map(str,skips))}))
for name,settings in cases:
 env={k:v for k,v in os.environ.items() if not k.startswith('SPLASH_ARCH_')};env.update(settings)
 args=[str(OUT/'native/teacher-logits'),str(OUT/'native/splash.metallib'),str(MODEL),str(OUT/'heldout.u32'),str(OUT/name),'--window','1152:128','--window','4224:128','--kv-format','int8','--state-format','fp32']
 start=time.time()
 with (OUT/(name+'.log')).open('w') as log:result=subprocess.run(args,env=env,stdout=log,stderr=subprocess.STDOUT)
 records.append({'name':name,'settings':settings,'command':args,'exit_code':result.returncode,'seconds':time.time()-start})
 (OUT/'quality-provenance.json').write_text(json.dumps(records,indent=2)+'\n')
 print(name,result.returncode,round(records[-1]['seconds'],2),flush=True)
 if result.returncode:raise RuntimeError(name)

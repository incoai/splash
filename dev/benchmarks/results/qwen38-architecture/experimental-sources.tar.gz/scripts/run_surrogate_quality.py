import json,os,subprocess,time
from pathlib import Path
R=Path.cwd();O=R/'build/qwen38-architecture';M=R/'install/models/mlx-community/Qwen3.8-27B-4bit';records=[]
for name,layers in [('surrogate1','4'),('surrogate4','3,4,5,9')]:
 env={k:v for k,v in os.environ.items() if not k.startswith('SPLASH_ARCH_')};settings={'SPLASH_ARCH_SURROGATE_LAYERS':layers,'SPLASH_ARCH_SURROGATE_DIRECTORY':str(O/'surrogate-model')};env.update(settings)
 cmd=[str(O/'native/teacher-logits'),str(O/'native/splash.metallib'),str(M),str(O/'heldout.u32'),str(O/f'quality-{name}'),'--window','1152:128','--window','4224:128','--kv-format','int8','--state-format','fp32']
 started=time.time()
 with (O/f'quality-{name}.log').open('w') as log:r=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
 records.append({'name':name,'settings':settings,'command':cmd,'exit_code':r.returncode,'seconds':time.time()-started});(O/'surrogate-quality-provenance.json').write_text(json.dumps(records,indent=2)+'\n');print(name,r.returncode,records[-1]['seconds'],flush=True);assert r.returncode==0

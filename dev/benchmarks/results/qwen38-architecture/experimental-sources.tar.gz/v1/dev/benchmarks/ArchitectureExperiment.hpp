#pragma once
// Private architecture ablations. No installed tensor/config is modified.
#include "metal/CommandGraph.hpp"
#include "ops/RowCopy.hpp"
#include <CommonCrypto/CommonDigest.h>
#include <algorithm>
#include <array>
#include <cstdlib>
#include <fstream>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>
namespace splash::architecture {
struct Options {
  std::vector<uint32_t> layers{0,1,2,3,4};
  uint32_t intermediate = 17408;
  std::array<bool,5> skipMlp{};
  std::array<bool,64> skipTargetFfn{};
  bool skipAttentionConv=false, skipMlpConv=false;
  std::string capture;
  static std::vector<uint32_t> list(const char *value, uint32_t maximum) {
    std::vector<uint32_t> result; std::stringstream input(value); std::string part;
    while (std::getline(input,part,',')) {
      size_t read=0; const auto n=std::stoul(part,&read);
      if(read!=part.size() || n>=maximum || std::find(result.begin(),result.end(),n)!=result.end())
        throw std::invalid_argument("invalid architecture layer list");
      result.push_back(static_cast<uint32_t>(n));
    }
    if(result.empty()) throw std::invalid_argument("empty architecture layer list");
    return result;
  }
  Options() {
    if(const char *x=std::getenv("SPLASH_ARCH_DRAFT_LAYERS")) {
      layers=list(x,5); if(!std::is_sorted(layers.begin(),layers.end())) throw std::invalid_argument("draft source layers must ascend");
    }
    if(const char *x=std::getenv("SPLASH_ARCH_DRAFT_INTERMEDIATE")) {
      intermediate=static_cast<uint32_t>(std::stoul(x));
      if(intermediate<2048 || intermediate>17408 || intermediate%256) throw std::invalid_argument("invalid draft FFN width");
    }
    if(const char *x=std::getenv("SPLASH_ARCH_SKIP_DRAFT_MLP")) for(auto n:list(x,5)) skipMlp[n]=true;
    if(const char *x=std::getenv("SPLASH_ARCH_SKIP_TARGET_FFN")) for(auto n:list(x,64)) skipTargetFfn[n]=true;
    if(const char *x=std::getenv("SPLASH_ARCH_SKIP_CONV")) {
      const std::string mode=x;
      if(mode!="attention" && mode!="mlp" && mode!="both") throw std::invalid_argument("invalid convolution ablation");
      skipAttentionConv=mode!="mlp"; skipMlpConv=mode!="attention";
    }
    if(const char *x=std::getenv("SPLASH_ARCH_CAPTURE_FFN")) capture=x;
  }
  std::string canonical() const {
    std::string out="draft="; for(auto n:layers) out+=std::to_string(n)+",";
    out+=";I="+std::to_string(intermediate)+";mlp=";
    for(bool x:skipMlp) out+=x?'1':'0'; out+=";target=";
    for(bool x:skipTargetFfn) out+=x?'1':'0';
    return out+";conv="+std::to_string(skipAttentionConv)+std::to_string(skipMlpConv)+";capture="+std::to_string(!capture.empty());
  }
};
inline const Options &options() { static const Options value; return value; }
inline std::string sourceTensor(const std::string &name) {
  if(name.rfind("layers.",0)!=0) return name;
  const size_t end=name.find('.',7); const auto index=std::stoul(name.substr(7,end-7));
  return "layers."+std::to_string(options().layers.at(index))+name.substr(end);
}
inline void copy(metal::CommandGraph &g,metal::MetalBuffer a,metal::MetalBuffer b,uint32_t rows,uint32_t width) {
  ops::RowCopy::add(g,a,{0,width,0},b,{0,width,0},rows,width);
}
inline void residual(metal::CommandGraph &g,metal::MetalBuffer a,metal::MetalBuffer b,metal::MetalBuffer out,uint32_t rows,uint32_t width) {
  const uint32_t count=rows*width;
  g.add("architecture_add_residual",{a,b,out},count,{(count+255)/256,1,1},{256,1,1});
}
inline std::string identity(const std::string &compiled) {
  const std::string data=compiled+options().canonical(); unsigned char bytes[CC_SHA256_DIGEST_LENGTH];
  CC_SHA256(data.data(),static_cast<CC_LONG>(data.size()),bytes); const char *hex="0123456789abcdef";
  std::string result="src-"; for(auto b:bytes) {result+=hex[b>>4];result+=hex[b&15];} return result;
}
}

#pragma once
#include "ArchitectureExperiment.hpp"
#include "ops/Linear.hpp"
#include <cmath>
#include <cstring>
namespace splash::architecture {
// Rank-64 calibrated residual surrogate; all original target weights remain resident.
class SurrogateFfn {
public:
  explicit SurrogateFfn(metal::MetalBackend &backend) {
    for(auto index:options().surrogateLayers) {
      for(uint32_t part=0;part<2;++part) {
        const std::string path=options().surrogateDirectory+"/layer-"+std::to_string(index)+(part?"-B.f32":"-A.f32");
        std::ifstream in(path,std::ios::binary);std::vector<float> values(64*5120);
        in.read(reinterpret_cast<char *>(values.data()),values.size()*4);
        if(!in || !std::ranges::all_of(values,[](float x){return std::isfinite(x);})) throw std::invalid_argument("invalid surrogate: "+path);
        auto buffer=backend.allocateBuffer(values.size()*4,metal::BufferStorage::Shared,"architecture-surrogate");
        std::memcpy(buffer.contents(),values.data(),values.size()*4);
        tensors_[index][part]=ops::QuantizedSegment::floats(part?5120:64,part?64:5120,std::move(buffer));
      }
      present_[index]=true;
    }
  }
  bool has(uint32_t index) const {return present_.at(index);}
  void add(metal::CommandGraph &graph,uint32_t index,metal::MetalBuffer input,metal::MetalBuffer latent,
           metal::MetalBuffer residualInput,metal::MetalBuffer output,uint32_t rows) const {
    const auto &t=tensors_.at(index);
    ops::addGgufFloat(graph,input,t[0],latent,rows,64,0,ops::FloatOutput::BFloat16,ops::FloatTile::Simdgroup);
    ops::addGgufFloat(graph,latent,t[1],output,rows,5120,0,ops::FloatOutput::BFloat16,ops::FloatTile::Simdgroup);
    residual(graph,output,residualInput,output,rows,5120);
  }
private:
  std::array<std::array<ops::QuantizedSegment,2>,64> tensors_{};
  std::array<bool,64> present_{};
};
}

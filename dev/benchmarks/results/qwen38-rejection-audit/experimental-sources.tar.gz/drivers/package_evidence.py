"""Freeze portable evidence; omit models, native binaries, activations and full-vocab logits."""
from pathlib import Path
import gzip,hashlib,io,json,shutil,subprocess,tarfile

R=Path.cwd();O=R/'build/qwen38-rejection-audit'
W=Path('/private/tmp/splash-qwen38-rejection-audit')
P=R/'dev/benchmarks/results/qwen38-rejection-audit';P.mkdir(parents=True,exist_ok=True)
def sha(path):
 with Path(path).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def clean(x):
 if isinstance(x,str):
  for a,b in [(str(R),'${SPLASH_ROOT}'),(str(W),'${AUDIT_WORKTREE}'),(str(Path.home()),'${USER_HOME}')]:x=x.replace(a,b)
  return x
 if isinstance(x,list):return [clean(v) for v in x]
 if isinstance(x,dict):return {k:clean(v) for k,v in x.items()}
 return x
def dump(path,x):path.write_text(json.dumps(clean(x),indent=2,ensure_ascii=False,allow_nan=False)+'\n')
names=['protocol','audit-final-summary','training-plan','frozen-dataset','selector-training',
 'selector-selection','final-test-lock','selector-validation-comparison','selector-final-comparison',
 'selector-parity-sensitivity','validation-reference-audit','policy-summary','restore-summary',
 'restore-output-parity','forensic-analysis','feature-math-validation','quantization-parity',
 'mps-quantization-parity','reader-control-validation','released-export-control-validation',
 'native-build','batch-build','policy-build','forensic-build','run-provenance','followup-provenance',
 'final-phases-provenance','forensic-provenance','candidate-validation-protocol',
 'final-test-protocol','restore-protocol','policy-protocol']
for n in names:dump(P/(n+'.json'),json.loads((O/(n+'.json')).read_text()))
for n in ['summary','measurements','protocol']:
 dump(P/('m16-'+n+'.json'),json.loads((O/'m16-qualification'/(n+'.json')).read_text()))
for name in ['selected','released-control']:
 dump(P/(name+'-export.json'),json.loads((O/'model-assemblies'/name/'experiment.json').read_text()))

# One record per case; all proposals/support/first-rejection labels remain independently auditable.
sets=[('baseline','protocol.json'),('selector-validation','candidate-validation-protocol.json'),
      ('selector-test','final-test-protocol.json'),('restore','restore-protocol.json')]
compact=[];raw_files=set()
for label,name in sets:
 for case in json.loads((O/name).read_text())['cases']:
  path=Path(case['output_file']);raw_files.add(path);raw_files.add(Path(str(path)+'.hidden.bf16'))
  rows=[json.loads(line) for line in path.read_text().splitlines()]
  assert rows[-1]['kind']=='end' and rows[-1]['records']==len(rows)-2
  keep=[{k:v for k,v in row.items() if k not in ['unary','edges']} for row in rows[1:-1]]
  compact.append({'set':label,'case':{k:case[k] for k in ['id','family','domain','split','context','thinking']},
                  'metadata':rows[0],'cycles':keep,'raw_capture_sha256':sha(path)})
with (P/'compact-traces.jsonl.gz').open('wb') as raw:
 with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as out:
  for row in compact:out.write((json.dumps(clean(row),separators=(',',':'),ensure_ascii=False)+'\n').encode())

protocol=json.loads((O/'protocol.json').read_text())
representatives=[c for c in protocol['cases'] if c['id'].split('-')[1]=='0' and c['context']=='2k']
assert len(representatives)==8
def archive(path,entries):
 with path.open('wb') as raw:
  with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as gz:
   with tarfile.open(fileobj=gz,mode='w') as tar:
    for name,data in sorted(entries.items()):
     info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0
     tar.addfile(info,io.BytesIO(data))
archive(P/'representative-captures.tar.gz',{c['id']+'.jsonl':Path(c['output_file']).read_bytes() for c in representatives})
shutil.copyfile(W/'dev/benchmarks/draft_replay.py',P/'replay_reference.py')

sources={}
for p in sorted(O.glob('*.py')):sources['drivers/'+p.name]=p.read_bytes()
for name in ['runtime/model/Runtime.cpp','runtime/model/RuntimeInstrumentation.hpp',
             'dev/benchmarks/decode_profile.mm','dev/benchmarks/draft_replay.py',
             'dev/benchmarks/dflash_context_compare.py','dev/benchmarks/rejection_audit.mm',
             'dev/benchmarks/rejection_policy_audit.mm','dev/benchmarks/rejection_forensic.mm',
             'dev/tests/tools/test_draft_replay.py','dev/tests/tools/test_dflash_context_compare.py']:
 sources['audit-source/'+name]=(W/name).read_bytes()
sources['training-reference/draft_training/quantization.py']=Path('/private/tmp/splash-dflash-543/draft_training/quantization.py').read_bytes()
historical={}
for folder in ['dflash-acceptance-m5-pro','dflash-restored-context-m5-pro']:
 for p in sorted((W/'dev/benchmarks/results'/folder).iterdir()):
  if p.is_file():historical['dev/benchmarks/results/'+folder+'/'+p.name]={'bytes':p.stat().st_size,'sha256':sha(p)}
sources['historical-test-fixtures.json']=json.dumps({'scope':'Historical fixtures already published in PR550/PR556; not duplicated in this archive. Required only for their two archived-fixture unit tests, not verify_bundle.py.',
 'source_commits':{'dflash-acceptance-m5-pro':'ef0e95d4','dflash-restored-context-m5-pro':'b4006b12'},'files':historical},indent=2).encode()
sources['production-base.patch']=subprocess.run(['git','diff','3135ab45','950ffef9','--'],check=True,capture_output=True).stdout
# Runtime.cpp accessors were staged during conflict resolution; include the index too.
sources['development-accessors.patch']=subprocess.run(['git','diff','HEAD','--','runtime/model/Runtime.cpp','runtime/model/RuntimeInstrumentation.hpp'],cwd=W,check=True,capture_output=True).stdout
for p in sorted((O/'prompts').iterdir()):
 if p.suffix in ['.u32','.txt']:sources['prompts/'+p.name]=p.read_bytes()
sources['protocol-original.json']=(O/'protocol.json').read_bytes()
archive(P/'experimental-sources.tar.gz',sources)

for folder in ['policy-captures','forensic']:
 for p in (O/folder).iterdir():
  if p.is_file():raw_files.add(p)
for p in (O/'selector-fits').glob('*.bf16'):raw_files.add(p)
for p in (O/'native').iterdir():
 if p.is_file():raw_files.add(p)
for n in ['frozen-development.npz','frozen-validation.npz']:raw_files.add(O/n)
raw_manifest={str(p.relative_to(O)):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(raw_files)}
model=json.loads((R/'install/models/mlx-community/Qwen3.8-27B-4bit/model.json').read_text())
model_checks={}
digest_cache={}
for name,record in model['files'].items():
 path=Path(record['path']);key=str(path.resolve())
 if key not in digest_cache:digest_cache[key]=sha(path)
 digest=digest_cache[key]
 expected=record['digest']
 native_digest=digest if len(expected)==64 else hashlib.sha1(b'blob '+str(path.stat().st_size).encode()+b'\0'+path.read_bytes()).hexdigest()
 assert native_digest==expected,('installed model changed',name)
 model_checks[name]={'bytes':path.stat().st_size,'sha256':digest,'installed_digest':expected,'matches_installed_manifest':True}
manifest={'scope':'Immutable local research evidence; no runtime or model default changes.',
 'upstream_base':'3135ab45','measured_combined_base':'950ffef9',
 'diagnostic_sources':{'PR550':'ef0e95d4','PR556':'b4006b12','PR551_quantizer':'d8b15fbe'},
 'models':{'sources':model['sources'],'original_installed_files_unchanged':model_checks},
 'compact_trace_cases':len(compact),'compact_trace_cycles':sum(len(c['cycles']) for c in compact),
 'representative_full_capture_cases':[c['id'] for c in representatives],
 'representative_raw_bytes_preserved':True,
 'archive_source_sha256':{name:hashlib.sha256(data).hexdigest() for name,data in sources.items()},
 'local_raw_artifacts_not_shipped':raw_manifest,
 'portable_sha256':{p.name:sha(p) for p in sorted(P.iterdir()) if p.is_file() and p.name!='manifest.json'}}
dump(P/'manifest.json',manifest)
print(json.dumps({'portable_files':len(manifest['portable_sha256']),'bytes':sum(p.stat().st_size for p in P.iterdir()),
                  'compact_cases':len(compact),'compact_cycles':manifest['compact_trace_cycles'],
                  'local_raw_files_hashed':len(raw_manifest),'installed_files_verified':len(model_checks)},indent=2))

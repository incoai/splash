"""Matched-correct-context policy reference on native raw logits; no rollout or timing claim."""
from pathlib import Path
import collections,hashlib,json,struct,sys
import numpy as np
O=Path(__file__).resolve().parent;sys.path.insert(0,'/private/tmp/splash-qwen38-rejection-audit');from dev.benchmarks import draft_replay

def softmax(x):
 x=np.asarray(x,dtype=np.float64);x=x-x.max();p=np.exp(x);return p/p.sum()
rows=[]
for case in json.loads((O/'policy-protocol.json').read_text())['cases']:
 p=Path(case['output_file']);m,records=draft_replay.read_capture(p);draft_replay.summarize(m,records);raw=np.memmap(str(p)+'.policy.f32',dtype='<f4',mode='r').reshape(-1,248320)
 prompt=np.fromfile(case['prompt_file'],dtype='<u4').tolist();history=[];seen_records=0
 for record in records:
  if 'policy_record' not in record:
   history+=record['output_tokens'];continue
  pos=record['policy_position'];index=record['policy_record'];assert index==seen_records;seen_records+=1
  anchor=record['output_tokens'][0];within=record['proposed'][:pos];generated=history+[anchor]+within
  context=prompt+generated;digest=hashlib.sha256(struct.pack('<'+'I'*len(context),*context)).hexdigest();assert digest==record['policy_context_sha256']
  logits=np.array(raw[index]);assert np.isfinite(logits).all();assert int(logits.argmax())==record['target_tokens'][pos],(case['id'],index,pos)
  cs=np.asarray(record['candidates'],dtype=np.int64).reshape(7,16);prev=0 if pos==0 else int(np.flatnonzero(cs[pos-1]==record['target_tokens'][pos-1])[0]);score=np.asarray(record['unary'],dtype=np.float32).reshape(7,16)[pos]+np.asarray(record['edges'][pos],dtype=np.float32).reshape(-1,16)[prev]
  assert int(cs[pos,score.argmax()])==record['proposed'][pos]
  history_ids=set(history+[anchor]);full_ids=set(generated)
  for strength in [0.0,1.5,-.5]:
   adjusted=logits.copy();adjusted[list(full_ids)]-=np.float32(strength);target=softmax(adjusted);gold=int(adjusted.argmax());variants={}
   for name,ids in [('existing',set()),('history',history_ids),('history_and_prefix',full_ids)]:
    scores=score-np.asarray([strength if int(t) in ids else 0 for t in cs[pos]],dtype=np.float32);q=softmax(scores)
    variants[name]={'overlap':float(np.minimum(target[cs[pos]],q).sum()),'greedy_agreement':int(int(cs[pos,scores.argmax()])==gold)}
   rows.append({'family':case['family'],'domain':case['domain'],'case':case['id'],'cycle':record['cycle'],'position':pos,'presence_penalty':strength,'target_mass_in_candidate_support':float(target[cs[pos]].sum()),'target_greedy_token_in_support':bool(gold in cs[pos]),'variants':variants})
  history+=record['output_tokens']
 assert seen_records==len(raw)
summary={'scope':'FP64 unit-temperature unfiltered policy reference applied to native FP32 pre-policy logits at identical correct prefixes; target mass outside top16 is retained; greedy-context sample, not sampled rollouts, native policy probability parity, or a serving-speed claim','validated_native_raw_argmax_and_proposal_replay':True,'rows':rows,'aggregates':{}}
for strength in [0.0,1.5,-.5]:
 selected=[r for r in rows if r['presence_penalty']==strength];result={'rows':len(selected),'families':len({r['family'] for r in selected}),'mean_support_mass':float(np.mean([r['target_mass_in_candidate_support'] for r in selected])),'variants':{}}
 for variant in ['existing','history','history_and_prefix']:
  result['variants'][variant]={'mean_overlap':float(np.mean([r['variants'][variant]['overlap'] for r in selected])),'greedy_agreements':sum(r['variants'][variant]['greedy_agreement'] for r in selected)}
 summary['aggregates'][str(strength)]=result
(O/'policy-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary['aggregates'],indent=2))

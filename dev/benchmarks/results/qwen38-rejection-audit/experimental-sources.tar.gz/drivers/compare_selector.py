from pathlib import Path
import argparse,collections,hashlib,json,math,statistics,sys
import numpy as np
O=Path(__file__).resolve().parent;sys.path.insert(0,'/private/tmp/splash-qwen38-rejection-audit');from dev.benchmarks import draft_replay

def gm(xs):return math.exp(statistics.mean(math.log(x) for x in xs))
def compare(protocol_name):
 pro=json.loads((O/protocol_name).read_text());base={c['id']:c for c in json.loads((O/'protocol.json').read_text())['cases']};rows=[]
 for c in pro['cases']:
  cm,cr=draft_replay.read_capture(c['output_file']);bm,br=draft_replay.read_capture(base[c['id']]['output_file']);cs=draft_replay.summarize(cm,cr);bs=draft_replay.summarize(bm,br)
  for key in ['prompt_sha256','thinking','reasoning_effort','source_id','kv_format','state_format']:assert cm[key]==bm[key],(c['id'],key)
  out=[t for r in cr for t in r['output_tokens']];original=[t for r in br for t in r['output_tokens']];n=min(len(out),len(original));bad=next((i for i,(a,b) in enumerate(zip(out,original)) if a!=b),None)
  # Only selector H changed: initial draft hidden, candidates, and unary logits must be exact.
  for key in ['candidates','unary']:assert cr[0][key]==br[0][key],(c['id'],'initial non-selector forward changed',key)
  h0=Path(c['output_file']+'.hidden.bf16').read_bytes()[:8*5120*2];hb=Path(base[c['id']]['output_file']+'.hidden.bf16').read_bytes()[:8*5120*2];assert h0==hb,(c['id'],'initial hidden changed')
  rows.append({'id':c['id'],'family':c['family'],'domain':c['domain'],'context':c['context'],'thinking':c['thinking'],'baseline_tau':bs['mean_retained_tokens'],'candidate_tau':cs['mean_retained_tokens'],'tau_ratio':cs['mean_retained_tokens']/bs['mean_retained_tokens'],'common_prefix_tokens':n,'first_output_difference':bad,'common_output_prefix_equal':bad is None,'baseline_first_rejections':bs['first_rejections'],'candidate_first_rejections':cs['first_rejections'],'baseline_cycles':len(br),'candidate_cycles':len(cr)})
 family=collections.defaultdict(list)
 for r in rows:family[r['family']].append(math.log(r['tau_ratio']))
 family_means=np.asarray([np.mean(v) for v in family.values()]);rng=np.random.default_rng(20261025);boot=np.exp(np.mean(rng.choice(family_means,(20000,len(family_means)),replace=True),axis=1))-1
 summary={'scope':'native natural greedy rollout acceptance;32 cycles maximum; identical target/backbone/codebooks, merged selector-H update; bootstrap clusters task families and does not treat cycles as independent; not timed serving throughput','cases':rows,'geometric_mean_tau_gain_pct':100*(gm([r['tau_ratio'] for r in rows])-1),'family_cluster_bootstrap_95pct_gain_interval':(100*np.quantile(boot,[.025,.975])).tolist(),'independent_task_families':len(family),'all_initial_non_selector_forwards_bitwise_equal':True,'all_common_output_prefixes_equal':all(r['common_output_prefix_equal'] for r in rows),'domains':{},'strata':{}}
 for key in sorted({r['domain'] for r in rows}):
  selected=[r for r in rows if r['domain']==key];summary['domains'][key]={'cases':len(selected),'tau_gain_pct':100*(gm([r['tau_ratio'] for r in selected])-1)}
 for context in sorted({r['context'] for r in rows}):
  for think in [False,True]:
   selected=[r for r in rows if r['context']==context and r['thinking']==think]
   if selected:summary['strata'][context+'/'+('think' if think else 'direct')]={'cases':len(selected),'tau_gain_pct':100*(gm([r['tau_ratio'] for r in selected])-1)}
 summary['acceptance_promotion_gate']=summary['all_common_output_prefixes_equal'] and summary['geometric_mean_tau_gain_pct']>=3 and all(v['tau_gain_pct']>=-1 for v in summary['domains'].values())
 return summary
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('protocol');p.add_argument('output');a=p.parse_args();s=compare(a.protocol);(O/a.output).write_text(json.dumps(s,indent=2)+'\n');print(json.dumps({k:v for k,v in s.items() if k!='cases'},indent=2))

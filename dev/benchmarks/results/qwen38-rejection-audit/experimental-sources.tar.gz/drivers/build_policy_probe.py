from pathlib import Path
import hashlib,json,subprocess
R=Path.cwd();O=R/'build/qwen38-rejection-audit';W=Path('/private/tmp/splash-qwen38-rejection-audit');B=O/'native'
s=(W/'dev/benchmarks/rejection_audit.mm').read_text()
s=s.replace('bool thinking = false, hidden = true;','bool thinking = false, hidden = true, policy = false;')
s=s.replace('  uint64_t records=0,emitted=0;bool terminal=false;','  uint64_t records=0,emitted=0,policyRecords=0;bool terminal=false;\n  std::ofstream policy; if(item.policy){policy.open(item.outputFile+".policy.f32",std::ios::binary);if(!policy)throw std::runtime_error("cannot create policy sidecar");}')
s=s.replace('    callMs+=ms;','    callMs+=ms;\n    auto raw=item.policy?model::RuntimeInstrumentation::takeTargetLogits(executor):std::vector<std::vector<float>>{};')
needle='''    file<<"}\\n";
    history.insert'''
addition='''    if(item.policy) {
      const uint32_t passed=std::min(draft.accepted,draft.retained-1);
      const bool rejected=draft.accepted<draft.verifyRows-1 && draft.retained==draft.accepted+1 && result.outputTokens.size()==draft.retained && draft.targetTokens[draft.accepted]!=draft.proposed[draft.accepted];
      if(passed+uint32_t(rejected)>0) {
        const uint32_t pos=rejected?passed:passed-1;
        constexpr uint32_t vocabulary=248320;
        if(raw.size()!=1 || raw[0].size()!=8ULL*vocabulary)throw std::runtime_error("bad raw target shape");
        policy.write(reinterpret_cast<const char *>(raw[0].data()+uint64_t{pos}*vocabulary),vocabulary*sizeof(float));
        auto correctContext=context;correctContext.insert(correctContext.end(),draft.proposed.begin(),draft.proposed.begin()+pos);
        file<<",\\"policy_record\\":"<<policyRecords++<<",\\"policy_position\\":"<<pos<<",\\"policy_context_sha256\\":"<<json::quote(digestIds(correctContext));
      }
    }
'''
assert needle in s;s=s.replace(needle,addition+needle)
s=s.replace('  file.flush();if(hidden)hidden->flush();','  file.flush();if(hidden)hidden->flush();if(item.policy)policy.flush();')
s=s.replace('item.thinking=numberField(value,@"thinking",0);item.hidden=numberField(value,@"capture_hidden",1);','item.thinking=numberField(value,@"thinking",0);item.hidden=numberField(value,@"capture_hidden",1);item.policy=numberField(value,@"capture_policy",0);')
s=s.replace('<<",\\"hidden_capture\\":"<<(item.hidden?"true":"false")','<<",\\"policy_capture\\":"<<(item.policy?"true":"false")<<",\\"policy_vocabulary\\":248320"<<",\\"hidden_capture\\":"<<(item.hidden?"true":"false")')
s=s.replace('      prefill(executor,lane,prompt,item.cycles*8+2,0,item.restore,item.materialize);','      model::RuntimeInstrumentation::captureTargetLogits(executor,item.policy);\n      prefill(executor,lane,prompt,item.cycles*8+2,0,item.restore,item.materialize);\n      if(item.policy)static_cast<void>(model::RuntimeInstrumentation::takeTargetLogits(executor));')
s=s.replace('      executor.end(lane.id);','      executor.end(lane.id);\n      model::RuntimeInstrumentation::captureTargetLogits(executor,false);')
p=W/'dev/benchmarks/rejection_policy_audit.mm';p.write_text(s)
files=['runtime/model/Runtime.cpp','runtime/model/RuntimeInstrumentation.hpp','dev/benchmarks/decode_profile.mm','dev/benchmarks/rejection_policy_audit.mm'];h=hashlib.sha256(b''.join((W/f).read_bytes() for f in files)).hexdigest()
cmd=['xcrun','-sdk','macosx','clang++','-std=c++20','-O3','-Wall','-Wextra','-Werror','-fobjc-arc','-I'+str(W/'runtime'),'-I'+str(W/'dev'),'-mmacosx-version-min=26.4','-DSPLASH_AUDIT_SOURCE_ID="'+h+'"',str(p),str(B/'RuntimeInstrumented.o'),str(R/'build/engine/metal/MetalBackendInstrumented.o'),str(R/'build/engine/libsplash.a'),'-framework','Foundation','-framework','Metal','-framework','IOKit','-framework','IOSurface','-o',str(B/'rejection-policy')]
subprocess.run(cmd,check=True)
(O/'policy-build.json').write_text(json.dumps({'source_sha256':h,'files':{f:hashlib.sha256((W/f).read_bytes()).hexdigest() for f in files},'binary_sha256':hashlib.sha256((B/'rejection-policy').read_bytes()).hexdigest(),'command':cmd},indent=2)+'\n')
pro=json.loads((O/'protocol.json').read_text());cases=[];(O/'policy-captures').mkdir(exist_ok=True)
for case in pro['cases']:
 if case['split']!='development' or case['thinking'] or case['context']!='short' or int(case['id'].split('-')[1]) not in [0,1]:continue
 cases.append({**case,'id':case['id']+'-policy','cycles':8,'capture_hidden':False,'capture_policy':True,'output_file':str(O/'policy-captures'/f"{case['id']}.jsonl")})
(O/'policy-protocol.json').write_text(json.dumps({**pro,'method':'Native raw target logits at first rejection or last reached position; policy reference evaluates unit-temperature unfiltered p/q at identical correct prefixes; no native sampled rollout or serving policy change','cases':cases},indent=2,ensure_ascii=False)+'\n');print('policy probe built',len(cases),'cases',h)

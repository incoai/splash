"""Post-decision audit only: rescore the LOCKED selector with emitted reference tokens.

Do not use this to select or fit another checkpoint. The final native test already failed.
The original fixed-continuation proxy could fill the final, unobserved suffix using
target rows after a rejection. Those rows do not have a correct-prefix guarantee.
"""
from pathlib import Path
import collections,json,sys
import numpy as np
import torch
import torch.nn.functional as F
import frozen_selector as fs

O=Path(__file__).resolve().parent
sys.path.insert(0,'/private/tmp/splash-dflash-543')
from draft_training.quantization import fake_affine4
torch.set_num_threads(2)
protocol=json.loads((O/'protocol.json').read_text())
cycles=[];incomplete=0;legacy_count=0;legacy_conflicts=0
for case in protocol['cases']:
 if case['split']!='validation':continue
 rows,h=fs.load_case(case);emitted={};legacy={}
 for row in rows:
  for j,t in enumerate(row['output_tokens']):
   emitted[row['position']+j]=t;legacy[row['position']+j]=t
  for j,t in enumerate(row['target_tokens']):legacy[row['position']+j+1]=t
 for ri,row in enumerate(rows):
  positions=[row['position']+j+1 for j in range(7)]
  if not all(p in legacy for p in positions):continue
  legacy_count+=1
  legacy_conflicts+=any(p in emitted and legacy[p]!=emitted[p] for p in positions)
  if not all(p in emitted for p in positions):incomplete+=1;continue
  cs=np.asarray(row['candidates'],dtype=np.int64).reshape(7,16)
  edges=np.empty((7,16,16),dtype=np.float32);prev=np.empty((7,16),dtype=np.int64)
  for pos in range(7):
   e=np.asarray(row['edges'][pos],dtype=np.float32).reshape(-1,16)
   edges[pos]=e if pos else e[0][None,:]
   prev[pos]=cs[pos-1] if pos else row['output_tokens'][0]
  cycles.append({'case':case['id'],'hidden':np.array(h[ri,1:]),'candidates':cs,
                 'predecessors':prev,'edges':edges,
                 'unary':np.asarray(row['unary'],dtype=np.float32).reshape(7,16),
                 'truth':np.asarray([emitted[p] for p in positions])})
get=fs.source_tensors()
base=torch.tensor(fs.widen(get('candidate_selector.hidden_projection.weight')),device='mps')
before=torch.tensor(fs.widen(get('candidate_selector.predecessor_codebook')),device='mps')
after=torch.tensor(fs.widen(get('candidate_selector.successor_codebook')),device='mps')
selection=json.loads((O/'selector-selection.json').read_text())
selected=np.fromfile(selection['tensor_file'],dtype='<u2').reshape(256,5120)
selected=torch.tensor(fs.widen(selected),device='mps')
@torch.no_grad()
def evaluate(weight):
 wnew=fake_affine4(weight);wold=fake_affine4(base);scores=collections.defaultdict(list)
 for start in range(0,len(cycles),32):
  batch=cycles[start:start+32]
  hx=torch.tensor(fs.widen(np.asarray([r['hidden'] for r in batch])),device='mps')
  dz=F.linear(hx,wnew).to(torch.bfloat16).float()-F.linear(hx,wold).to(torch.bfloat16).float()
  ids=torch.tensor(np.asarray([r['candidates'] for r in batch]),device='mps',dtype=torch.long)
  pi=torch.tensor(np.asarray([r['predecessors'] for r in batch]),device='mps',dtype=torch.long)
  old=torch.tensor(np.asarray([r['edges'] for r in batch]),device='mps')
  unary=torch.tensor(np.asarray([r['unary'] for r in batch]),device='mps')
  edges=old+torch.einsum('npad,npbd->npab',before[pi]*dz.unsqueeze(-2),after[ids])
  previous=torch.zeros(len(batch),device='mps',dtype=torch.long)
  rr=torch.arange(len(batch),device='mps');out=[]
  for pos in range(7):
   pick=(unary[:,pos]+edges[rr,pos,previous]).argmax(-1)
   out.append(ids[rr,pos,pick]);previous=pick
  chosen=torch.stack(out,1).cpu().numpy()
  for i,row in enumerate(batch):
   bad=np.flatnonzero(chosen[i]!=row['truth'])
   scores[row['case']].append(int(bad[0])+1 if len(bad) else 8)
 return {'macro_tau_proxy':float(np.mean([np.mean(v) for v in scores.values()])),
         'per_case':{k:float(np.mean(v)) for k,v in scores.items()}}
released=evaluate(base);candidate=evaluate(selected)
report={'scope':'Post-decision reference audit; only released and already-locked checkpoint rescored. No fitting, reselection or final-test tuning.',
        'legacy_proxy_cycles':legacy_count,'legacy_cycles_without_complete_emitted_reference':incomplete,
        'legacy_cycles_conflicting_with_observed_emitted_tokens':legacy_conflicts,
        'corrected_complete_emitted_reference_cycles':len(cycles),
        'training_reached_prefix_labels_affected':False,
        'released':released,'locked_candidate':candidate,
        'corrected_proxy_gain_pct':100*(candidate['macro_tau_proxy']/released['macro_tau_proxy']-1),
        'native_final_test_decision':'rejected; unchanged',
        'recommendation':'Future proxy builders must omit unobserved suffixes; post-rejection target rows are not valid continuation labels.'}
(O/'validation-reference-audit.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ['released','locked_candidate']},indent=2))

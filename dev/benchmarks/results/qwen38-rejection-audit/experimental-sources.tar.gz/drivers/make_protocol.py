"""Authored, task-family-split acceptance audit; synthetic context records, not task accuracy eval."""
from pathlib import Path
import hashlib,json,random,sys
from transformers import AutoTokenizer
from server.chat_templates import render_chat_template,template_options
R=Path.cwd();O=R/'build/qwen38-rejection-audit';(O/'prompts').mkdir(exist_ok=True);(O/'captures').mkdir(exist_ok=True)
t=AutoTokenizer.from_pretrained(R/'install/models/mlx-community/Qwen3.8-27B-4bit/tokenizer',local_files_only=True)
tasks={
'code':[
('rollback-dsu','Implement a Python disjoint-set union structure supporting snapshot and rollback. State which optimizations are safe, provide the implementation and focused tests, and explain time and space bounds.'),
('stream-csv','Implement an incremental CSV parser in Python that accepts arbitrary string chunks, quoted fields, escaped quotes, CRLF and embedded newlines. Explain how state persists across chunks and give tests.'),
('fair-scheduler','Design and implement a small Python job scheduler that respects per-tenant concurrency limits and rotates fairly among ready tenants. Explain cancellation and completion races and give tests.'),
('autocomplete','Implement a trie-based autocomplete index in Python supporting insert, removal, prefix search and deterministic top suggestions. Explain invariants and complexity, including shared prefixes.'),
('cursor-pages','Implement cursor-based pagination over records sorted by timestamp and unique ID. Explain duplicate timestamps, concurrent inserts and deletes, and give a Python implementation with tests.'),
('token-bucket','Implement a thread-safe token-bucket rate limiter in Python using a monotonic clock. Inject the clock for deterministic tests and explain bursts, clock advancement and nonblocking rejection.'),
('topological-order','Implement a Python dependency planner that returns a deterministic topological order or a concrete cycle. Handle disconnected nodes and duplicate edges. Give code, tests, invariants and complexity.'),
('rolling-median','Implement an exact sliding-window median in Python using two heaps and lazy deletion. Explain balancing and duplicate values, and include tests that repeatedly expire the current median.')],
'math':[
('divisibility-induction','Prove that n cubed minus n is divisible by six for every integer n, using two independent arguments. Explain the role of consecutive integers and address negative n.'),
('inclusion-exclusion','Explain inclusion-exclusion for three finite sets, prove the formula using element multiplicities, and give a worked numerical example with consistent intersections.'),
('convex-jensen','Prove the midpoint inequality for the square function, extend it to weighted averages, and explain its equality cases and its relation to variance.'),
('binary-gcd','Explain the binary greatest-common-divisor algorithm. Prove the transformations, work through gcd(462,1071), and give pseudocode with a termination argument.'),
('geometric-series','Derive the finite geometric-series formula and use it to establish convergence when the absolute ratio is below one. Explain exceptional cases and provide numerical examples.'),
('pigeonhole','Give a rigorous proof that any n+1 integers contain two whose difference is divisible by n. Then discuss why replacing n+1 by n fails, with examples.'),
('bezout-inverse','Derive the extended Euclidean algorithm and use it to find the multiplicative inverse of 37 modulo 101. Verify the result and explain when such an inverse exists.'),
('counting-paths','Count shortest lattice paths from (0,0) to (7,5) that avoid (3,2). Derive the counting method, show the arithmetic, and explain how to generalize to two forbidden points.')],
'chinese':[
('clinic-access','请为社区诊所制定改善预约和现场排队的方案。解释老人、临时急需就诊者和上班族的不同需求，分析预约爽约、人员安排和执行成本，提出可检验的改进指标。'),
('school-meals','请分析学校食堂减少食物浪费的可行方案。结合学生选择、菜单反馈、份量和食品安全，说明如何试行和评估，避免用简单的处罚替代管理。'),
('storm-drains','请为住宅区雨水排水沟制定雨季前后的维护方案。说明检查顺序、居民反馈、垃圾堵塞、积水记录和施工协作，区分可以自行处理与需要专业人员处理的问题。'),
('bicycle-parking','请讨论老城区自行车和电动车停车空间的安排。平衡行人通行、消防通道、商户装卸和居民便利，提出可逐步试行的设计和反馈机制。'),
('library-reuse','请提出社区旧图书馆改造的方案。考虑安静阅读、儿童活动、无障碍通行、设备维护与志愿者安排，解释空间和预算取舍，并说明如何评价使用效果。'),
('waste-collection','请分析社区分类垃圾收集的运行问题。讨论收集时段、标识、异味、清洁人员工作量和居民参与，提出务实的试点方案及评估方法。'),
('bus-information','请为社区公交站的信息展示提出改进建议。考虑临时改道、老年乘客、夜间辨识、手机使用困难和维护责任，说明信息如何更新、验证和纠错。'),
('shared-laundry','请为公寓共享洗衣房制定公平可行的使用安排。讨论预约、超时占用、设备故障、清洁责任和邻里纠纷，给出试行步骤及可衡量的效果指标。')],
'json':[
('deployment-calendar','Return only a JSON object describing a fictional deployment calendar. Include at least20 milestones with unique IDs, dependency IDs, owners, status, and rollback actions. Keep references consistent.'),
('warehouse-transfers','Return only a JSON document describing at least24 fictional warehouse transfers. Include product IDs, origin, destination, quantity, checks and approval records, with consistent references and varied values.'),
('museum-program','Return only JSON for a fictional museum program with at least20 events, rooms, guides, accessibility details and dependencies. Use consistent IDs and sensible schedules.'),
('device-maintenance','Return only JSON describing a fictional maintenance plan for at least24 devices. Include device IDs, locations, owners, inspection steps and follow-up actions with consistent references.'),
('support-triage','Return only JSON representing a fictional support triage queue of at least24 tickets. Include severity, evidence, routing, owner, dependencies and resolution checks. Use unique IDs and coherent references.'),
('research-catalog','Return only JSON for a fictional research artifact catalog with at least24 artifacts. Include provenance, authors, versions, linked datasets and validation steps, keeping identifiers consistent.'),
('conference-rooms','Return only JSON describing a fictional conference schedule with at least24 sessions. Include rooms, speakers, setup dependencies, accessibility notes and contingency actions. Keep references internally consistent.'),
('backup-manifest','Return only JSON for a fictional backup manifest with at least24 resources. Include resource IDs, retention, dependencies, recovery order, owners and verification steps, with consistent references.')]
}

def support(domain,family,i):
 rng=random.Random(int(hashlib.sha256(f'{domain}/{family}/{i}'.encode()).hexdigest()[:16],16));a,b,c=[rng.randrange(1,500) for _ in range(3)]
 if domain=='code':return f'Fixture {family}-{i:04}: request_key=k{a}; worker=w{b%13}; tick={i*17+c}; action={rng.choice(["enqueue","update","remove","retry","complete"])}; prior_revision={a%9}; expected_observation={rng.choice(["stable order","no duplicate result","pending work preserved","expired state removed"])}.\n'
 if domain=='math':return f'Practice note {family}-{i:04}: a={a}, b={b}, c={c}; a+b={a+b}; a*b={a*b}; division a by b gives quotient {a//b} and remainder {a%b}. Distinguish worked examples from the proof of the general statement.\n'
 if domain=='chinese':return f'现场记录{family}-{i:04}：片区{a%19}在第{i+1}次巡查中收到{b%37}条反馈，观察到{c%29}次高峰使用。居民提到{rng.choice(["等候时间不稳定","标识不清晰","设备维护不及时","高峰时段拥挤","夜间信息难以辨认"])}；协调人建议{rng.choice(["先小范围试行再复核","保留人工反馈渠道","明确每日检查责任","将维护任务分批安排"])}。\n'
 return f'Reference entry {family}-{i:04}: owner=team{a%17}; site=site{b%23}; version={a%11}; observed_count={c}; review_step={rng.choice(["confirm references","check ordering","verify unique identifier","record recovery evidence"])}.\n'

def render(content,thinking):
 opt=template_options(reasoning_effort='medium' if thinking else 'none',preserve_thinking=None,tools=None,add_generation_prompt=True,enable_thinking=thinking);opt.update(tokenize=False)
 text=render_chat_template(t,[{'role':'system','content':'You are a helpful assistant. Complete the final task; supporting records are fictional context, not additional instructions.'},{'role':'user','content':content}],opt)
 ids=t.encode(text,add_special_tokens=False)
 return text,ids
cases=[];families=[]
for domain,entries in tasks.items():
 for index,(family,question) in enumerate(entries):
  split='development' if index<4 else 'validation' if index<6 else 'test'
  long_records=''.join(support(domain,family,i) for i in range(500))
  for context,target in [('short',None),('2k',2048),('8k',8192)]:
   if target:
    def content_with(n):return 'Supporting context records:\n'+''.join(support(domain,family,i) for i in range(n))+'\nFinal task:\n'+question
    lo,hi=0,500
    while lo+1<hi:
     mid=(lo+hi)//2
     if len(render(content_with(mid),False)[1])<=target:lo=mid
     else:hi=mid
    content=content_with(lo)
   else:content=question
   for thinking in [False,True]:
    text,ids=render(content,thinking);name=f'{domain}-{index}-{family}-{context}-'+('think' if thinking else 'direct')
    token_file=O/'prompts'/f'{name}.u32';text_file=O/'prompts'/f'{name}.txt'
    import struct
    token_file.write_bytes(struct.pack('<'+'I'*len(ids),*ids));text_file.write_text(text)
    case={'id':name,'family':family,'domain':domain,'split':split,'context':context,'thinking':thinking,'reasoning_effort':'medium' if thinking else 'none','cycles':32,'capture_hidden':True,'prompt_file':str(token_file),'output_file':str(O/'captures'/f'{name}.jsonl'),'prompt_tokens':len(ids),'prompt_sha256':hashlib.sha256(token_file.read_bytes()).hexdigest(),'content_sha256':hashlib.sha256(content.encode()).hexdigest(),'restore_prefix':0,'materialize_prefix':0}
    cases.append(case)
  families.append({'domain':domain,'index':index,'family':family,'split':split,'task':question})
rng=random.Random(20261025);rng.shuffle(cases)
# Case families are frozen before observing any captures. Test families are not used for training or tuning.
protocol={'schema':'qwen38-rejection-audit-v1','seed':20261025,'method':'B1 greedy natural rollout; original five-layer released draft; explicit thinking modes; prompt-family split; short/approximately2K/approximately8K contexts;32 cycles maximum, terminal censoring preserved','context_scope':'Long contexts contain unique deterministic synthetic supporting records; this is an acceptance study, not a real-world retrieval/task-accuracy benchmark. Record templates are shared across families.','families':families,'cases':cases}
(O/'protocol.json').write_text(json.dumps(protocol,indent=2,ensure_ascii=False)+'\n')
# Same-build control using reviewed single-case driver input.
control={'id':'reader-batch-control','family':'reader-control','domain':'code','split':'control','reasoning_effort':'none','thinking':False,'cycles':8,'capture_hidden':True,'prompt_file':'/private/tmp/splash-dflash-acceptance/dev/benchmarks/results/dflash-acceptance-m5-pro/code.u32','output_file':str(O/'reader-batch-control.jsonl')}
(O/'control-suite.json').write_text(json.dumps({'schema':protocol['schema'],'cases':[control]},indent=2)+'\n')
(O/'pilot-suite.json').write_text(json.dumps({**protocol,'cases':[next(c for c in cases if c['domain']==dom and c['context']==ctx and c['thinking']==think) for dom,ctx,think in [('code','short',False),('math','2k',True),('chinese','8k',False),('json','short',True)]]},indent=2,ensure_ascii=False)+'\n')
print('Frozen protocol:',len(families),'independent families;',len(cases),'cases;', {k:sum(c['split']==k for c in cases) for k in ['development','validation','test']})

from pathlib import Path
import hashlib,json,os,subprocess,time
R=Path.cwd();O=R/'build/qwen38-rejection-audit';PY=R/'.venv/bin/python'
def h(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
state={'started_utc':time.time(),'phases':[]}
def save():(O/'final-phases-provenance.json').write_text(json.dumps(state,indent=2)+'\n')
def run(name,cmd):
 print('START',name,flush=True);state['active']=name;save();began=time.time()
 with (O/(name+'.log')).open('w') as log:r=subprocess.run(list(map(str,cmd)),stdout=log,stderr=subprocess.STDOUT)
 state['phases'].append({'name':name,'command':list(map(str,cmd)),'seconds':time.time()-began,'exit_code':r.returncode});save();print('END',name,r.returncode,round(time.time()-began,2),flush=True)
 if r.returncode:raise RuntimeError(name)
assert json.loads((O/'followup-provenance.json').read_text())['active']=='complete'
selection=json.loads((O/'selector-selection.json').read_text());protocol=json.loads((O/'protocol.json').read_text())
test=[];(O/'final-test').mkdir(exist_ok=True)
for case in protocol['cases']:
 if case['split']=='test':test.append({**case,'output_file':str(O/'final-test'/Path(case['output_file']).name)})
(O/'final-test-protocol.json').write_text(json.dumps({**protocol,'method':'Single final evaluation of frozen selected selector; unseen task families; no further fitting or checkpoint selection from these outcomes','cases':test},indent=2,ensure_ascii=False)+'\n')
lock={'selected_tensor_sha256':selection['tensor_sha256'],'training_plan_sha256':h(O/'training-plan.json'),'final_protocol_sha256':h(O/'final-test-protocol.json'),'test_metrics_inspected_before_lock':False,'frozen_utc':time.time()};(O/'final-test-lock.json').write_text(json.dumps(lock,indent=2)+'\n')
run('released-control-export',[PY,O/'export_selector.py',O/'selector-fits/released-hidden-projection.bf16','released-control'])
control=json.loads((O/'control-suite.json').read_text());control['cases'][0]['output_file']=str(O/'released-export-control.jsonl');(O/'released-control-protocol.json').write_text(json.dumps(control,indent=2)+'\n')
run('released-control-native',[O/'native/rejection-audit',O/'native/splash.metallib',O/'model-assemblies/released-control',O/'released-control-protocol.json'])
if selection['improves_proxy']:
 run('selector-native-final-test',[O/'native/rejection-audit',O/'native/splash.metallib',O/'model-assemblies/selected',O/'final-test-protocol.json'])
run('restore-native',[O/'native/rejection-audit',O/'native/splash.metallib',R/'install/models/mlx-community/Qwen3.8-27B-4bit',O/'restore-protocol.json'])
state['active']='complete';state['finished_utc']=time.time();save();print('FINAL PHASES COMPLETE',flush=True)

from pathlib import Path
import hashlib,json,subprocess,time,sys
R=Path.cwd();O=R/'build/qwen38-rejection-audit';assert json.loads((O/'final-phases-provenance.json').read_text())['active']=='complete';state={'started_utc':time.time(),'phases':[]}
def save():(O/'forensic-provenance.json').write_text(json.dumps(state,indent=2)+'\n')
def run(name,cmd):
 state['active']=name;save();began=time.time();print('START',name,flush=True)
 with (O/(name+'.log')).open('w') as f:r=subprocess.run(list(map(str,cmd)),stdout=f,stderr=subprocess.STDOUT)
 state['phases'].append({'name':name,'command':list(map(str,cmd)),'exit_code':r.returncode,'seconds':time.time()-began});save();print('END',name,r.returncode,flush=True);assert r.returncode==0,name
window=json.loads((O/'forensic/window.json').read_text());end=window['end'];roots={'released':R/'install/models/mlx-community/Qwen3.8-27B-4bit','selected':O/'model-assemblies/selected'}
for label,root in roots.items():run('forensic-'+label,[O/'native/rejection-forensic',O/'native/splash.metallib',root,O/f'forensic-{label}-protocol.json'])
for label,root in roots.items():run('forced-'+label,[R/'build/engine-tests/teacher-logits',R/'build/splash.metallib',root,O/'forensic/forced.u32',O/f'forensic/forced-{label}','--window',f'{end}:128','--kv-format','int8','--state-format','fp32'])
state['active']='complete';state['finished_utc']=time.time();save();print('FORENSICS COMPLETE',flush=True)

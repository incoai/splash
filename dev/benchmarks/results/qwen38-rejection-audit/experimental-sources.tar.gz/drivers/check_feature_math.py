"""Independent CPU check of captured hidden-row alignment and deployed AF4 selector scores."""
from pathlib import Path
import json,struct,numpy as np,sys
R=Path.cwd();O=R/'build/qwen38-rejection-audit';W=Path('/private/tmp/splash-qwen38-rejection-audit');sys.path.insert(0,str(W));from dev.benchmarks import draft_replay
f=R/'install/models/mlx-community/Qwen3.8-27B-4bit/draft/model.safetensors'
with f.open('rb') as stream:
 n=struct.unpack('<Q',stream.read(8))[0];header=json.loads(stream.read(n));offset=8+n

def tensor(name):
 d=header[name];assert d['dtype']=='BF16';return np.memmap(f,dtype='<u2',mode='r',offset=offset+d['data_offsets'][0],shape=tuple(d['shape']))
def widen(a):return (np.array(a,dtype=np.uint32)<<16).view(np.float32)
def bf16(a):
 u=np.asarray(a,dtype=np.float32).view(np.uint32);return ((u+0x7fff+((u>>16)&1))>>16).astype(np.uint16)
def away(x):
 v=np.trunc(x);rem=x-v;return v+np.where(rem>=.5,np.float32(1),np.where(rem<=-.5,np.float32(-1),np.float32(0)))
def quantized(w):
 x=widen(w).reshape(w.shape[0],-1,64);low=x.min(-1,keepdims=True);high=np.maximum(0,x.max(-1,keepdims=True));lower=np.abs(low)>np.abs(high);step=np.maximum((high-low)/np.float32(15),np.float32(1e-7));step=np.where(lower,step,-step);edge=np.where(lower,low,high);q0=away(edge/step);step=np.where(q0!=0,edge/np.where(q0!=0,q0,np.float32(1)),step);bias=np.where(q0!=0,edge,np.float32(0));codes=np.clip(away((x-bias)/step),0,15);return (codes*widen(bf16(step))+widen(bf16(bias))).reshape(w.shape)
Wq=quantized(tensor('candidate_selector.hidden_projection.weight'));A=tensor('candidate_selector.predecessor_codebook');B=tensor('candidate_selector.successor_codebook')
source=O/'reader-batch-control.jsonl';meta,records=draft_replay.read_capture(source);hidden=np.memmap(str(source)+'.hidden.bf16',dtype='<u2',mode='r',shape=(len(records),8,5120))
errors=[];matches=0;total=0
for index,row in enumerate(records):
 x=widen(hidden[index]).astype(np.float64);z=widen(bf16(x@Wq.astype(np.float64).T)).astype(np.float64);c=np.array(row['candidates']).reshape(7,16)
 for pos in range(7):
  prev=np.array([row['output_tokens'][0]]) if pos==0 else c[pos-1];before=widen(A[prev]).astype(np.float64);after=widen(B[c[pos]]).astype(np.float64)
  expected=(before*z[pos+1])@after.T;native=np.array(row['edges'][pos]).reshape(len(prev),16);errors.extend((expected-native).ravel().tolist());matches+=np.sum(np.argmax(expected+np.array(row['unary']).reshape(7,16)[pos],axis=1)==np.argmax(native+np.array(row['unary']).reshape(7,16)[pos],axis=1));total+=len(prev)
error=np.array(errors);report={'rows_checked':len(records),'native_edges':len(errors),'edge_RMSE':float(np.sqrt(np.mean(error**2))),'edge_max_abs':float(np.max(np.abs(error))),'conditional_argmax_match':int(matches),'conditional_argmax_count':total,'method':'original BF16 H weight -> loader-equivalent group64 AF4 -> captured normalized BF16 h -> BF16 gate; F64 CPU edge sums vs F32 Metal reductions; candidate position uses hidden row position+1'}
assert report['edge_RMSE']<.01,report
(O/'feature-math-validation.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))

from pathlib import Path
import hashlib,json,subprocess,struct
R=Path.cwd();O=R/'build/qwen38-rejection-audit';W=Path('/private/tmp/splash-qwen38-rejection-audit');B=O/'native'
s=(W/'dev/benchmarks/rejection_policy_audit.mm').read_text();s=s.replace('raw[0].data()+uint64_t{pos}*vocabulary),vocabulary*sizeof(float)','raw[0].data()),8ULL*vocabulary*sizeof(float)');assert 'policy.write(reinterpret_cast<const char *>(raw[0].data()),8ULL*vocabulary*sizeof(float))' in s
p=W/'dev/benchmarks/rejection_forensic.mm';p.write_text(s);files=['runtime/model/Runtime.cpp','runtime/model/RuntimeInstrumentation.hpp','dev/benchmarks/decode_profile.mm','dev/benchmarks/rejection_forensic.mm'];h=hashlib.sha256(b''.join((W/f).read_bytes() for f in files)).hexdigest()
cmd=['xcrun','-sdk','macosx','clang++','-std=c++20','-O3','-Wall','-Wextra','-Werror','-fobjc-arc','-I'+str(W/'runtime'),'-I'+str(W/'dev'),'-mmacosx-version-min=26.4','-DSPLASH_AUDIT_SOURCE_ID="'+h+'"',str(p),str(B/'RuntimeInstrumented.o'),str(R/'build/engine/metal/MetalBackendInstrumented.o'),str(R/'build/engine/libsplash.a'),'-framework','Foundation','-framework','Metal','-framework','IOKit','-framework','IOSurface','-o',str(B/'rejection-forensic')];subprocess.run(cmd,check=True)
(O/'forensic-build.json').write_text(json.dumps({'source_sha256':h,'files':{f:hashlib.sha256((W/f).read_bytes()).hexdigest() for f in files},'binary_sha256':hashlib.sha256((B/'rejection-forensic').read_bytes()).hexdigest(),'raw_sidecar':'8x248320 F32 logits per policy_record; rows past retained are not a correct-prefix oracle'},indent=2)+'\n')
primary=json.loads((O/'protocol.json').read_text());bad=json.loads((O/'forensic-cases.json').read_text())[0];case=next(c for c in primary['cases'] if c['id']==bad['id']);(O/'forensic').mkdir(exist_ok=True)
for label in ['released','selected']:
 c={**case,'capture_policy':True,'capture_hidden':False,'output_file':str(O/'forensic'/f'{label}.jsonl')}
 (O/f'forensic-{label}-protocol.json').write_text(json.dumps({**primary,'method':'forensic full raw logits, correct-prefix rows only','cases':[c]},indent=2,ensure_ascii=False)+'\n')
records=[json.loads(x) for x in Path(case['output_file']).read_text().splitlines()][1:-1];ids=list(struct.unpack('<'+'I'*case['prompt_tokens'],Path(case['prompt_file']).read_bytes()))
continuation=[t for row in records for t in row['output_tokens']];ids+=continuation;end=case['prompt_tokens']+160;assert len(ids)>end
(O/'forensic/forced.u32').write_bytes(struct.pack('<'+'I'*len(ids),*ids));(O/'forensic/window.json').write_text(json.dumps({'end':end,'rows':128,'prompt_tokens':case['prompt_tokens'],'first_output_difference':bad['first_output_difference'],'baseline_continuation_tokens':len(continuation)})+'\n');print('forensic probe built',h)

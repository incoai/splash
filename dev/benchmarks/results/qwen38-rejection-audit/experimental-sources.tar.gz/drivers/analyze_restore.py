from pathlib import Path
import hashlib,json,math,sys
import numpy as np
O=Path(__file__).resolve().parent;sys.path.insert(0,'/private/tmp/splash-qwen38-rejection-audit');from dev.benchmarks import draft_replay,dflash_context_compare
pro=json.loads((O/'restore-protocol.json').read_text());groups={}
for c in pro['cases']:
 key=(c['family'],c['context']);groups.setdefault(key,{})['restore' if c['restore_prefix'] else 'materialize']=c
results=[]
for key,pair in sorted(groups.items()):
 a,b=pair['materialize'],pair['restore'];aa=draft_replay.read_capture(a['output_file']);bb=draft_replay.read_capture(b['output_file']);assert aa[0]['thinking']==bb[0]['thinking'] is False
 result=dflash_context_compare.compare(aa,bb);am,ar=aa;bm,br=bb
 ah=np.memmap(a['output_file']+'.hidden.bf16',dtype='<u2',mode='r',shape=(len(ar),8,5120));bh=np.memmap(b['output_file']+'.hidden.bf16',dtype='<u2',mode='r',shape=(len(br),8,5120))
 lookup={(r['position'],r['context_sha256']):(i,r) for i,r in enumerate(br)};drift=[]
 for i,row in enumerate(ar):
  other=lookup.get((row['position'],row['context_sha256']))
  if other is None:continue
  j,_=other;x=(ah[i].astype(np.uint32)<<16).view(np.float32);y=(bh[j].astype(np.uint32)<<16).view(np.float32);delta=x.astype(np.float64)-y.astype(np.float64)
  drift.append({'position':row['position'],'hidden_bit_match_fraction':float(np.mean(ah[i]==bh[j])),'hidden_RMS_difference':float(np.sqrt(np.mean(delta**2))),'hidden_relative_L2':float(np.linalg.norm(delta)/np.linalg.norm(x)),'hidden_max_abs':float(np.max(np.abs(delta)))})
 result.update(family=key[0],context=key[1],hidden_matched_context_drift=drift)
 results.append(result)
summary={'scope':'same-prompt materialized-boundary versus snapshot/restore to another state lane;8 development task families, direct mode,2K/8K; compare only identical context+anchor hashes; later matched observations can include restore-induced grouping effects; no memory-architecture or throughput claim','pairs':results,'pair_count':len(results),'matched_context_count':sum(r['matched_contexts'] for r in results),'matched_target_prefixes_all_equal':all(c['target_token_prefix_equal'] for r in results for c in r['comparisons']),'matched_cycles_with_proposal_changes':sum(c['proposed_token_changes']>0 for r in results for c in r['comparisons']),'matched_cycles_with_retained_change':sum(c['retained_left']!=c['retained_right'] for r in results for c in r['comparisons'])}
summary['descriptive_macro_tau_change_pct']=100*(math.exp(np.mean([math.log(r['right_acceptance']['mean_retained_tokens']/r['left_acceptance']['mean_retained_tokens']) for r in results]))-1)
(O/'restore-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({k:v for k,v in summary.items() if k!='pairs'},indent=2))

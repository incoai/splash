"""One-off native-feature selector pilot. Reuses PR551 AF4 QAT; no teacher/backbone training."""
from pathlib import Path
import argparse,collections,hashlib,json,math,os,random,struct,sys,time
import numpy as np
O=Path(__file__).resolve().parent;R=O.parents[1];W=Path('/private/tmp/splash-qwen38-rejection-audit')
sys.path.insert(0,str(W));from dev.benchmarks import draft_replay
from audit_analysis import reached_rows

def widen(x):return (np.asarray(x,dtype=np.uint32)<<16).view(np.float32)
def digest(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()

def source_tensors():
 f=R/'install/models/mlx-community/Qwen3.8-27B-4bit/draft/model.safetensors'
 with f.open('rb') as s:n=struct.unpack('<Q',s.read(8))[0];h=json.loads(s.read(n))
 def get(name):
  d=h[name];assert d['dtype']=='BF16';return np.memmap(f,dtype='<u2',mode='r',offset=8+n+d['data_offsets'][0],shape=tuple(d['shape']))
 return get

def load_case(case):
 path=Path(case['output_file']);m,rows=draft_replay.read_capture(path);draft_replay.summarize(m,rows)
 assert m['family']==case['family'] and m['split']==case['split'] and m['prompt_sha256']==case['prompt_sha256']
 hidden=np.memmap(str(path)+'.hidden.bf16',dtype='<u2',mode='r',shape=(len(rows),8,5120))
 assert Path(str(path)+'.hidden.bf16').stat().st_size==len(rows)*8*5120*2
 return rows,hidden

def dataset():
 protocol=json.loads((O/'protocol.json').read_text());summary={}
 for split in ['development','validation']:
  arrays=collections.defaultdict(list);coverage=collections.Counter();case_ids=[]
  for case_index,case in enumerate(protocol['cases']):
   if case['split']!=split:continue
   case_ids.append(case['id']);rows,h=load_case(case)
   for ri,row in enumerate(rows):
    candidates=np.asarray(row['candidates'],dtype=np.int64).reshape(7,16);unary=np.asarray(row['unary'],dtype=np.float32).reshape(7,16)
    for pos in reached_rows(row):
     target=row['target_tokens'][pos];coverage['reached']+=1
     hits=np.flatnonzero(candidates[pos]==target)
     if not len(hits):coverage['unsupported']+=1;continue
     prev=row['output_tokens'][0] if pos==0 else row['target_tokens'][pos-1]
     previous_index=0 if pos==0 else int(np.flatnonzero(candidates[pos-1]==prev)[0])
     edges=np.asarray(row['edges'][pos],dtype=np.float32).reshape(-1,16)[previous_index]
     arrays['hidden'].append(np.array(h[ri,pos+1]));arrays['unary'].append(unary[pos]);arrays['native_scores'].append(unary[pos]+edges)
     arrays['candidates'].append(candidates[pos]);arrays['predecessor'].append(prev);arrays['label'].append(int(hits[0]));arrays['position'].append(pos);arrays['case'].append(case_index)
  result={k:np.asarray(v) for k,v in arrays.items()};counts=collections.Counter(result['case'].tolist());weights=np.asarray([1/counts[i] for i in result['case']],dtype=np.float64);weights/=weights.sum();result['sample_probability']=weights
  np.savez(O/f'frozen-{split}.npz',**result)
  summary[split]={'examples':len(result['label']),'cases':len(case_ids),'case_ids':case_ids,'coverage':dict(coverage),'dataset_sha256':digest(O/f'frozen-{split}.npz')}
 (O/'frozen-dataset.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({k:{x:y for x,y in v.items() if x!='case_ids'} for k,v in summary.items()},indent=2))

def val_cycles():
 protocol=json.loads((O/'protocol.json').read_text());out=[]
 for case in protocol['cases']:
  if case['split']!='validation':continue
  rows,h=load_case(case);continuation={}
  for row in rows:
   for j,t in enumerate(row['output_tokens']):continuation[row['position']+j]=t
   for j,t in enumerate(row['target_tokens']):continuation[row['position']+j+1]=t
  for ri,row in enumerate(rows):
   if not all(row['position']+j+1 in continuation for j in range(7)):continue
   cs=np.asarray(row['candidates'],dtype=np.int64).reshape(7,16);edges=np.empty((7,16,16),dtype=np.float32);prev=np.empty((7,16),dtype=np.int64)
   for pos in range(7):
    e=np.asarray(row['edges'][pos],dtype=np.float32).reshape(-1,16);edges[pos]=e if pos else e[0][None,:];prev[pos]=cs[pos-1] if pos else row['output_tokens'][0]
   out.append({'case':case['id'],'hidden':np.array(h[ri,1:]),'candidates':cs,'predecessors':prev,'edges':edges,'unary':np.asarray(row['unary'],dtype=np.float32).reshape(7,16),'truth':np.asarray([continuation[row['position']+j+1] for j in range(7)])})
 return out

def train():
 import torch
 import torch.nn.functional as F
 torch.set_num_threads(2)
 sys.path.insert(0,'/private/tmp/splash-dflash-543');from draft_training.quantization import fake_affine4
 plan=json.loads((O/'training-plan.json').read_text());get=source_tensors();base_bits=np.array(get('candidate_selector.hidden_projection.weight'));base=torch.tensor(widen(base_bits),device='mps')
 before=torch.tensor(widen(get('candidate_selector.predecessor_codebook')),device='mps');after=torch.tensor(widen(get('candidate_selector.successor_codebook')),device='mps')
 assert torch.backends.mps.is_available()
 data=np.load(O/'frozen-development.npz');x=torch.tensor(widen(data['hidden']),device='mps');gold=torch.tensor(data['label'],device='mps',dtype=torch.long)
 native=torch.tensor(data['native_scores'],device='mps');pred=before[torch.tensor(data['predecessor'],device='mps',dtype=torch.long)]
 cand=after[torch.tensor(data['candidates'],device='mps',dtype=torch.long)];position=torch.tensor(data['position'],device='mps',dtype=torch.float32);probs=data['sample_probability'];n=len(probs)
 cycles=val_cycles();result=[];dest=O/'selector-fits';dest.mkdir(exist_ok=True)
 # Validation batches stay small; selected checkpoint is evaluated with deployed AF4 in both arms.
 @torch.no_grad()
 def evaluate(weight):
  wnew=fake_affine4(weight);wold=fake_affine4(base);scores=collections.defaultdict(list)
  for start in range(0,len(cycles),32):
   batch=cycles[start:start+32];hx=torch.tensor(widen(np.asarray([r['hidden'] for r in batch])),device='mps')
   dz=F.linear(hx,wnew).to(torch.bfloat16).float()-F.linear(hx,wold).to(torch.bfloat16).float()
   ids=torch.tensor(np.asarray([r['candidates'] for r in batch]),device='mps',dtype=torch.long);pi=torch.tensor(np.asarray([r['predecessors'] for r in batch]),device='mps',dtype=torch.long)
   old=torch.tensor(np.asarray([r['edges'] for r in batch]),device='mps');u=torch.tensor(np.asarray([r['unary'] for r in batch]),device='mps')
   delta=torch.einsum('npad,npbd->npab',before[pi]*dz.unsqueeze(-2),after[ids]);edges=old+delta
   previous=torch.zeros(len(batch),device='mps',dtype=torch.long);out=[];rr=torch.arange(len(batch),device='mps')
   for pos in range(7):
    pick=(u[:,pos]+edges[rr,pos,previous]).argmax(-1);out.append(ids[rr,pos,pick]);previous=pick
   chosen=torch.stack(out,1).cpu().numpy()
   for i,row in enumerate(batch):
    bad=np.flatnonzero(chosen[i]!=row['truth']);scores[row['case']].append(int(bad[0])+1 if len(bad) else 8)
  per_case={k:float(np.mean(v)) for k,v in scores.items()};return {'macro_tau_proxy':float(np.mean(list(per_case.values()))),'per_case':per_case,'complete_reference_cycles':len(cycles),'scope':'anchored fixed-continuation proxy at original baseline cycle starts; not a new rollout or throughput'}
 initial=evaluate(base)
 (O/'selector-initial-proxy.json').write_text(json.dumps(initial,indent=2)+'\n')
 # Baseline checkpoint bytes are copied unchanged, not reconstructed through arithmetic.
 (dest/'released-hidden-projection.bf16').write_bytes(base_bits.tobytes())
 for forward in ['bf16','af4']:
  for lr in plan['learning_rates']:
   seed=plan['seed'];torch.manual_seed(seed);rng=np.random.default_rng(seed)
   rank=plan['rank'];a=torch.nn.Parameter(torch.randn(rank,5120,device='cpu').to('mps')*.01);b=torch.nn.Parameter(torch.zeros(256,rank,device='mps'))
   optimizer=torch.optim.AdamW([a,b],lr=lr,weight_decay=.01);name=f'{forward}-lr{lr:g}';history=[];started=time.time()
   def projected(inputs,w):
    prepared=fake_affine4(w) if forward=='af4' else w.to(torch.bfloat16).float()
    return F.linear(inputs,prepared).to(torch.bfloat16).float()
   with torch.no_grad():baseline_gate=projected(x,base)
   for step in range(plan['steps_per_fit']+1):
    weight=base+b@a/rank
    if step in plan['validation_steps']:
     record={'step':step,'validation':evaluate(weight)};history.append(record)
     tensor=weight.detach().to(torch.bfloat16).cpu().view(torch.uint16).numpy()
     if step==0:assert np.array_equal(tensor,base_bits),(forward,lr,'zero update changed tensor')
     filename=f'{name}-step{step}.bf16';(dest/filename).write_bytes(tensor.tobytes());record['tensor_file']=filename;record['tensor_sha256']=digest(dest/filename)
     print(name,'step',step,'validation proxy',record['validation']['macro_tau_proxy'],'seconds',round(time.time()-started,2),flush=True)
    if step==plan['steps_per_fit']:break
    ids_np=rng.choice(n,plan['batch_size'],replace=True,p=probs);idx=torch.tensor(ids_np,device='mps',dtype=torch.long)
    dz=projected(x[idx],weight)-baseline_gate[idx];logits=native[idx]+torch.einsum('bd,bkd->bk',pred[idx]*dz,cand[idx])
    logp=F.log_softmax(logits,dim=-1);ce=F.nll_loss(logp,gold[idx],reduction='none');kl=F.kl_div(logp,F.softmax(native[idx],dim=-1),reduction='none').sum(-1)
    loss=((ce+.25*kl)*torch.exp(-position[idx]/8)).mean();assert torch.isfinite(loss).item()
    optimizer.zero_grad(set_to_none=True);loss.backward();torch.nn.utils.clip_grad_norm_([a,b],1.0,error_if_nonfinite=True);optimizer.step()
   result.append({'name':name,'forward':forward,'learning_rate':lr,'steps':plan['steps_per_fit'],'history':history,'seconds':time.time()-started})
   (O/'selector-training.json').write_text(json.dumps({'plan':plan,'torch':torch.__version__,'device':'mps','dataset_sha256':digest(O/'frozen-development.npz'),'validation_dataset_sha256':digest(O/'frozen-validation.npz'),'initial':initial,'trials':result},indent=2)+'\n')
 # Freeze the candidate before any final test inspection. No candidate if validation proxy does not improve.
 candidates=[(h['validation']['macro_tau_proxy'],h['step'],trial['name'],h) for trial in result for h in trial['history'] if h['step']>0]
 best=max(candidates,key=lambda row:(row[0],-row[1]));selection={'initial_proxy':initial['macro_tau_proxy'],'candidate_proxy':best[0],'improves_proxy':best[0]>initial['macro_tau_proxy'],'trial':best[2],'step':best[1],'tensor_file':str(dest/best[3]['tensor_file']),'tensor_sha256':best[3]['tensor_sha256'],'test_used':False,'scope':'candidate selection only; native rollout qualification still required'}
 (O/'selector-selection.json').write_text(json.dumps(selection,indent=2)+'\n');print(json.dumps(selection,indent=2),flush=True)

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('phase',choices=['dataset','train']);a=p.parse_args();dataset() if a.phase=='dataset' else train()

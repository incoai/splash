from pathlib import Path
import argparse,collections,hashlib,json,math,random,statistics,sys
O=Path(__file__).resolve().parent;W=Path('/private/tmp/splash-qwen38-rejection-audit');sys.path.insert(0,str(W));from dev.benchmarks import draft_replay

def reached_rows(row):
 passed=min(row['accepted'],row['retained']-1)
 rejected=(row['accepted']<row['verify_rows']-1 and row['retained']==row['accepted']+1 and len(row['output_tokens'])==row['retained'] and row['target_tokens'][row['accepted']]!=row['proposed'][row['accepted']])
 return range(passed+int(rejected))

def case_report(case):
 p=Path(case['output_file']);meta,rows=draft_replay.read_capture(p);report=draft_replay.summarize(meta,rows)
 for key in ['id','family','domain','split','thinking','reasoning_effort','prompt_tokens','prompt_sha256']:
  assert meta['audit_case' if key=='id' else key]==case[key],(case['id'],key)
 assert meta['source_id']==json.loads((O/'batch-build.json').read_text())['source_sha256']
 assert p.with_name(p.name+'.hidden.bf16').stat().st_size==len(rows)*8*5120*2
 assert sum(len(reached_rows(row)) for row in rows)==sum(r['reached'] for r in report['conditional_acceptance'])
 all_accepted=sum(r['accepted']>=r['verify_rows']-1 and r['retained']==8 for r in rows)
 return {'id':case['id'],'family':case['family'],'domain':case['domain'],'split':case['split'],'thinking':case['thinking'],'context':case['context'],'prompt_tokens':case['prompt_tokens'],'cycles':len(rows),'tau':report['mean_retained_tokens'],'first_rejections':report['first_rejections'],'fully_accepted_cycles':all_accepted,'conditional_acceptance':report['conditional_acceptance'],'gold_unary_rank_counts_at_selection_miss':report['selection_miss_unary_rank_counts'],'confidence_bins':report['confidence_bins'],'counterfactual':report['counterfactual']}

def aggregate(rows):
 misses=collections.Counter();reached=[0]*7;accepted=[0]*7
 for row in rows:
  misses.update(row['first_rejections'])
  for i,x in enumerate(row['conditional_acceptance']):reached[i]+=x['reached'];accepted[i]+=x['accepted']
 families=collections.defaultdict(list)
 for row in rows:families[row['family']].append(row['tau'])
 return {'cases':len(rows),'families':len(families),'cycles':sum(r['cycles'] for r in rows),'macro_case_tau':statistics.mean(r['tau'] for r in rows),'macro_family_tau':statistics.mean(statistics.mean(v) for v in families.values()),'first_rejections':dict(misses),'selection_share_of_uncensored_first_misses':misses['selection']/(misses['selection']+misses['candidate_recall']) if misses['selection']+misses['candidate_recall'] else None,'conditional_acceptance':[{'position':i+1,'reached':reached[i],'accepted':accepted[i],'rate':accepted[i]/reached[i] if reached[i] else None} for i in range(7)]}

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--include-test',action='store_true');ap.add_argument('--partial',action='store_true');args=ap.parse_args();protocol=json.loads((O/'protocol.json').read_text());reports=[]
 for case in protocol['cases']:
  if case['split']=='test' and not args.include_test:continue
  try:reports.append(case_report(case))
  except (OSError,ValueError,json.JSONDecodeError) as error:
   if not args.partial:raise
 if not reports:raise RuntimeError('no complete cases')
 summary={'scope':'greedy natural rollout; first-rejection diagnosis, not task accuracy or a numerical causal quantization ablation; prompt families are statistical clusters','test_included':args.include_test,'aggregate':aggregate(reports),'strata':{},'cases':reports}
 for domain in sorted({r['domain'] for r in reports}):
  for ctx in ['short','2k','8k']:
   for thinking in [False,True]:
    subset=[r for r in reports if r['domain']==domain and r['context']==ctx and r['thinking']==thinking]
    if subset:summary['strata'][f'{domain}/{ctx}/'+('think' if thinking else 'direct')]=aggregate(subset)
 name='audit-final-summary.json' if args.include_test else 'audit-development-summary.json';(O/name).write_text(json.dumps(summary,indent=2)+'\n')
 print('AUDIT',len(reports),'cases','test included',args.include_test)
 print(json.dumps(summary['aggregate'],indent=2))
 for domain in sorted({r['domain'] for r in reports}):print(domain,json.dumps(aggregate([r for r in reports if r['domain']==domain])))
if __name__=='__main__':main()

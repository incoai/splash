"""Sequential CPU/native/MPS pilot phases; never run two GPU jobs concurrently."""
from pathlib import Path
import hashlib,json,os,subprocess,time,sys
R=Path.cwd();O=R/'build/qwen38-rejection-audit';PY=R/'.venv/bin/python';TRAIN=O/'train-venv/bin/python'
state={'started_utc':time.time(),'phases':[]}
def save():(O/'followup-provenance.json').write_text(json.dumps(state,indent=2)+'\n')
def run(name,cmd,env=None):
 state['active']=name;save();began=time.time();print('START',name,flush=True)
 with (O/(name+'.log')).open('w') as f:r=subprocess.run(list(map(str,cmd)),env=env,stdout=f,stderr=subprocess.STDOUT)
 state['phases'].append({'name':name,'command':list(map(str,cmd)),'seconds':time.time()-began,'exit_code':r.returncode});save();print('END',name,r.returncode,round(time.time()-began,2),flush=True)
 if r.returncode:raise RuntimeError(name+' failed; inspect log')
while True:
 d=json.loads((O/'run-provenance.json').read_text())
 if d['status']!='running':
  if d['status']!='complete':raise RuntimeError('primary audit failed')
  break
 time.sleep(5)
run('audit-development-analysis',[PY,O/'audit_analysis.py'])
run('policy-capture',[O/'native/rejection-policy',O/'native/splash.metallib',R/'install/models/mlx-community/Qwen3.8-27B-4bit',O/'policy-protocol.json'])
run('policy-analysis',[PY,O/'analyze_policy.py'])
run('frozen-dataset-build',[PY,O/'frozen_selector.py','dataset'])
code="""import sys,json,torch,numpy as np
from pathlib import Path
sys.path.insert(0,'build/qwen38-rejection-audit');from frozen_selector import source_tensors,widen
sys.path.insert(0,'/private/tmp/splash-dflash-543');from draft_training.quantization import fake_affine4
torch.set_num_threads(2);assert torch.backends.mps.is_available()
w=torch.tensor(widen(source_tensors()('candidate_selector.hidden_projection.weight')))
a=fake_affine4(w).detach();b=fake_affine4(w.to('mps')).detach().cpu();assert torch.equal(a,b),torch.max(torch.abs(a-b)).item()
Path('build/qwen38-rejection-audit/mps-quantization-parity.json').write_text(json.dumps({'torch':torch.__version__,'device':'mps','weights':w.numel(),'all_weights_exact_cpu_mps':True})+'\\n')
print('all selector weights exact CPU/MPS fake-quant parity')
"""
env=dict(os.environ,PYTORCH_ENABLE_MPS_FALLBACK='0',PYTORCH_MPS_FAST_MATH='0',VECLIB_MAXIMUM_THREADS='2')
run('mps-quantization-check',[TRAIN,'-c',code],env)
run('selector-training',[TRAIN,O/'frozen_selector.py','train'],env)
selection=json.loads((O/'selector-selection.json').read_text());state['selection']=selection;save()
if selection['improves_proxy']:
 run('selector-native-export',[PY,O/'export_selector.py',selection['tensor_file'],'selected'])
 run('selector-native-validation',[O/'native/rejection-audit',O/'native/splash.metallib',O/'model-assemblies/selected',O/'candidate-validation-protocol.json'])
state['active']='complete';state['finished_utc']=time.time();save();print('FOLLOWUP COMPLETE',flush=True)

from pathlib import Path
import hashlib,json,subprocess
R=Path.cwd();W=Path('/private/tmp/splash-qwen38-rejection-audit');O=R/'build/qwen38-rejection-audit';B=O/'native'
files=['runtime/model/Runtime.cpp','runtime/model/RuntimeInstrumentation.hpp','dev/benchmarks/decode_profile.mm','dev/benchmarks/rejection_audit.mm'];digest=hashlib.sha256(b''.join((W/f).read_bytes() for f in files)).hexdigest()
cmd=['xcrun','-sdk','macosx','clang++','-std=c++20','-O3','-Wall','-Wextra','-Werror','-fobjc-arc','-I'+str(W/'runtime'),'-I'+str(W/'dev'),'-mmacosx-version-min=26.4','-DSPLASH_AUDIT_SOURCE_ID="'+digest+'"',str(W/'dev/benchmarks/rejection_audit.mm'),str(B/'RuntimeInstrumented.o'),str(R/'build/engine/metal/MetalBackendInstrumented.o'),str(R/'build/engine/libsplash.a'),'-framework','Foundation','-framework','Metal','-framework','IOKit','-framework','IOSurface','-o',str(B/'rejection-audit')]
subprocess.run(cmd,check=True)
(O/'batch-build.json').write_text(json.dumps({'source_sha256':digest,'files':{f:hashlib.sha256((W/f).read_bytes()).hexdigest() for f in files},'command':cmd,'binary_sha256':hashlib.sha256((B/'rejection-audit').read_bytes()).hexdigest()},indent=2)+'\n');print('batch native audit built',digest)

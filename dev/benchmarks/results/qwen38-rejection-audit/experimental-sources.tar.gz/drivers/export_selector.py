"""Private COW model assembly; replace one BF16 selector tensor, preserve all other source bytes."""
from pathlib import Path
import argparse,copy,hashlib,json,os,shutil,struct,subprocess
R=Path.cwd();O=R/'build/qwen38-rejection-audit';SOURCE=R/'install/models/mlx-community/Qwen3.8-27B-4bit'
def hfile(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def outside(p,start,end):
 h=hashlib.sha256()
 with p.open('rb') as f:
  remaining=start
  while remaining:
   block=f.read(min(8*1024*1024,remaining));assert block;h.update(block);remaining-=len(block)
  f.seek(end)
  for block in iter(lambda:f.read(8*1024*1024),b''):h.update(block)
 return h.hexdigest()
def assemble(tensor,label):
 dest=O/'model-assemblies'/label;dest.mkdir(parents=True,exist_ok=True);src=(SOURCE/'draft/model.safetensors').resolve();weight=dest/'draft/model.safetensors';weight.parent.mkdir(exist_ok=True)
 with src.open('rb') as f:n=struct.unpack('<Q',f.read(8))[0];header=json.loads(f.read(n))
 spec=header['candidate_selector.hidden_projection.weight'];assert spec['dtype']=='BF16' and spec['shape']==[256,5120]
 start,end=[8+n+x for x in spec['data_offsets']];assert end-start==256*5120*2
 replacement=Path(tensor).read_bytes();assert len(replacement)==end-start
 original_record=json.loads((SOURCE/'model.json').read_text());old_hash=original_record['files']['draft/model.safetensors']['digest'];assert hfile(src)==old_hash
 for name in ['config.json','target','vision','tokenizer']:
  p=dest/name
  if not p.exists():p.symlink_to((SOURCE/name).resolve(),target_is_directory=(SOURCE/name).is_dir())
 config=dest/'draft/config.json'
 if not config.exists():config.symlink_to((SOURCE/'draft/config.json').resolve())
 if weight.exists():raise FileExistsError('Do not overwrite an existing experimental model assembly: '+str(weight))
 cp=subprocess.run(['/bin/cp','-c',str(src),str(weight)],capture_output=True,text=True)
 if cp.returncode:shutil.copyfile(src,weight)
 assert not weight.is_symlink() and weight.stat().st_ino!=src.stat().st_ino and weight.stat().st_nlink==1
 with weight.open('r+b') as f:f.seek(start);f.write(replacement);f.flush();os.fsync(f.fileno())
 outside_src=outside(src,start,end);assert outside(weight,start,end)==outside_src
 record=copy.deepcopy(original_record);st=weight.stat();new_hash=hfile(weight)
 record['files']['draft/model.safetensors']={'path':str(weight.resolve()),'bytes':st.st_size,'ctime_ns':st.st_ctime_ns,'mtime_ns':st.st_mtime_ns,'digest':new_hash}
 record['sources']['draft']={'repo':'local/qwen38-selector-'+label,'revision':hashlib.sha256(replacement).hexdigest(),'base_repo':original_record['sources']['draft']['repo'],'base_revision':original_record['sources']['draft']['revision']}
 record['local_experiment']={'label':label,'changed_tensor':'candidate_selector.hidden_projection.weight','tensor_sha256':hashlib.sha256(replacement).hexdigest(),'all_other_draft_bytes_sha256':outside_src}
 (dest/'model.json').write_text(json.dumps(record,indent=2)+'\n');assert hfile(src)==old_hash
 manifest={'model_root':str(dest.resolve()),'source_draft_sha256':old_hash,'export_draft_sha256':new_hash,'tensor_sha256':record['local_experiment']['tensor_sha256'],'all_non_selector_draft_bytes_equal':True,'original_source_unchanged':True,'target_tokenizer_vision':'original read-only source symlinks','same_geometry':True}
 (dest/'experiment.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps(manifest,indent=2));return dest
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('tensor',type=Path);p.add_argument('label');a=p.parse_args();assemble(a.tensor,a.label)

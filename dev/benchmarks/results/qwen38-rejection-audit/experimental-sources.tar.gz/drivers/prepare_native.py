from pathlib import Path
import subprocess,hashlib,json,shutil
R=Path.cwd();W=Path('/private/tmp/splash-qwen38-rejection-audit');O=R/'build/qwen38-rejection-audit';B=O/'native';B.mkdir(exist_ok=True)
old=Path('/private/tmp/splash-dflash-548')
s=(R/'runtime/model/Runtime.cpp').read_text();extra=(old/'runtime/model/Runtime.cpp').read_text();a=extra.index('RuntimeInstrumentation::DraftSelection RuntimeInstrumentation::lastDraftSelection(');b=extra.index('RuntimeInstrumentation::LaneTables RuntimeInstrumentation::laneTables',a);s=s.replace('RuntimeInstrumentation::LaneTables RuntimeInstrumentation::laneTables',extra[a:b]+'RuntimeInstrumentation::LaneTables RuntimeInstrumentation::laneTables');(W/'runtime/model/Runtime.cpp').write_text(s)
s=(R/'runtime/model/RuntimeInstrumentation.hpp').read_text();extra=(old/'runtime/model/RuntimeInstrumentation.hpp').read_text();a=extra.index('  // Shared scratch');b=extra.index('  // The GPU tables',a);s=s.replace('  // The GPU tables',extra[a:b]+'  // The GPU tables');(W/'runtime/model/RuntimeInstrumentation.hpp').write_text(s)
subprocess.run(['git','add','runtime/model/Runtime.cpp','runtime/model/RuntimeInstrumentation.hpp'],cwd=W,check=True)
if not (W/'.venv').exists():(W/'.venv').symlink_to(R/'.venv',target_is_directory=True)
base=['xcrun','-sdk','macosx','clang++','-std=c++20','-O3','-Wall','-Wextra','-Werror','-I'+str(W/'runtime'),'-I'+str(W/'dev'),'-mmacosx-version-min=26.4']
subprocess.run(base+['-DSPLASH_RUNTIME_INSTRUMENTATION=1','-c',str(W/'runtime/model/Runtime.cpp'),'-o',str(B/'RuntimeInstrumented.o')],check=True)
subprocess.run(base+['-fobjc-arc',str(W/'dev/benchmarks/decode_profile.mm'),str(B/'RuntimeInstrumented.o'),str(R/'build/engine/metal/MetalBackendInstrumented.o'),str(R/'build/engine/libsplash.a'),'-framework','Foundation','-framework','Metal','-framework','IOKit','-framework','IOSurface','-o',str(B/'decode-profile')],check=True)
for name in ['splash.metallib','host-step.metallib']:shutil.copy2(R/'build'/name,B/name)
# The production preprocessing must exclude every new accessor.
pre=['xcrun','-sdk','macosx','clang++','-std=c++20','-E','-P','-mmacosx-version-min=26.4']
a=subprocess.run(pre+['-I'+str(R/'runtime'),str(R/'runtime/model/Runtime.cpp')],check=True,capture_output=True).stdout
b=subprocess.run(pre+['-I'+str(W/'runtime'),'-ffile-prefix-map='+str(W)+'='+str(R),str(W/'runtime/model/Runtime.cpp')],check=True,capture_output=True).stdout
assert a==b,'production preprocessing changed'
(O/'native-build.json').write_text(json.dumps({'production_preprocessing_bitwise_equal':True,'production_preprocessed_sha256':hashlib.sha256(a).hexdigest(),'combined_production_base':'950ffef9','diagnostics_source':'PR550 ef0e95d4 +PR556 b4006b12 development-only accessors','files':{str(f.relative_to(W)):hashlib.sha256(f.read_bytes()).hexdigest() for f in [W/'runtime/model/Runtime.cpp',W/'runtime/model/RuntimeInstrumentation.hpp',W/'dev/benchmarks/decode_profile.mm']},'binary_sha256':hashlib.sha256((B/'decode-profile').read_bytes()).hexdigest()},indent=2)+'\n')
print('native diagnostic build and production parity PASS')

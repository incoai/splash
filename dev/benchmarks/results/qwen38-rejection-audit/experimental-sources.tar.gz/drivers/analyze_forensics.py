from pathlib import Path
import hashlib,json,sys
import numpy as np
O=Path(__file__).resolve().parent;sys.path.insert(0,'/private/tmp/splash-qwen38-rejection-audit');from dev.benchmarks import draft_replay
bad=json.loads((O/'forensic-cases.json').read_text())[0];protocol=json.loads((O/'protocol.json').read_text());case=next(c for c in protocol['cases'] if c['id']==bad['id']);candidate=next(c for c in json.loads((O/'final-test-protocol.json').read_text())['cases'] if c['id']==bad['id'])
records={};outputs={};source={};arrays={};faithful={}
for label,ref in [('released',case),('selected',candidate)]:
 m,r=draft_replay.read_capture(O/f'forensic/{label}.jsonl');draft_replay.summarize(m,r);_,original=draft_replay.read_capture(ref['output_file']);keys=['proposed','candidates','unary','edges','confidence','accepted','retained','target_tokens','output_tokens','context_sha256'];same=len(r)==len(original) and all(all(a[k]==b[k] for k in keys) for a,b in zip(r,original,strict=True));faithful[label]=same;assert same,(label,'full-logit instrumentation changed rollout')
 records[label]=r;outputs[label]=[t for row in r for t in row['output_tokens']];source[label]=m
 arrays[label]=np.memmap(O/f'forensic/{label}.jsonl.policy.f32',dtype='<f4',mode='r').reshape(-1,8,248320)
a,b=outputs['released'],outputs['selected'];different=next(i for i,(x,y) in enumerate(zip(a,b)) if x!=y);assert different==bad['first_output_difference'];absolute=case['prompt_tokens']+different;selected={}
for label in records:
 for r in records[label]:
  if r['position']<absolute<=r['position']+r['retained']:
   row=absolute-r['position']-1;assert row<r['retained'] and row<=r['accepted'];z=np.array(arrays[label][r['policy_record'],row],dtype=np.float64);token=outputs[label][different];assert int(z.argmax())==token and r['target_tokens'][row]==token
   # The model's actual input before this prediction is the shared true prefix.
   prefix=outputs[label][:r['position']-case['prompt_tokens']]+[r['output_tokens'][0]]+r['proposed'][:row]
   assert prefix==outputs[label][:different]
   ids=np.argsort(-z,kind='stable')[:5];selected[label]={'cycle':r['cycle'],'verify_start_position':r['position'],'logit_row':row,'retained':r['retained'],'top5_token_ids':ids.tolist(),'top5_logits':z[ids].tolist(),'top1_margin':float(z[ids[0]]-z[ids[1]]),'logits':z};break
 assert label in selected
x=selected['released'].pop('logits');y=selected['selected'].pop('logits');delta=(y-y.mean())-(x-x.mean())
window=json.loads((O/'forensic/window.json').read_text());paths={k:O/f"forensic/forced-{k}-{window['end']}.f32" for k in ['released','selected']}
def h(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
sha={k:h(v) for k,v in paths.items()};equal=sha['released']==sha['selected'];assert equal,'same forced schedule changed target logits'
result={'case':case['id'],'first_output_difference':different,'absolute_target_position':absolute,'common_prefix_tokens':different,'raw_capture_reproduces_original_rollouts_exactly':faithful,'same_correct_prefix_before_difference':True,'predictions':selected,'centered_logit_difference_RMSE':float(np.sqrt(np.mean(delta**2))),'centered_logit_difference_max_abs':float(np.max(np.abs(delta))),'fixed_schedule_teacher_forced_logits_bitwise_equal':equal,'fixed_schedule_logits_sha256':sha,'fixed_schedule_rows':129,'fixed_schedule_vocabulary':248320,'interpretation':'Unchanged target weights produce bitwise-equal target logits on an identical forced prefix/verification schedule. Natural rollouts reached the same correct prefix through different draft acceptance schedules and produced different logits at a close argmax. This is consistent with finite-precision scheduling sensitivity; it is not a proven kernel-level root cause, a task-quality assessment, or permission to waive greedy-output qualification.'}
(O/'forensic-analysis.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))

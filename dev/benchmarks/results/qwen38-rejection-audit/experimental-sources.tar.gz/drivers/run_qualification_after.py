from pathlib import Path
import json,subprocess,time,os
R=Path.cwd();O=R/'build/qwen38-rejection-audit'
while True:
 
 try:d=json.loads((O/'forensic-provenance.json').read_text())
 except (FileNotFoundError,json.JSONDecodeError):time.sleep(1);continue
 if d['active']=='complete':break
 time.sleep(5)
cmd=[str(R/'.venv/bin/python'),str(O/'qualify_m16.py'),'--model','mlx-community/Qwen3.8-27B-4bit','--model-root',str(R/'install/models/mlx-community/Qwen3.8-27B-4bit'),'--max-context','32768','--max-memory','34G','--max-cache-disk','0','--disable-ane','--state-format','fp32']
with (O/'m16-qualification-driver.log').open('w') as log:r=subprocess.run(cmd,env=dict(os.environ,PYTHONPATH=str(R)),stdout=log,stderr=subprocess.STDOUT)
(O/'qualification-exit.json').write_text(json.dumps({'exit_code':r.returncode,'command':cmd})+'\n');raise SystemExit(r.returncode)

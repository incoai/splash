from pathlib import Path
import json,subprocess,time
R=Path.cwd();O=R/'build/qwen38-rejection-audit'
while not (O/'m16-qualification/summary.json').exists():
 time.sleep(5)
with (O/'forensic-analysis.log').open('w') as log:r=subprocess.run([str(R/'.venv/bin/python'),str(O/'analyze_forensics.py')],stdout=log,stderr=subprocess.STDOUT)
(O/'forensic-analysis-exit.json').write_text(json.dumps({'exit_code':r.returncode})+'\n');raise SystemExit(r.returncode)

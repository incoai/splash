from pathlib import Path
import json,os,subprocess,time,shutil
R=Path.cwd();O=R/'build/qwen38-rejection-audit'
for k in os.environ:
 if k.startswith('SPLASH_ARCH_'):raise RuntimeError('Architecture experiment flags must be absent')
def snapshot():
 d={'utc':time.time()}
 for key,cmd in {'power':['pmset','-g','batt'],'thermal':['pmset','-g','therm'],'pressure':['sysctl','kern.memorystatus_vm_pressure_level'],'swap':['sysctl','vm.swapusage']}.items():d[key]=subprocess.run(cmd,capture_output=True,text=True).stdout
 return d
before=snapshot();assert 'AC Power' in before['power']
(O/'pilot-captures').mkdir(exist_ok=True)
for case in json.loads((O/'pilot-suite.json').read_text())['cases']:
 for suffix in ['', '.hidden.bf16']:
  f=Path(case['output_file']+suffix);shutil.copy2(f,O/'pilot-captures'/f.name)
cmd=[str(O/'native/rejection-audit'),str(O/'native/splash.metallib'),str(R/'install/models/mlx-community/Qwen3.8-27B-4bit'),str(O/'protocol.json')]
state={'command':cmd,'before':before,'completed':[],'status':'running'};(O/'run-provenance.json').write_text(json.dumps(state,indent=2)+'\n')
with (O/'native-audit.log').open('w') as log:
 process=subprocess.Popen(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,bufsize=1)
 for line in process.stdout:
  log.write(line);log.flush();print(line.rstrip(),flush=True)
  if line.startswith('AUDIT '):
   state['completed'].append({'line':line.strip(),'utc':time.time()})
   if len(state['completed'])%8==0:state.setdefault('snapshots',[]).append(snapshot())
   (O/'run-provenance.json').write_text(json.dumps(state,indent=2)+'\n')
 code=process.wait()
state.update(after=snapshot(),exit_code=code,status='complete' if code==0 else 'failed');(O/'run-provenance.json').write_text(json.dumps(state,indent=2)+'\n')
if code:raise SystemExit(code)

#pragma once

#include "metal/abi/KvExtent.h"
#include "model/Runtime.hpp"

#include <cstddef>
#include <cstdint>
#include <optional>
#include <span>
#include <vector>

namespace splash::model {

// What tests impose on a Runtime beyond its serving API. Only the
// instrumented build of Runtime.cpp (SPLASH_RUNTIME_INSTRUMENTATION) defines
// these; production binaries never link it.
class RuntimeInstrumentation final {
public:
  // The PLE rows the last decode step gathered for batch lane `lane`'s
  // verify rows, each row's heads' in order (Qwen3.8-Flash-Next), until the
  // next decode step; none for a target without them.
  [[nodiscard]] static std::vector<uint32_t> lastTableRows(const Runtime &runtime, uint32_t lane);
  // The fp32 logits the last command left in batch lane `lane`'s rows, each
  // the target's vocabulary wide, until the next command: a decode step's
  // verify rows, or in row 0 the final position of the prefill chunk that
  // ended a prompt.
  [[nodiscard]] static std::span<const float> lastLogits(const Runtime &runtime, uint32_t lane);
  // The rows of its block batch lane `lane` of the last decode step verified
  // (ops::DraftSelector::addVerifyRows), until the next decode step.
  [[nodiscard]] static uint32_t lastVerifyRows(const Runtime &runtime, uint32_t lane);
  // While capturing, each command that selects first tokens or verifies
  // copies the rows lastLogits returns, as the target's forward wrote them
  // before the policy rewrites them in place: for each of its batch lanes,
  // row 0 for a selection or the lane's verified rows (lastVerifyRows) for a
  // verify. Only a capturing command adds the host step that copies them.
  // takeTargetLogits() reads and clears the copies, one per batch lane of the
  // last such command since the last take; none if none ran.
  static void captureTargetLogits(Runtime &runtime, bool enabled);
  [[nodiscard]] static std::vector<std::vector<float>> takeTargetLogits(Runtime &runtime);
  // The anchor request `requestId`'s last selection left pending, which its
  // next decode step emits first; none until its first token is selected.
  [[nodiscard]] static std::optional<uint32_t> pendingToken(const Runtime &runtime, uint64_t requestId);
  // Shared scratch of a completed, unconstrained decode, until the next
  // command. `width` is the dispatch width, not its projection storage width:
  // edge tables follow ALL lanes' shard partials in one packed allocation.
  // Position zero has only predecessor row zero; its other rows are unwritten.
  struct DraftSelection final {
    std::span<const uint32_t> candidates, proposed, targetTokens;
    std::span<const float> unary, edges, confidence;
    uint32_t accepted = 0, retained = 0, verifyRows = 0;
  };
  [[nodiscard]] static DraftSelection lastDraftSelection(const Runtime &runtime,
                                                        uint32_t lane, uint32_t width);
  // Restore the prior/seed for controlled capture; no online timing history.
  static void resetVerifyBudget(Runtime &runtime);
  // BF16 bit patterns of all final draft hidden rows, anchor included.
  [[nodiscard]] static std::span<const uint16_t> lastDraftHidden(const Runtime &runtime, uint32_t lane);
  // The GPU tables of resident request `requestId`'s lane as its last
  // command left them, every entry the lane holds: its page table and, for
  // a layout with a block index, its index table (none without).
  struct LaneTables final {
    std::span<const SplashKvPage> pages;
    std::span<const SplashKvPage> index;
  };
  [[nodiscard]] static LaneTables laneTables(const Runtime &runtime, uint64_t requestId);
  // The rows resident request `requestId`'s latest decode step retained,
  // which its GDN cell holds only once its next step folds them in
  // (QwenLaneMetadata::pendingRows): every GDN layer's tape rows
  // (metal/abi/GDN.h) up to that count, field by field, layer by layer.
  [[nodiscard]] static std::vector<uint8_t> pendingGdnRows(const Runtime &runtime, uint64_t requestId);
  // The entries of the registry through which the placements of an image
  // share its rows: an entry for each image whose rows something holds, and
  // for each whose rows went since the last start with images.
  [[nodiscard]] static size_t imageEntries(const Runtime &runtime);
};

} // namespace splash::model

// Batch driver reusing the reviewed PR550/556 capture primitives.
// The production runtime is unchanged; only instrumented accessors are linked.
#define main splash_decode_profile_legacy_main
#include "decode_profile.mm"
#undef main

#ifndef SPLASH_AUDIT_SOURCE_ID
#define SPLASH_AUDIT_SOURCE_ID "unidentified"
#endif

namespace {
struct AuditCase {
  std::string id, promptFile, outputFile, family, domain, split, reasoning;
  bool thinking = false, hidden = true, policy = false;
  uint32_t cycles = 32, restore = 0, materialize = 0;
};

std::string stringField(NSDictionary *object, NSString *key) {
  id value=object[key];
  if(![value isKindOfClass:NSString.class] || ![value length])
    throw std::invalid_argument(std::string("missing string field: ")+key.UTF8String);
  return [value UTF8String];
}
uint32_t numberField(NSDictionary *object, NSString *key, uint32_t fallback) {
  id value=object[key]; if(!value) return fallback;
  if(![value isKindOfClass:NSNumber.class]) throw std::invalid_argument("non-numeric audit setting");
  const double number=[value doubleValue];
  if(!std::isfinite(number) || number<0 || number>UINT32_MAX || number!=std::floor(number))
    throw std::invalid_argument("audit integer out of range");
  return static_cast<uint32_t>(number);
}
std::string digestIds(std::span<const uint32_t> values) {
  return model::weightDigest({reinterpret_cast<const uint8_t *>(values.data()), values.size()*sizeof(uint32_t)});
}

void captureAudit(model::Runtime &executor, Lane &lane, const AuditCase &item,
                  std::span<const uint32_t> prompt, std::ostream &file, std::ostream *hidden) {
  std::vector<uint32_t> history(prompt.begin(),prompt.end());
  uint64_t records=0,emitted=0,policyRecords=0;bool terminal=false;
  std::ofstream policy; if(item.policy){policy.open(item.outputFile+".policy.f32",std::ios::binary);if(!policy)throw std::runtime_error("cannot create policy sidecar");}
  double callMs=0;
  for(uint32_t cycle=0;cycle<item.cycles;++cycle) {
    BatchPlan plan{.kind=WorkKind::Decode,.items={{lane.id,0,0}},.decodeStage=DecodeStage::Regular};
    const ModelBatchItem batch{lane.id,lane.position,0,lane.pages,lane.pageTableRevision};
    const auto began=std::chrono::steady_clock::now();
    const auto results=executor.decode(plan,std::span(&batch,1));
    const double ms=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-began).count();
    callMs+=ms;
    auto raw=item.policy?model::RuntimeInstrumentation::takeTargetLogits(executor):std::vector<std::vector<float>>{};
    if(results.size()!=1 || !results[0].failure.empty()) throw std::runtime_error("audit decode failed");
    const auto &result=results[0];
    emitted+=result.outputTokens.size();terminal=result.finished;
    if(!result.draftedTokens) break;
    const auto draft=model::RuntimeInstrumentation::lastDraftSelection(executor,0,1);
    auto context=history;
    if(!result.outputTokens.empty())context.push_back(result.outputTokens.front());
    file<<"{\"kind\":\"cycle\",\"request_id\":"<<lane.id<<",\"cycle\":"<<cycle
        <<",\"lane\":0,\"position\":"<<lane.position<<",\"accepted\":"<<draft.accepted
        <<",\"retained\":"<<draft.retained<<",\"verify_rows\":"<<draft.verifyRows<<",\"proposed\":";
    jsonArray(file,draft.proposed);file<<",\"candidates\":";jsonArray(file,draft.candidates);
    file<<",\"unary\":";jsonArray(file,draft.unary);file<<",\"edges\":[";
    for(uint32_t position=0;position<SPLASH_DRAFT_PROPOSAL_TOKENS;++position) {
      if(position)file<<',';
      const uint32_t count=position?SPLASH_DRAFT_CANDIDATES*SPLASH_DRAFT_CANDIDATES:SPLASH_DRAFT_CANDIDATES;
      jsonArray(file,draft.edges.subspan(position*SPLASH_DRAFT_CANDIDATES*SPLASH_DRAFT_CANDIDATES,count));
    }
    file<<"],\"confidence\":";jsonArray(file,draft.confidence);
    file<<",\"target_tokens\":";jsonArray(file,draft.targetTokens.first(draft.retained));
    file<<",\"output_tokens\":";jsonArray(file,std::span<const uint32_t>(result.outputTokens));
    file<<",\"context_sha256\":"<<json::quote(digestIds(context))<<",\"decode_call_ms\":"<<ms;
    if(hidden) {
      const auto rows=model::RuntimeInstrumentation::lastDraftHidden(executor,0);
      hidden->write(reinterpret_cast<const char *>(rows.data()),rows.size_bytes());
      file<<",\"hidden_record\":"<<records;
    }
    if(item.policy) {
      const uint32_t passed=std::min(draft.accepted,draft.retained-1);
      const bool rejected=draft.accepted<draft.verifyRows-1 && draft.retained==draft.accepted+1 && result.outputTokens.size()==draft.retained && draft.targetTokens[draft.accepted]!=draft.proposed[draft.accepted];
      if(passed+uint32_t(rejected)>0) {
        const uint32_t pos=rejected?passed:passed-1;
        constexpr uint32_t vocabulary=248320;
        if(raw.size()!=1 || raw[0].size()!=8ULL*vocabulary)throw std::runtime_error("bad raw target shape");
        policy.write(reinterpret_cast<const char *>(raw[0].data()),8ULL*vocabulary*sizeof(float));
        auto correctContext=context;correctContext.insert(correctContext.end(),draft.proposed.begin(),draft.proposed.begin()+pos);
        file<<",\"policy_record\":"<<policyRecords++<<",\"policy_position\":"<<pos<<",\"policy_context_sha256\":"<<json::quote(digestIds(correctContext));
      }
    }
    file<<"}\n";
    history.insert(history.end(),result.outputTokens.begin(),result.outputTokens.end());
    lane.position+=result.outputTokens.size()-result.outputTokensWithoutKv;
    ++records;
    if(terminal)break;
  }
  file<<"{\"kind\":\"end\",\"records\":"<<records<<",\"terminal\":"<<(terminal?"true":"false")
      <<",\"actual_emitted_tokens\":"<<emitted<<",\"decode_call_ms\":"<<callMs<<"}\n";
  file.flush();if(hidden)hidden->flush();if(item.policy)policy.flush();
  if(!file || (hidden && !*hidden))throw std::runtime_error("could not finish audit capture");
}
}

int main(int argc,char **argv) {
 @autoreleasepool {
  try {
    if(argc!=4)throw std::invalid_argument("usage: rejection-audit METALLIB MODEL_ROOT SUITE.json");
    NSError *error=nil;
    NSData *data=[NSData dataWithContentsOfFile:[NSString stringWithUTF8String:argv[3]]];
    id parsed=data?[NSJSONSerialization JSONObjectWithData:data options:0 error:&error]:nil;
    if(![parsed isKindOfClass:NSDictionary.class])throw std::invalid_argument("cannot read audit suite JSON");
    NSDictionary *document=parsed;
    if(stringField(document,@"schema")!="qwen38-rejection-audit-v1")throw std::invalid_argument("unsupported audit suite");
    NSArray *cases=document[@"cases"];
    if(![cases isKindOfClass:NSArray.class] || !cases.count)throw std::invalid_argument("empty audit suite");
    std::vector<AuditCase> items;uint32_t largest=0,maxCycles=0;
    for(NSDictionary *value in cases) {
      if(![value isKindOfClass:NSDictionary.class])throw std::invalid_argument("audit case must be an object");
      AuditCase item;item.id=stringField(value,@"id");item.family=stringField(value,@"family");item.domain=stringField(value,@"domain");
      item.split=stringField(value,@"split");item.reasoning=stringField(value,@"reasoning_effort");
      item.promptFile=stringField(value,@"prompt_file");item.outputFile=stringField(value,@"output_file");
      item.thinking=numberField(value,@"thinking",0);item.hidden=numberField(value,@"capture_hidden",1);item.policy=numberField(value,@"capture_policy",0);
      item.cycles=numberField(value,@"cycles",32);item.restore=numberField(value,@"restore_prefix",0);
      item.materialize=numberField(value,@"materialize_prefix",item.restore);
      if(!item.cycles || item.cycles>4096 || item.thinking!=(item.reasoning!="none"))throw std::invalid_argument("invalid audit cycles/reasoning mode");
      const auto prompt=readPrompt(item.promptFile);
      if(prompt.size()>32768)throw std::invalid_argument("audit prompt exceeds32768");
      if(item.restore && item.restore!=item.materialize)throw std::invalid_argument("restore and materialize must agree");
      if(item.materialize && (item.materialize%32 || item.materialize>=prompt.size()))throw std::invalid_argument("invalid audit materialization boundary");
      largest=std::max(largest,static_cast<uint32_t>(prompt.size()));maxCycles=std::max(maxCycles,item.cycles);items.push_back(item);
    }
    const auto suiteHash=model::weightDigest({static_cast<const uint8_t *>(data.bytes),data.length});
    metal::MetalBackend backend(argv[1]);const std::filesystem::path root(argv[2]);
    model::ModelLoadOptions options;options.readers=std::make_shared<model::SsdReaders>(model::kSsdReaders);
    auto model=model::loadModel(backend,root,model::inspectModelRoot(root),options);
    if(model.draft.layout.layers!=5 || model.draft.layout.hiddenSize!=5120 || model.draft.layout.vocabularySize!=248320)
      throw std::invalid_argument("audit requires pinned five-layer dense27B drafter");
    if(uint64_t{largest}+maxCycles*8+2>model.maximumContextTokens())throw std::invalid_argument("audit exceeds model context");
    ops::ExecutionPlans operators(backend.capabilities());
    const uint32_t pagesPerLane=(largest+maxCycles*8+10)/32+2;
    const auto layout=model.targetKvLayout(kv::Format::Int8);const uint32_t extentPages=layout.maximumExtentPages();
    const uint32_t pageCount=(pagesPerLane*4+extentPages-1)/extentPages*extentPages;
    MemoryGovernor governor(backend,34ULL*1024*1024*1024,1,1,queryHostMemory,0);
    kv::PageStorage pages(backend,governor.allocationAdmission(),layout,pageCount,extentPages);
    for(uint32_t n=0;n<pageCount/extentPages;++n)if(!pages.allocateExtent(n))throw std::runtime_error("audit KV allocation failed");
    model::QwenStateStorage states(backend,governor.allocationAdmission(),model.stateLayout(ops::GdnStateFormat::Float32),nullptr);
    model::RuntimeContext context{backend,model,pages,states,operators};context.verifyRows=model::VerifyRows::All;
    model::Runtime executor(context);
    for(uint32_t index=0;index<items.size();++index) {
      const auto &item=items[index];const auto prompt=readPrompt(item.promptFile);
      for(auto token:prompt)if(token>=model.draft.layout.vocabularySize)throw std::invalid_argument("audit token out of vocabulary");
      std::ofstream file(item.outputFile);if(!file)throw std::runtime_error("cannot create audit output");
      std::ofstream hidden;if(item.hidden){hidden.open(item.outputFile+".hidden.bf16",std::ios::binary);if(!hidden)throw std::runtime_error("cannot create hidden sidecar");}
      file<<std::setprecision(std::numeric_limits<float>::max_digits10);
      file<<"{\"kind\":\"metadata\",\"schema\":1,\"audit_case\":"<<json::quote(item.id)
          <<",\"family\":"<<json::quote(item.family)<<",\"domain\":"<<json::quote(item.domain)<<",\"split\":"<<json::quote(item.split)
          <<",\"source_id\":"<<json::quote(SPLASH_AUDIT_SOURCE_ID)<<",\"suite_sha256\":"<<json::quote(suiteHash)
          <<",\"model_root\":"<<json::quote(root.string())<<",\"model_fingerprint\":"<<json::quote(model.manifestFingerprintSha256)
          <<",\"device\":"<<json::quote(backend.capabilities().deviceName)<<",\"width\":1,\"positions\":7,\"candidates\":16,\"sampling\":false"
          <<",\"verify_rows\":\"all\",\"budget_learning\":\"frozen\",\"presence_penalty\":0,\"kv_format\":\"int8\",\"state_format\":\"fp32\""
          <<",\"thinking\":"<<(item.thinking?"true":"false")<<",\"reasoning_effort\":"<<json::quote(item.reasoning)
          <<",\"restore_prefix\":"<<item.restore<<",\"materialize_prefix\":"<<item.materialize
          <<",\"prompt_tokens\":"<<prompt.size()<<",\"prompt_sha256\":"<<json::quote(digestIds(prompt))
          <<",\"policy_capture\":"<<(item.policy?"true":"false")<<",\"policy_vocabulary\":248320"<<",\"hidden_capture\":"<<(item.hidden?"true":"false")<<",\"hidden_rows\":8,\"hidden_width\":5120}\n";
      Lane lane{uint64_t{index}+1,0,0,pageRange(0,pagesPerLane)};
      const auto began=std::chrono::steady_clock::now();
      model::RuntimeInstrumentation::captureTargetLogits(executor,item.policy);
      prefill(executor,lane,prompt,item.cycles*8+2,0,item.restore,item.materialize);
      if(item.policy)static_cast<void>(model::RuntimeInstrumentation::takeTargetLogits(executor));
      captureAudit(executor,lane,item,prompt,file,item.hidden?&hidden:nullptr);
      executor.end(lane.id);
      model::RuntimeInstrumentation::captureTargetLogits(executor,false);
      std::printf("AUDIT %u/%zu %s %.3fs\n",index+1,items.size(),item.id.c_str(),std::chrono::duration<double>(std::chrono::steady_clock::now()-began).count());std::fflush(stdout);
    }
    return 0;
  }catch(const std::exception &error){std::cerr<<"rejection-audit: "<<error.what()<<'\n';return 1;}
 }
}

"""Apply the prospective M48 operator rule to every registered configuration."""
from collections import defaultdict
from pathlib import Path
import hashlib
import json

root = Path(__file__).resolve().parents[1]


def load(ident):
    receipt_path = root / 'results' / (ident + '.receipt.json')
    receipt = json.loads(receipt_path.read_text())
    assert receipt['state'] == 'complete' and receipt['exit_code'] == 0
    assert receipt['artifact_sha256'] == receipt['artifact_sha256_after']
    path = root / 'results' / (ident + '.stdout')
    return [json.loads(v) for v in path.read_text().splitlines()], {
        'job': ident, 'receipt_sha256': hashlib.sha256(receipt_path.read_bytes()).hexdigest(),
        'stdout_sha256': hashlib.sha256(path.read_bytes()).hexdigest()}


oracle, oracle_source = load('af4-m48-oracle-v3')
numerical = [v for v in oracle if v.get('case_passed')]
assert len(numerical) == 2
data, diagnostic_source = load('af4-m48-diagnostic-v3')
grouped = defaultdict(list)
for row in data:
    if 'gpu_ms_per_projection' in row:
        grouped[(row['splits'], row['spread'])].append(row)
assert len(grouped) == 4
cases = []
for (split, spread), rows in grouped.items():
    assert [v['arm'] for v in rows] == [0, 3, 3, 0]
    assert all(v['rows'] == 64 and v['live_rows'] == 48 and v['repeats'] == 50 for v in rows)
    control = (rows[0]['gpu_ms_per_projection'] + rows[3]['gpu_ms_per_projection']) / 2
    candidate = (rows[1]['gpu_ms_per_projection'] + rows[2]['gpu_ms_per_projection']) / 2
    cases.append({'splits': split, 'spread': spread, 'control_ms': control, 'candidate_ms': candidate,
                  'latency_change': candidate / control - 1, 'throughput_change': control / candidate - 1})
primary = next(v for v in cases if v['splits'] == 1 and v['spread'])
resources, resource_source = load('af4-m48-resources-v3')
record = {'scope': 'Finite balanced operator screen, not a controlled whole-model speed claim. Both arms receive64rows with48live rows; M48 only computes the48live rows. All split/spread settings retained.',
    'numerical': {'small_cases': 2,
        'small_bitwise_comparisons': sum(v['bitwise_comparisons'] for v in numerical),
        'independent_fp64_checks': sum(v['independent_fp64_checks'] for v in numerical),
        'production_shape_bitwise_comparisons': sum(v['bitwise_comparisons'] for v in data if v.get('case_passed')),
        'guards': 'NaNpadding, outputguard, same-split reference bits, independent FP64 bounds and released split counters.',
        'source': oracle_source},
    'cases': cases, 'primary': primary, 'operator_rule_met': primary['throughput_change'] >= .05,
    'production_source_adopted': False, 'resources': resources,
    'sources': [diagnostic_source, resource_source],
    'interpretation': 'The primary rule is met and motivates a separate prospective B3 whole-model comparison. Actual M48allocation remainsM64 in that research variant, so no arena-memory saving is claimed. Static threadgroup bytes stay8208; smaller cooperative destination element capacity is not an allocated-register/spill measurement.',
    'retained_setup_failures': [
        {'job': 'build-af4-m48-operator-v1', 'cause': 'Extracted entry wrapper omitted its source-local helper/store templates; no GPU output.'},
        {'job': 'build-af4-m48-operator-v2', 'cause': 'Copied unused prefill-only constant rejected by unchanged -Werror; no GPU output.'}],
    'correction': 'V3 includes the unchanged required helpers and removes the unused declaration. Compiler warnings, kernel math, operator order, numerical guards and5%rule are unchanged. Initial failures are not numerical shader failures.'}
assert record['operator_rule_met']
output = root / 'results/m48-operator-v3.json'
assert not output.exists()
output.write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({'numerical': record['numerical'], 'primary': primary, 'operator_rule_met': True}, indent=2))

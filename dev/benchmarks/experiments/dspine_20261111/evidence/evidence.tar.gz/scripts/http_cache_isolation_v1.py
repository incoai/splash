"""Actual old/new default-cache compatibility and physical-layout isolation."""
from pathlib import Path
import datetime as dt
import fcntl
import hashlib
import json
import os
import signal
import stat
import subprocess
import sys
import time

root=Path(__file__).resolve().parents[1]
ident,variant,short_window=sys.argv[1:]
short_window=bool(int(short_window))
sys.path.insert(0,str(root/variant))
from dev.tests import smoke_real as smoke
out=root/'http'/ident;out.mkdir(exist_ok=False)
cache=out/'cache';model='local/dspine-cache-isolation'
model_root=Path('/Users/linson/Documents/ai/splash/build/dspine/model-root.txt').read_text().strip()
record={'id':ident,'variant':variant,'short_window':short_window,'runs':[],
        'shader_validation':os.environ.get('MTL_SHADER_VALIDATION'),'passed':False}
def save():
    p=out/'result.json.tmp';p.write_text(json.dumps(record,indent=2)+'\n');p.replace(out/'result.json')
def namespaces():
    return sorted(p.name for p in cache.iterdir() if p.is_dir()) if cache.exists() else []
def closed():
    for path in cache.iterdir():
        smoke.require(smoke.CACHE_NAMESPACE.fullmatch(path.name) is not None and path.is_dir(),'invalid cache namespace')
        smoke.require(stat.S_IMODE(path.stat().st_mode)==0o700,'wrong namespace permissions')
        smoke.require({p.name for p in path.iterdir()}==smoke.CACHE_FILES|{'lock'},'unclean cache namespace')
        with (path/'lock').open('rb') as lock:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
prompt=smoke.filler('dspine13h','layout-isolation',24)+'\nWrite an iterative Python function that checks whether an integer is prime. Return only code.'
body=smoke.chat_body(model,prompt,max_completion_tokens=96,seed=20261110,cache_salt=ident+'-same-lineage')
# The first final8 run must take back exactly the namespace written by425.
runs=[('old8','control',8,32768,'new'),('final8',variant,8,32768,'reuse'),
      ('final16',variant,16,32768,'new')]
if short_window:runs += [('short8',variant,8,2048,'new'),('short16',variant,16,2048,'new'),('short16_restart',variant,16,2048,'reuse')]
else:runs += [('final16_restart',variant,16,32768,'reuse')]
for name,source,rows,context,expected in runs:
    tree=root/source;binary=root/'artifacts'/source/'splash';port=smoke.available_port()
    command=[sys.executable,'-m','server.server',model_root,'--binary',str(binary),'--model',model,
       '--host','127.0.0.1','--port',str(port),'--max-context',str(context),'--kv-format','int8','--state-format','fp32',
       '--disable-ane','--verify-rows','all','--persistent-cache','--cache-dir',str(cache),'--max-cache-disk','4G']
    if source!='control':command += ['--draft-block-size',str(rows)]
    before=namespaces();run={'name':name,'source':source,'rows':rows,'context':context,'expected':expected,
       'command':command,'namespaces_before':before};record['runs'].append(run);save()
    with (out/f'{name}.server.log').open('w') as log:
        process=subprocess.Popen(command,cwd=tree,stdout=log,stderr=subprocess.STDOUT)
        try:
            deadline=time.monotonic()+300
            while time.monotonic()<deadline:
                smoke.require(process.poll() is None,'server exited at startup')
                try:
                    code,status=smoke.request(port,'GET','/status',timeout=1)
                    if code==200 and status.get('ready'):break
                except (OSError,smoke.SmokeFailure):pass
                time.sleep(.25)
            else:raise RuntimeError('startup timeout')
            smoke.validate_status(status,'int8');smoke.require(status.get('draft_block_size',8)==rows,'runtime width differs')
            run['status_start']=status
            taken=status['disk']['taken_back']
            smoke.require((taken['states']>=1 and taken['kv_blocks']>=1) if expected=='reuse' else taken['states']==0,
                          name+': namespace did not isolate/reuse expected states')
            code,answer=smoke.request(port,'POST','/v1/chat/completions',body,timeout=600)
            smoke.require(code==200,f'{name}: HTTP{code}: {answer}')
            content=answer['choices'][0]['message']['content'];smoke.require(bool(content),'empty response')
            (out/f'{name}.answer.json').write_text(json.dumps(answer,indent=2)+'\n')
            run['output_sha256']=hashlib.sha256(content.encode()).hexdigest();run['usage']=answer['usage']
            run['status_end']=smoke.runtime_status(port)
            smoke.require(answer['usage']['prompt_tokens']+96<2048,'short layout fixture exceeds context')
            if expected=='reuse':
                smoke.require(answer['usage']['prompt_tokens_details']['cached_tokens']>=answer['usage']['prompt_tokens']*.8,'expected cached prefix not restored')
                reference=next(v for v in record['runs'] if v['name']==('old8' if name=='final8' else 'short16' if short_window else 'final16'))
                smoke.require(run['output_sha256']==reference['output_sha256'],'restored output differs from its layout reference')
            save()
        finally:
            if process.poll() is None:process.send_signal(signal.SIGINT)
            try:process.wait(timeout=45)
            except subprocess.TimeoutExpired:
                process.terminate()
                try:process.wait(timeout=10)
                except subprocess.TimeoutExpired:process.kill();process.wait(timeout=10)
            run['exit_code']=process.returncode;save();smoke.require(process.returncode==0,'unclean server stop')
    closed();after=namespaces();run['namespaces_after']=after
    smoke.require(len(after)==len(before)+(expected=='new'),name+': unexpected physical namespace count')
    save();print(json.dumps({'run':name,'namespace_count':len(after),'expectation_passed':True}),flush=True)
smoke.require(len(namespaces())==(4 if short_window else 2),'wrong total physical namespaces')
record['passed']=True;record['completed_utc']=dt.datetime.now(dt.timezone.utc).isoformat();save()
print('PASS baseline8 persistent compatibility,8/16 isolation,actual-window isolation and clean restart')

"""Retain every nomination-screen result, including invalid fixtures."""
from collections import defaultdict
from pathlib import Path
import hashlib
import json
import math

root = Path(__file__).resolve().parents[1]

def load(ident):
    path = root/'results'/f'{ident}.stdout'
    receipt = json.loads((root/'results'/f'{ident}.receipt.json').read_text())
    assert receipt['exit_code'] == 0 and receipt['artifact_sha256'] == receipt['artifact_sha256_after']
    return [json.loads(line) for line in path.read_text().splitlines()], hashlib.sha256(path.read_bytes()).hexdigest()

prefill = []
for mode in [1, 2, 3]:
    oracle, oracle_sha = load(f'prefill-tiles-v3-mode{mode}-oracle')
    assert len(oracle) == 40 and all(v['case_passed'] for v in oracle)
    values, source_sha = load(f'prefill-tiles-v3-mode{mode}-diagnostic')
    grouped = defaultdict(list)
    for row in values:
        if 'gpu_ms' not in row:
            continue
        grouped[tuple(row[k] for k in ['rows', 'outputs', 'inputs', 'epilogue'])].append(row)
    assert len(grouped) == 27
    cases = []
    for key, rows in grouped.items():
        assert [v['mode'] for v in rows] == [0, mode, mode, 0]
        base = (rows[0]['gpu_ms'] + rows[3]['gpu_ms'])/2
        candidate = (rows[1]['gpu_ms'] + rows[2]['gpu_ms'])/2
        cases.append(dict(zip(['rows', 'outputs', 'inputs', 'epilogue'], key),
                          control_ms=base, candidate_ms=candidate,
                          latency_change=candidate/base-1, throughput_change=base/candidate-1))
    gain = math.exp(sum(math.log(1+v['throughput_change']) for v in cases)/len(cases))-1
    worst = max((v for v in cases if v['rows'] >= 512), key=lambda v:v['latency_change'])
    nominated = gain >= .05 and worst['latency_change'] <= .03
    prefill.append({'mode':mode,'nomination_rule_met':nominated,'geometric_throughput_change':gain,
                    'worst_large_row_case':worst,'cases':cases,'oracle':{'cases':40,
                    'bitwise_comparisons':sum(v['bitwise_comparisons'] for v in oracle),
                    'fp64_checks':sum(v['independent_fp64_checks'] for v in oracle),
                    'stdout_sha256':oracle_sha},'diagnostic_stdout_sha256':source_sha})
coop_oracle, coop_oracle_sha = load('af4-coop-oracle-v1')
coop_oracle = [v for v in coop_oracle if v.get('case_passed')]
values, coop_sha = load('af4-coop-diagnostic-v1')
grouped=defaultdict(dict)
for row in values:
    if 'gpu_ms_per_projection' in row:
        grouped[tuple(row[k] for k in ['rows','live_rows','splits','spread'])][row['simdgroups']]=row['gpu_ms_per_projection']
coop_cases=[]
for key,v in grouped.items():
    assert set(v)=={0,1,2}
    best=min(v[0],v[1])
    coop_cases.append(dict(zip(['rows','live_rows','splits','spread'],key),
        original_one_pass_ms=v[1],original_two_pass_ms=v[0],cooperative_input_ms=v[2],
        latency_change_against_best_existing=v[2]/best-1))
resources, resources_sha = load('af4-coop-resources-v1')
failures=[]
for version in [1,2]:
    for mode in [1,2,3]:
        ident=f'prefill-tiles-v{version}-mode{mode}-oracle'
        receipt=json.loads((root/'results'/f'{ident}.receipt.json').read_text())
        failures.append({'job':ident,'state':receipt['state'],'exit_code':receipt['exit_code']})
result={'scope':'Finite operator nomination screens, not controlled end-to-end throughput. No candidate is selected from a favorable subset.',
        'prefill_candidates':prefill,'prefill_production_nominations':sum(v['nomination_rule_met'] for v in prefill),
        'cooperative_input_candidate':{'nominated':False,'cases':coop_cases,
          'oracle_cases':len(coop_oracle),'bitwise_comparisons':sum(v['bitwise_comparisons'] for v in coop_oracle),
          'fp64_checks':sum(v['independent_fp64_checks'] for v in coop_oracle),
          'oracle_stdout_sha256':coop_oracle_sha,'diagnostic_stdout_sha256':coop_sha,
          'resources':resources,'resources_stdout_sha256':resources_sha,
          'interpretation':'Direct cooperative-register input reduces static threadgroup storage but loses to the best existing gate/up path in every tested production shape. Static storage is not an occupancy or spill measurement.'},
        'invalid_fixture_attempts':failures,
        'fixture_correction':'Both v1 and v2 prefill fixtures actually executed and failed baseline validation: plain prefill requires the production segmented 36-byte/11-buffer ABI. V2 only corrected plane1 fallback, so it remained invalid. A v3 preparation note proposed canceling pending v2 jobs, but they had already executed and no receipts were overwritten. V3 corrected the fixture ABI; shader candidates were unchanged. Only v3 is numerical evidence.'}
(root/'results/operator-rejections-v1.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'prefill_nominations':result['prefill_production_nominations'],
  'prefill_geometric_changes':[v['geometric_throughput_change'] for v in prefill],
  'cooperative_input_oracle_cases':len(coop_oracle),'cooperative_input_nominated':False},indent=2))

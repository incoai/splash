from pathlib import Path
r=Path(__file__).resolve().parents[1]
s=(r/'scripts/study_driver_v1.mm').read_text()
s=s.replace('using Clock = std::chrono::steady_clock;', '''using Clock = std::chrono::steady_clock;

// Compile identical measurement code against the committed baseline and the
// per-model geometry candidate; only the candidate exposes the new setting.
template<class Config> void setDraftBlock(Config &config, uint32_t rows) {
  if constexpr (requires { config.draftBlockSize = rows; }) config.draftBlockSize = rows;
  else if (rows != 8) throw std::invalid_argument("baseline supports eight rows only");
}
template<class Executor> uint32_t activeRows(const Executor &executor) {
  if constexpr (requires { executor.decodeRows(); }) return executor.decodeRows();
  else return model::ExecutionLimits::targetVerifyRows;
}
''')
s=s.replace('config.draftBlockSize = draftBlockSize;', 'setDraftBlock(config, draftBlockSize);').replace('executor->decodeRows()', 'activeRows(*executor)').replace('(executor.decodeRows() - 1)', '(activeRows(executor) - 1)')
s=s.replace('struct DecodeThroughputMeasurement final {', '''struct DecodeThroughputMeasurement final {
  std::string scenario = "decode";
  uint32_t promptTokens = 0;
  uint32_t outputCap = 64;
  uint64_t inputTokenHash = 0;
  std::vector<std::vector<uint32_t>> laneOutputs;''')
s=s.replace('std::span<const uint32_t> tokens) {\n  if (!width', 'std::span<const uint32_t> tokens, uint32_t outputCap = 64, std::string scenario = "decode") {\n  if (!outputCap) throw std::invalid_argument("clone output cap is zero");\n  if (!width')
s=s.replace('request.maxNewTokens = 64;', 'request.maxNewTokens = outputCap;').replace('observed.outputTokens.size() != 64', '(observed.outputTokens.empty() || observed.outputTokens.size() > outputCap)').replace('decode throughput request did not produce exactly 64 tokens', 'decode throughput request returned no tokens or exceeded its cap')
s=s.replace('  result.width = width;\n', '''  result.width = width;
  result.scenario = std::move(scenario);
  result.promptTokens = static_cast<uint32_t>(tokens.size());
  result.outputCap = outputCap;
  result.inputTokenHash = tokenSequenceHash(tokens);
  for (uint64_t id : requestIds) result.laneOutputs.push_back(events.get(id).outputTokens);
''')
s=s.replace('uint32_t draftBlockSize = 8;', 'uint32_t draftBlockSize = 8;\n    uint32_t studyWidth = 1, prefixSuffix = 0;')
s=s.replace('      if (option == "--draft-block-size") {', '''      if (option == "--study-width") {
        studyWidth = parseSamples(argv[index + 1]);
        if (studyWidth > 4) throw std::invalid_argument("study width must be one through four");
      } else if (option == "--prefix-suffix") {
        prefixSuffix = parseSamples(argv[index + 1]);
      } else if (option == "--draft-block-size") {''')
s=s.replace('    if (cohort) selected = parseScenarios("study");', '    if (prefixSuffix && studyWidth != 1) throw std::invalid_argument("prefix study is serial");\n    if (cohort) selected = parseScenarios("study");')
old='''          measurements.push_back(runRequest(engine, driver, *executor, events, progress.get(), requestId++,
              c.name, sample, c.tokens, c.cap, true, &policy));'''
new='''          if (studyWidth > 1) {
            if (studyTemperature != 0) throw std::invalid_argument("clone study is greedy");
            decodeThroughput.push_back(runDecodeThroughput(engine, driver, *executor, events, progress.get(),
                requestId, studyWidth, sample, c.tokens, c.cap, c.name));
          } else if (prefixSuffix) {
            if (c.tokens.size() <= prefixSuffix + kv::kPageTokens)
              throw std::invalid_argument("prefix study prompt is shorter than its fixed suffix and one page");
            Measurement cold = runRequest(engine, driver, *executor, events, progress.get(), requestId++,
                c.name + "_cold", sample, c.tokens, c.cap, true, &policy);
            evictAllCache(resources->cache());
            std::vector<uint32_t> prefix(c.tokens.begin(), c.tokens.end() - prefixSuffix);
            Measurement seed = runRequest(engine, driver, *executor, events, progress.get(), requestId++,
                c.name + "_seed", sample, std::move(prefix), 1, false, &policy);
            Measurement hit = runRequest(engine, driver, *executor, events, progress.get(), requestId++,
                c.name + "_hit", sample, c.tokens, c.cap, true, &policy);
            hit.coldOutputMatch = cold.outputTokens == hit.outputTokens;
            measurements.push_back(std::move(cold)); measurements.push_back(std::move(seed));
            measurements.push_back(std::move(hit));
          } else {
            measurements.push_back(runRequest(engine, driver, *executor, events, progress.get(), requestId++,
                c.name, sample, c.tokens, c.cap, true, &policy));
          }'''
assert old in s;s=s.replace(old,new)
old='''      std::cout << "{\\"width\\":" << value.width'''
assert old in s;s=s.replace(old,'''      std::cout << "{\\"scenario\\":\\"" << value.scenario << "\\",\\"prompt_tokens\\":" << value.promptTokens
                << ",\\"output_cap\\":" << value.outputCap << ",\\"input_token_hash\\":\\"" << value.inputTokenHash << "\\""
                << ",\\"width\\":" << value.width''')
old='''                << tokenSequenceHash(value.firstLaneOutputTokens) << '"'
'''
new='''                << tokenSequenceHash(value.firstLaneOutputTokens) << '"';
      std::cout << ",\\"lane_outputs\\":[";
      for (size_t lane = 0; lane < value.laneOutputs.size(); ++lane) {
        if (lane) std::cout << ',';
        std::cout << '[';
        for (size_t t = 0; t < value.laneOutputs[lane].size(); ++t) {
          if (t) std::cout << ',';
          std::cout << value.laneOutputs[lane][t];
        }
        std::cout << ']';
      }
      std::cout << ']'
'''
assert old in s;s=s.replace(old,new)
(r/'scripts/study_driver_v2.mm').write_text(s)
s=(r/'scripts/build_study_v1.py').read_text().replace('study_driver_v1.mm','study_driver_v2.mm').replace("f'study-{name}-v1'", "f'study-{name}-v2'")
(r/'scripts/build_study_v2.py').write_text(s)

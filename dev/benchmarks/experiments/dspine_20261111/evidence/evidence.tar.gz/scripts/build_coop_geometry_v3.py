from pathlib import Path
import datetime as dt
import hashlib,json,subprocess
root=Path(__file__).resolve().parents[1];out=root/'artifacts/coop-input-geometry-v3';out.mkdir(exist_ok=False)
old=json.loads((root/'artifacts/coop-input-geometry-v2/build.json').read_text())
commands=[[s.replace('geometry-v2','geometry-v3').replace('geometry_v2','geometry_v3') for s in cmd] for cmd in old['commands']]
inputs={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [root/'scripts/coop_input_geometry_v3.metal',root/'scripts/coop_input_geometry_v3.mm']}
for cmd in commands:subprocess.run(cmd,check=True)
(out/'build.json').write_text(json.dumps({'utc':dt.datetime.now(dt.timezone.utc).isoformat(),'commands':commands,'inputs':inputs,
 'artifacts':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in out.iterdir()},
 'scope':'Cooperative destination element-capacity diagnostic across physical rows32/48/64 and columns16/32. Not allocated registers, occupancy, spills or throughput.'},indent=2)+'\n')

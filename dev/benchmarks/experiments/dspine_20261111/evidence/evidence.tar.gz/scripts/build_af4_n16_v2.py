from pathlib import Path
import hashlib,json,shutil,subprocess
r=Path(__file__).resolve().parents[1];out=r/'artifacts/af4-n16-operator-v2';out.mkdir(exist_ok=False)
old=json.loads((r/'artifacts/af4-n16-operator-v1/build.json').read_text())
cmd=[s.replace('af4-n16-operator-v1','af4-n16-operator-v2').replace('af4_n16_oracle_v1.mm','af4_n16_oracle_v2.mm') for s in old['commands'][-1]]
for name in ['splash.metallib','host-step.metallib']:shutil.copy2(r/'artifacts/af4-n16-operator-v1'/name,out/name)
subprocess.run(cmd,check=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(out/'splash.metallib')==old['artifacts']['splash.metallib']
(out/'build.json').write_text(json.dumps({'command':cmd,'source_sha256':sha(r/'scripts/af4_n16_oracle_v2.mm'),'same_shader_as_v1':True,'shader_sha256':sha(out/'splash.metallib'),'artifacts':{p.name:sha(p) for p in out.iterdir()}},indent=2)+'\n')

#include <MetalPerformancePrimitives/MetalPerformancePrimitives.h>
#include <metal_stdlib>
#define SPLASH_DRAFT_QUERY_ROWS 16u
#define SPLASH_DRAFT_PROPOSAL_TOKENS 15u
#define SPLASH_TARGET_VERIFY_ROWS 16u
#define SPLASH_KERNEL_SUFFIX "_v16"
namespace splash_verify16 {
#include "metal/kernels/decode/gdn.metal"
}

"""Register every frozen arm together, then honor the pre-data global order."""
from pathlib import Path
import datetime as dt
import hashlib
import json
import subprocess
import sys
root=Path(__file__).resolve().parents[1]
assert not (root/'notes/final-comparison-nominations-v1.json').exists()
for script,args in [('nominate_production_v3.py',[]),('prepare_final_comparisons_v1.py',['production-final-v1']),('prepare_sampling_jobs_v1.py',['production-final-v1'])]:
    subprocess.run([sys.executable,str(root/'scripts'/script),*args],check=True)
if (root/'notes/m48-research-v1-comparison-eligibility.json').exists():
    subprocess.run([sys.executable,str(root/'scripts/prepare_m48_comparison_v1.py')],check=True)
q=root/'queue.jsonl';jobs=[json.loads(s) for s in q.read_text().splitlines()]
labels=['default8-final-v1','dspine16-final-v1','dflash8-vs-dspine16-final-v1','dflash8-vs-dspine16-b4-final-v1','sampling4-v1','agent12-dflash8-vs-dspine16-final-v1','m48-b3-research-v1']
def rank(job):
    ident=job['id']
    if ident.startswith('sampling4-') or ident in ['freeze-artifacts-sampling4-v1','analyze-sampling4-v1']:
        return 5
    for n,label in enumerate(labels,1):
        if ident in ['freeze-artifacts-'+label,'analyze-'+label] or ident.startswith(label+'-g'):
            return n
    return 0
jobs=sorted(jobs,key=rank)
assert len({j['id'] for j in jobs})==len(jobs)
t=q.with_suffix('.tmp');t.write_text(''.join(json.dumps(j)+'\n' for j in jobs));t.replace(q)
(root/'notes/final-experiment-order-registered-v1.json').write_text(json.dumps({'registered_utc':dt.datetime.now(dt.timezone.utc).isoformat(),'ordered_labels':labels,'predata_order_record_sha256':hashlib.sha256((root/'notes/final-experiment-order-predata-v1.json').read_bytes()).hexdigest(),'order_matches_predata_record':True,'all_arm_protocols_written_before_first_fresh_output':True,'queue_sha256':hashlib.sha256(q.read_bytes()).hexdigest()},indent=2)+'\n')
print('Registered all arms before fresh outputs; original global order retained.')

"""Build the standalone experiment after all active controlled timings."""
from pathlib import Path
import datetime as dt
import hashlib
import json
import shutil
import subprocess
root=Path(__file__).resolve().parents[1]
out=root/'artifacts/af4-n16-operator-v1'
assert not out.exists()
out.mkdir()
old=json.loads((root/'artifacts/af4-coop-operator-v1/build.json').read_text())
def convert(s):
    return s.replace('af4-coop-operator-v1','af4-n16-operator-v1').replace('af4_coop_gateup_v1.metal','af4_n16_gateup_v1.metal').replace('af4_coop_oracle_v1.mm','af4_n16_oracle_v1.mm').replace('/coop.air','/n16.air')
commands=[[convert(s) for s in cmd] for cmd in old['commands']]
inputs=[Path(convert(s)) for s in old['inputs']]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
before={str(p):sha(p) for p in inputs}
for command in commands:subprocess.run(command,check=True)
assert before=={str(p):sha(p) for p in inputs}
shutil.copy2(root/'runtime16-v10/build/host-step.metallib',out/'host-step.metallib')
record={'utc':dt.datetime.now(dt.timezone.utc).isoformat(),'commands':commands,'inputs':before,
 'scope':'Standalone N16 pair operator; no production nomination before numerical and frozen screen gates.',
 'artifacts':{p.name:sha(p) for p in out.iterdir()},'exit_code':0}
(out/'build.json').write_text(json.dumps(record,indent=2)+'\n')
print(out)

"""Run only make/all/native-CPU builds alongside functional GPU oracles, never timings."""
from pathlib import Path
import datetime as dt, fcntl, hashlib, json, os, signal, subprocess, time
r=Path(__file__).resolve().parents[1]
ids=['build-wide-gateup-v1','build-attention-bound-v1']
queue={j['id']:j for j in map(json.loads,(r/'queue.jsonl').read_text().splitlines())}
def utc():return dt.datetime.now(dt.timezone.utc).isoformat()
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(path,d):
 q=path.with_suffix('.tmp');q.write_text(json.dumps(d,indent=2)+'\n');q.replace(path)
lock=(r/'cpu-build.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
for ident in ids:
 receipt=r/f'results/{ident}.receipt.json'
 if receipt.exists():continue
 job=queue[ident];assert job['command'][1].endswith('build_frozen_v4.py')
 record={'id':ident,'state':'running','start_utc':utc(),'job':job,'resource_class':'CPU-only fresh build and native CPU suite; overlaps functional Metal regression, no controlled timings','artifact_sha256':{f:sha(f) for f in job['artifacts']},'power_before':subprocess.check_output(['pmset','-g','batt'],text=True)}
 began=time.monotonic()
 with (r/f'results/{ident}.stdout').open('w') as out,(r/f'logs/{ident}.stderr').open('w') as err:
  child=subprocess.Popen(job['command'],cwd='/Users/linson/Documents/ai/splash',stdout=out,stderr=err,start_new_session=True)
  record['pid']=child.pid;save(r/'notes/current-cpu-build.json',record)
  timed_out=False
  try:child.wait(timeout=job['timeout_seconds'])
  except subprocess.TimeoutExpired:
   timed_out=True;os.killpg(child.pid,signal.SIGINT)
   try:child.wait(timeout=20)
   except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
 record.update(state='timeout' if timed_out else 'complete',exit_code=child.returncode,elapsed_seconds=time.monotonic()-began,end_utc=utc(),artifact_sha256_after={f:sha(f) for f in job['artifacts']},power_after=subprocess.check_output(['pmset','-g','batt'],text=True))
 if record['artifact_sha256']!=record['artifact_sha256_after']:record.update(state='artifact_changed_during_job',exit_code=123)
 save(receipt,record);save(r/'notes/current-cpu-build.json',record)
 print(json.dumps({'job':ident,'state':record['state'],'exit_code':record['exit_code'],'elapsed_seconds':record['elapsed_seconds']}),flush=True)
fcntl.flock(lock,fcntl.LOCK_UN);lock.close()

"""Narrow one-pass AF4 gate/up; split the SIMD lanes across gate and up."""
from pathlib import Path
root=Path(__file__).resolve().parents[1]
original=(root/'runtime16-v10/runtime/metal/kernels/shared/gguf_linear.metal').read_text()
first=original.index('template <class F, ushort Rows>\nkernel void gguf_decode_gate_up')
last=original.index('using GgufDecodeGateUpKernel',first)
kernel=original[first:last].replace('gguf_decode_gate_up(', 'gguf_decode_n16_gate_up(')
kernel=kernel.replace('GGUF_STAGED_COLUMNS','16u')
kernel=kernel.replace('gguf_staged_pair_steps<F, Rows>', 'af4_n16_pair_steps<F, Rows>')
kernel=kernel.replace('staged_first_step(group.x / 2,', 'staged_first_step(group.x / 4,')
helper='''#pragma clang fp reassociate(off)
#include "metal/kernels/common/gguf_staged_tile.h"
#include "metal/kernels/common/split_reduce.h"

// The same K32 walk and half dequantization as the existing pair loop.
// Each SIMD lane stages one column of one operand; all lanes participate
// in both tensor operations and every barrier.
template<class F, ushort Rows, class Acc>
inline void af4_n16_pair_steps(device bfloat *input, device uchar *gw0, device uchar *gw1, device uchar *gmeta,
    device uchar *uw0, device uchar *uw1, device uchar *umeta, uint inputSize, uint origin,
    threadgroup half *stage, threadgroup half2 *table, uint lane,
    uint begin, uint end, uint first, thread Acc &gate, thread Acc &up) {
  constexpr ushort Columns=16, Step=32;
  auto a=tensor(input,dextents<int,2>{int(inputSize),Rows},array<int,2>{1,int(inputSize)});
  constexpr auto descriptor=matmul2d_descriptor(Rows,Columns,Step,false,true,false,
      matmul2d_descriptor::mode::multiply_accumulate);
  matmul2d<descriptor,execution_simdgroups<1>> operation;
  tensor<threadgroup half,dextents<int,2>,tensor_inline> gateTensor(stage,dextents<int,2>{Step,Columns},array<int,2>{1,Step});
  tensor<threadgroup half,dextents<int,2>,tensor_inline> upTensor(stage+Step*Columns,dextents<int,2>{Step,Columns},array<int,2>{1,Step});
  auto bg=gateTensor.slice<Step,Columns>(0,0),bu=upTensor.slice<Step,Columns>(0,0);
  const bool isGate=lane<Columns;
  const uint column=lane%Columns;
  StagedColumn<F> weight;
  weight.begin(isGate?gw0:uw0,isGate?gw1:uw1,isGate?gmeta:umeta,inputSize,origin,column,first,begin<end);
  const auto runStep=[&](uint step,uint next,bool more) __attribute__((always_inline)) {
    weight.stage(step,table,stage+(isGate?0:Step*Columns),column);
    simdgroup_barrier(mem_flags::mem_threadgroup);
    if(more)weight.load(step,next);
    auto slice=a.template slice<Step,Rows>(step*Step,0);
    operation.run(slice,bg,gate);operation.run(slice,bu,up);
    simdgroup_barrier(mem_flags::mem_threadgroup);
  };
  uint walked=0;
  for(uint run=0;run<2;++run){
    const uint from=run?begin:first,to=run?first:end;
    for(uint step=from;step<to;++step,++walked)
      runStep(step,step+1<to?step+1:begin,walked+1<end-begin);
  }
}
'''
a=original[last:original.index('#define GGUF_DECODE_GATE_UP',last)]
instances='\n'.join('template [[host_name("gguf_decode_af4g64_m'+str(rows)+'_gate_up_n16")]] kernel GgufDecodeGateUpKernel gguf_decode_n16_gate_up<FmtAF4G64,'+str(rows)+'>;' for rows in [16,32,64])
(root/'scripts/af4_n16_gateup_v1.metal').write_text(helper+kernel+a+instances+'\n')
oracle=(root/'scripts/gateup_same_split_oracle_v1.mm').read_text()
oracle=oracle.replace('counters(backend,n/32*4)', 'counters(backend,n/16*4)').replace('count+n/32','count+n/16')
oracle=oracle.replace('std::vector<uint32_t> groups{1,0};','const std::vector<uint32_t> groups=benchmark?std::vector<uint32_t>{0,2,2,0}:std::vector<uint32_t>{1,0,2};')
oracle=oracle.replace('+(groupCount>1?"_sg"+std::to_string(groupCount):"")','+(groupCount==2?"_n16":"")')
oracle=oracle.replace('{n/32,split,1},{32*groupCount,1,1}', '{n/(groupCount==2?16:32),split,1},{32,1,1}')
oracle=oracle.replace('if(groupCount==1)old.assign','if(old.empty()||groupCount==1)old.assign')
oracle=oracle.replace('const double seconds=backend.submitCommandAsync(graph.dispatches()).wait().gpuSeconds;', 'if(benchmark)for(uint32_t warm=0;warm<2;++warm)(void)backend.submitCommandAsync(graph.dispatches()).wait();\n      const double seconds=backend.submitCommandAsync(graph.dispatches()).wait().gpuSeconds;')
oracle=oracle.replace('if(benchmark){run(backend,32,32,17408,5120,true);run(backend,64,64,17408,5120,true);}', 'if(benchmark){run(backend,64,48,17408,5120,true);run(backend,64,64,17408,5120,true);}')

(root/'scripts/af4_n16_oracle_v1.mm').write_text(oracle)
print('Prepared AF4 N16 pair kernel and guarded same-split oracle')

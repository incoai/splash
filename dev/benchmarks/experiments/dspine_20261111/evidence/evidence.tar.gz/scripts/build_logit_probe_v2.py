"""Build an instrumented diagnostic, never used for throughput comparisons."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import sys

root = Path(__file__).resolve().parents[1]
variant = sys.argv[1]
tree = root / variant
out = root / 'artifacts' / f'logit-probe-{variant}-v2'
out.mkdir(exist_ok=False)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
inputs = [root / 'scripts/study_logit_probe_v2.mm', root / 'scripts/probe_support_v2.hpp',
          tree / 'build/engine/libsplash.a', tree / 'build/engine/BuildIdentity.hpp',
          tree / 'build/splash.metallib', tree / 'build/host-step.metallib']
before = {str(p): sha(p) for p in inputs}
subprocess.run(['make', '-C', str(tree), '-j2', 'build/engine/model/RuntimeInstrumented.o'], check=True)
instrumented = tree / 'build/engine/model/RuntimeInstrumented.o'
command = ['xcrun', '-sdk', 'macosx', 'clang++', '-std=c++20', '-O3', '-Wall', '-Wextra', '-Werror',
           '-I' + str(tree / 'runtime'), '-I' + str(tree / 'dev/benchmarks'),
           '-I' + str(root / 'scripts'), '-mmacosx-version-min=26.4', '-fobjc-arc',
           '-include', str(tree / 'build/engine/BuildIdentity.hpp'),
           str(root / 'scripts/study_logit_probe_v2.mm'), str(instrumented),
           str(tree / 'build/engine/libsplash.a'), '-framework', 'Foundation', '-framework', 'Metal',
           '-framework', 'IOKit', '-framework', 'IOSurface', '-o', str(out / 'logit-probe')]
subprocess.run(command, check=True)
assert before == {str(p): sha(p) for p in inputs}, 'production input changed during diagnostic build'
for name in ['splash.metallib', 'host-step.metallib']:
    shutil.copy2(tree / 'build' / name, out / name)
(out / 'build.json').write_text(json.dumps({'command': command, 'inputs': before,
    'instrumented_runtime_sha256': sha(instrumented), 'binary_sha256': sha(out / 'logit-probe'),
    'scope': 'Functional numerical diagnostics with host copies; never a performance artifact.'}, indent=2) + '\n')
print(out)

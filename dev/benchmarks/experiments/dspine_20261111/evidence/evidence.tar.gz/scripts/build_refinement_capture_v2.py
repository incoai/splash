"""Link a separate host-copy diagnostic without mutating production sources."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess

root = Path(__file__).resolve().parents[1]
tree = root / 'production-final-v1'
out = root / 'artifacts/refinement-capture-v2'
out.mkdir(exist_ok=False)
source = tree / 'runtime/model/DFlashDraft.cpp'
text = source.read_text()
needle = '    return;\n  }\n  selector_.add(graph, buffers,'
assert text.count(needle) == 1
text = '#include "refinement_capture_v1.hpp"\n' + text.replace(
    needle,
    '    captureRefinementResearch(graph, weights_, bridge, buffers, anchors, policies, operators_.geometry());\n'
    + needle)
instrumented = out / 'DFlashDraftCapture.cpp'
instrumented.write_text(text)
common = ['xcrun', '-sdk', 'macosx', 'clang++', '-std=c++20', '-O3', '-Wall', '-Wextra', '-Werror',
          '-I' + str(tree / 'runtime'), '-I' + str(tree / 'runtime/model'), '-I' + str(tree / 'dev/benchmarks'), '-I' + str(root / 'scripts'),
          '-mmacosx-version-min=26.4', '-fobjc-arc', '-include', str(tree / 'build/engine/BuildIdentity.hpp')]
commands = [common + ['-c', str(instrumented), '-o', str(out / 'DFlashDraftCapture.o')],
            common + [str(root / 'scripts/study_driver_v2.mm'), str(out / 'DFlashDraftCapture.o'),
                      str(tree / 'build/engine/libsplash.a'), '-framework', 'Foundation', '-framework', 'Metal',
                      '-framework', 'IOKit', '-framework', 'IOSurface', '-o', str(out / 'capture-driver')]]
inputs = [source, root / 'scripts/study_driver_v2.mm', root / 'scripts/refinement_capture_v1.hpp',
          tree / 'build/engine/libsplash.a', tree / 'build/engine/BuildIdentity.hpp']
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
before = {str(p): sha(p) for p in inputs}
for command in commands:
    subprocess.run(command, check=True)
for name in ['splash.metallib', 'host-step.metallib']:
    shutil.copy2(tree / 'build' / name, out / name)
assert before == {str(p): sha(p) for p in inputs}
(out / 'build.json').write_text(json.dumps({'commands': commands, 'inputs': before,
    'generated_source_sha256': sha(instrumented), 'binary_sha256': sha(out / 'capture-driver'),
    'scope': 'Numerical host-copy diagnostic; no production source changes and no throughput evidence.'}, indent=2) + '\n')
print(out)

"""Standalone AF4G64 experiment: same half weights and K order, register input."""
from pathlib import Path
root = Path(__file__).resolve().parents[1]
original = (root / 'runtime16-v10/runtime/metal/kernels/shared/gguf_linear.metal').read_text()
first = original.index('template <class F, ushort Rows>\nkernel void gguf_decode_gate_up')
last = original.index('using GgufDecodeGateUpKernel', first)
kernel = original[first:last].replace('gguf_decode_gate_up(', 'gguf_decode_coop_gate_up(')
a = kernel.index('  threadgroup half2 tl[')
b = kernel.index('  const uint per =', a)
kernel = kernel[:a] + '  threadgroup uint arrival;\n' + kernel[b:]
a = kernel.index('  auto gate = staged_accumulator')
b = kernel.index('  const auto value =', a)
kernel = kernel[:a] + '''  auto inputTensor = tensor(input, dextents<int, 2>{int(p.input_size), Rows},
                            array<int, 2>{1, int(p.input_size)});
  constexpr auto descriptor = matmul2d_descriptor(Rows, GGUF_STAGED_COLUMNS, GGUF_STAGED_STEP,
      false, true, false, matmul2d_descriptor::mode::multiply_accumulate);
  matmul2d<descriptor, execution_simdgroup> operation;
  auto right = operation.template get_right_input_cooperative_tensor<bfloat, half, float>();
  auto gate = operation.template get_destination_cooperative_tensor<decltype(inputTensor), decltype(right), float>();
  auto up = operation.template get_destination_cooperative_tensor<decltype(inputTensor), decltype(right), float>();
  gguf_zero(gate); gguf_zero(up);
  const uint sf = staged_first_step(group.x / 2, sb, se, p.spread);
  for (uint run = 0; run < 2; ++run) {
    const uint from = run ? sb : sf, to = run ? sf : se;
    for (uint step = from; step < to; ++step) {
      auto a = inputTensor.template slice<GGUF_STAGED_STEP, Rows>(step * GGUF_STAGED_STEP, 0);
      affine_cooperative_half<F>(right, gw0, gw1, gmeta, p.input_size, origin, step);
      operation.run(a, right, gate);
      affine_cooperative_half<F>(right, uw0, uw1, umeta, p.input_size, origin, step);
      operation.run(a, right, up);
    }
  }
''' + kernel[b:]
prefix = '''#pragma clang fp reassociate(off)
#include "metal/kernels/common/gguf_staged_tile.h"
#include "metal/kernels/common/split_reduce.h"

// Use public cooperative-tensor coordinates, rather than assuming a particular
// compiler's lane layout. Unroll the small right operand so repeated chunk and
// metadata loads can be shared. AF4 metadata is BF16 scale/bias; decode with the
// same float FMA and half rounding as dequant32_chunks before each tensor op.
template<class F, class Right>
inline void affine_cooperative_half(thread Right &right, device uchar *w0, device uchar *w1,
                                    device uchar *meta, uint inputSize, uint origin, uint step) {
  const uint groups = inputSize / 32, units = groups / F::MetaGroups;
#pragma unroll
  for (ushort i = 0; i < right.get_capacity(); ++i) {
    if (!right.is_valid_element(i)) continue;
    const auto index = right.get_multidimensional_index(i);
    const uint k = index[0], column = origin + index[1];
    const uint tile = column / QUANT_TILE_ROWS, row = column % QUANT_TILE_ROWS;
    const ulong group = (ulong(tile) * groups + step) * QUANT_TILE_ROWS + row;
    const ulong unit = (ulong(tile) * units + step / F::MetaGroups) * QUANT_TILE_ROWS + row;
    const auto chunk = F::loadChunk(w0 + group * F::P0, w1 + group * F::P1, ushort((k % 16) / 4));
    const uint4 pairs = F::codes(chunk);
    const uint pair = pairs[(k % 4) / 2 + (k / 16) * 2];
    const uint code = (pair >> ((k % 2) * 16)) & 0xffffu;
    const QuantCoef coefficient = F::coef(F::loadMeta(meta + unit * F::MetaBytes), ushort(step % F::MetaGroups));
    const float scale = k < 16 ? coefficient.s.x : coefficient.s.y;
    const float bias = k < 16 ? coefficient.m.x : coefficient.m.y;
    right[i] = half(fma(float(code), scale, bias));
  }
}
'''
alias_end = original.index('#define GGUF_DECODE_GATE_UP', last)
alias = original[last:alias_end]
instances = '\n'.join(
    'template [[host_name("gguf_decode_af4g64_coop_m' + str(rows) + '_gate_up")]] '
    'kernel GgufDecodeGateUpKernel gguf_decode_coop_gate_up<FmtAF4G64, ' + str(rows) + '>;'
    for rows in [16, 32, 64])
(root / 'scripts/af4_coop_gateup_v1.metal').write_text(prefix + kernel + alias + instances + '\n')

oracle = (root / 'scripts/gateup_same_split_oracle_v1.mm').read_text()
oracle = oracle.replace('std::vector<uint32_t> groups{1,0};', 'std::vector<uint32_t> groups{1,0,2};')
old = 'const std::string name="gguf_decode_af4g64_m"+std::to_string(rows)+"_gate_up"+(groupCount>1?"_sg"+std::to_string(groupCount):"");'
new = 'const std::string name=std::string(groupCount==2?"gguf_decode_af4g64_coop_m":"gguf_decode_af4g64_m")+std::to_string(rows)+"_gate_up";'
assert old in oracle
oracle = oracle.replace(old, new).replace('{32*groupCount,1,1}', '{32,1,1}')
oracle = oracle.replace('if(benchmark){run(backend,32,32,17408,5120,true);',
                        'if(benchmark){run(backend,16,16,17408,5120,true);run(backend,32,32,17408,5120,true);')
(root / 'scripts/af4_coop_oracle_v1.mm').write_text(oracle)
print('Prepared standalone register-input kernel and same-split oracle')

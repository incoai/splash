"""Describe work in every retained, readable round without changing its verdict."""

import argparse
import hashlib
import json
from pathlib import Path

labels = (
    "dspine16-final-v1",
    "dflash8-vs-dspine16-final-v1",
    "dflash8-vs-dspine16-b4-final-v1",
    "agent12-dflash8-vs-dspine16-final-v1",
    "m48-b3-research-v1",
)


def request_work(request):
    cycles = request["draft_cycles"]
    return {
        "batches": len(cycles),
        "emitted": sum(row["output_tokens"] for row in cycles),
        "returned": len(request["output_tokens"]),
        "drafted": sum(row["drafted_tokens"] for row in cycles),
        "accepted": sum(row["accepted_draft_tokens"] for row in cycles),
        "gpu_ms": request["decode_gpu_ms"],
        "prefill_gpu_ms": request["prefill_gpu_ms"],
    }


def clone_work(request):
    return {
        "batches": request["decode_batches"],
        "emitted": request["decode_output_tokens"],
        "returned": sum(len(lane) for lane in request["lane_outputs"]),
        "drafted": request["drafted_tokens"],
        "accepted": request["accepted_draft_tokens"],
        "gpu_ms": request["decode_gpu_ms"],
        "prefill_gpu_ms": request["prefill_gpu_ms"],
    }


def summarize(records, lanes):
    totals = {name: sum(row[name] for row in records) for name in records[0]}
    return {
        "requests": len(records),
        "lanes": lanes,
        "totals": totals,
        "gpu_ms_per_batch": totals["gpu_ms"] / totals["batches"],
        "emitted_tokens_per_lane_batch": totals["emitted"]
        / (lanes * totals["batches"]),
        "gpu_emitted_tokens_per_second": 1000 * totals["emitted"] / totals["gpu_ms"],
        "accepted_fraction": totals["accepted"] / totals["drafted"],
        "mean_prefill_gpu_ms": totals["prefill_gpu_ms"] / len(records),
    }


def comparison(evidence, label):
    path = evidence / "results" / (label + ".comparison.json")
    verdict = json.loads(path.read_text())
    protocol = verdict["protocol"]
    lanes = protocol["clone_width"]
    secondary = set(protocol.get("exclude_primary_cases", []))
    groups = []
    for group in verdict["groups"]:
        arm_rows = {"control": [], "candidate": []}
        sources = []
        for source in group["sources"]:
            ident = source["job"]
            raw = (evidence / "results" / (ident + ".stdout")).read_bytes()
            assert hashlib.sha256(raw).hexdigest() == source["sha256"]
            document = json.loads(raw)
            arm = "control" if ident.endswith(("a1", "a2")) else "candidate"
            if lanes == 1:
                requests = document["measurements"]
                extract = request_work
            else:
                requests = document["decode_throughput"]["samples"]
                extract = clone_work
            arm_rows[arm].extend(
                extract(request)
                for request in requests
                if request["scenario"] not in secondary
            )
            sources.append({"job": ident, "sha256": source["sha256"]})
        summary = {
            "group": group["group"],
            "frozen_qualified": group["qualified"],
            "frozen_problems": group["problems"],
            "sources": sources,
            "arms": {
                arm: summarize(rows, lanes) for arm, rows in arm_rows.items() if rows
            },
        }
        if len(sources) == 4 and "cases" in group:
            control, candidate = (
                summary["arms"][arm] for arm in ("control", "candidate")
            )
            summary["candidate_divided_by_control"] = {
                key: candidate[key] / control[key]
                for key in (
                    "gpu_ms_per_batch",
                    "emitted_tokens_per_lane_batch",
                    "gpu_emitted_tokens_per_second",
                    "mean_prefill_gpu_ms",
                )
            }
        groups.append(summary)
    return {"label": label, "frozen_qualified": verdict["qualified"], "groups": groups}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--evidence", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    report = {
        "scope": (
            "Descriptive work accounting of every round accepted as a source by the "
            "frozen analyzer. Primary cases only, with all internal repetitions pooled "
            "within each ABBA arm. Token and GPU sums are separate from the registered "
            "wall endpoints. Requests ending at different outputs do different work. "
            "Incomplete groups have no pooled cross-arm ratio. No additional gate."
        ),
        "comparisons": [comparison(args.evidence, label) for label in labels],
    }
    with args.output.open("x") as stream:
        json.dump(report, stream, indent=2)
        stream.write("\n")


if __name__ == "__main__":
    main()

"""Append a separate M48 comparison after every final production experiment."""
from pathlib import Path
import datetime as dt
import hashlib
import json

root = Path(__file__).resolve().parents[1]
label = 'm48-b3-research-v1'
path = root / 'notes' / (label + '.protocol.json')
assert not path.exists()
eligibility_path = root / 'notes/m48-research-v1-comparison-eligibility.json'
eligibility = json.loads(eligibility_path.read_text())
assert eligibility['source_nominated_for_research_comparison']
assert (root / 'notes/final-comparison-nominations-v1.json').exists()
assert (root / 'notes/sampling4-nominations-v1.json').exists()
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
cohort = root / 'cohorts/kernel-smoke3-cap256-v1.txt'
ds = Path('/Users/linson/Documents/ai/splash/build/dspine/model-root.txt').read_text().strip()
layout = json.loads((root / 'results/final-smoke-dspine16-v1.stdout').read_text())['identity']['loaded_model_layout_sha256']
names = ['production-final-v1', 'm48-research-v1']
nomination = {}
for name in names:
    bundle = root / 'artifacts' / ('study-' + name + '-v2')
    patch = root / 'patches' / (name + '.patch')
    nomination[name] = {'source_root': str(root / name), 'patch': str(patch), 'patch_sha256': sha(patch),
        'build_manifest': str(root / 'artifacts' / name / 'build.json'), 'driver': str(bundle / 'study-driver'),
        'library': str(bundle / 'splash.metallib'), 'host_step': str(bundle / 'host-step.metallib')}
arms = {key: {'variant': name, 'rows': 16, 'model_root': ds, 'loaded_model_layout_sha256': layout}
        for key, name in zip(['control', 'candidate'], names)}
required = eligibility['required_receipts'] + ['validate-m48-research-v1', 'final-host-sanitizers-v1']
protocol = {'frozen_utc': dt.datetime.now(dt.timezone.utc).isoformat(), 'prefix': label, 'groups': 3,
    'order_each_group': ['control', 'candidate', 'candidate', 'control'], 'arms': arms,
    'cohort': str(cohort), 'cohort_sha256': sha(cohort), 'cases': 3, 'samples_per_round': 3,
    'criterion': 'improvement', 'context_tokens': 32768, 'temperature': 0, 'ane_ffn_share': 0,
    'verify_rows': 'all', 'clone_width': 3, 'primary_endpoint': 'decode',
    'primary_metric': 'Fixed three shared-prompt cloned lanes; token-weighted aggregate decode wall/output work. Prefix warmup outside the request wall. Not heterogeneous HTTP latency.',
    'gates': 'Exactly3ABBAgroups; complete arrays match; every case and aggregate spread<=5%; throughput improvement exceeds the existing max(2%,twice spread) latency-effect bound. Sampled AC/no swap/no serious or critical thermal state and idle launch gates. No repeat-to-pass.',
    'artifact_nomination': nomination, 'required_receipts': required,
    'operating_script_sha256': sha(root / 'scripts/controlled_round.py'),
    'analyzer_file': 'analyze_abba_v2.py', 'analyzer_sha256': sha(root / 'scripts/analyze_abba_v2.py'),
    'abba_sha256': sha(root / 'scripts/abba.py'), 'eligibility_sha256': sha(eligibility_path),
    'scope': 'Historical calibration prompts. Separate research candidate chosen from its prospective operator screen; already frozen final serving source and agent12/sampling4 arms are unchanged. This candidate does not run those fresh cohorts. Entire comparison is last, after all registered final production experiments; deadline may leave it incomplete.'}
path.write_text(json.dumps(protocol, indent=2) + '\n')
q = root / 'queue.jsonl'
jobs = [json.loads(s) for s in q.read_text().splitlines()]
assert any(j['id'] == 'analyze-agent12-dflash8-vs-dspine16-final-v1' for j in jobs)
preflight = 'freeze-artifacts-' + label
jobs.append({'id': preflight, 'command': ['python3', str(root / 'scripts/freeze_abba_artifacts_v2.py'), str(path)],
    'artifacts': [str(path), str(root / 'scripts/freeze_abba_artifacts_v2.py')], 'requires': required,
    'timeout_seconds': 120})
for group in range(1, 4):
    for suffix in ['a1', 'b1', 'b2', 'a2']:
        name = names[0 if suffix.startswith('a') else 1]
        bundle = nomination[name]
        ident = f'{label}-g{group}-{suffix}'
        command = [bundle['driver'], bundle['library'], ds, '--draft-block-size', '16', '--study-width', '3',
            '--cohort', str(cohort), '--samples', '3', '--ane-ffn-share', '0', '--max-context', '32768',
            '--progress', str(root / 'results' / (ident + '.progress.jsonl'))]
        jobs.append({'id': ident, 'command': ['python3', str(root / 'scripts/run_frozen_abba_round_v1.py'), str(path), ident, *command],
            'artifacts': [bundle[k] for k in ['driver', 'library', 'host_step']] + [str(cohort), str(path),
                str(root / 'scripts/controlled_round.py'), str(root / 'scripts/run_frozen_abba_round_v1.py')],
            'requires': [preflight], 'timeout_seconds': 1800,
            'classification': 'Controlled separate M48research comparison; no concurrent heavy CPU/build/I/O'})
jobs.append({'id': 'analyze-' + label,
    'command': ['python3', str(root / 'scripts/analyze_abba_v2.py'), str(path), str(root / 'results' / (label + '.comparison.json'))],
    'artifacts': [str(path), str(root / 'scripts/analyze_abba_v2.py'), str(root / 'scripts/abba.py')], 'timeout_seconds': 60})
ids = [j['id'] for j in jobs]
assert len(ids) == len(set(ids))
assert all(d in ids or (root / 'results' / (d + '.receipt.json')).exists() for j in jobs for d in j.get('requires', []))
temporary = q.with_suffix('.tmp')
temporary.write_text(''.join(json.dumps(j) + '\n' for j in jobs))
temporary.replace(q)
print('Registered the separate full3ABBA M48study last; final production source unchanged.')

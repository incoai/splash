"""Nominate the final source once; register all production comparisons before data."""
from pathlib import Path
from collections import defaultdict
import datetime as dt
import hashlib
import json
import shutil
import sys

root=Path(__file__).resolve().parents[1]
variant=sys.argv[1]
selection_path=root/'notes'/f'{variant}-nomination.json'
selection=json.loads(selection_path.read_text())
assert selection['variant']==variant and selection['source_nominated'] is True
assert not (root/'notes/final-comparison-nominations-v1.json').exists(), 'already nominated'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
model_base=Path('/Users/linson/Documents/ai/splash/build/dspine')
ds=Path((model_base/'model-root.txt').read_text().strip())
df=Path((model_base/'dflash-root.txt').read_text().strip())
identities={str(ds):json.loads((root/'results/core-v12-smoke-r16.stdout').read_text())['identity']['loaded_model_layout_sha256'],
            str(df):json.loads((root/'results/calibration-dflash8-smoke3-v9.stdout').read_text())['identity']['loaded_model_layout_sha256']}
# Historical data stay clearly separate from the fresh registered agent tasks.
historical=root/'cohorts/historical31-v1.txt'
assert not historical.exists()
shutil.copy2('/Users/linson/Documents/ai/splash-dspine-investigation-20261110/notes/cohort31.txt',historical)
agent=root/'cohorts/agent12-v1.txt'
agent_protocol=json.loads((root/'cohorts/agent12-v1.protocol.json').read_text())
assert sha(agent)==agent_protocol['sha256']
categories=defaultdict(list)
for case in agent_protocol['cases']:categories[case['category']].append(case['name'])
patch=root/'patches'/f'{variant}.patch'
assert sha(patch)==selection['patch_sha256']
nomination={}
for name in ['control',variant]:
    bundle=root/'artifacts'/f'study-{name}-v2'
    manifest=root/'artifacts'/name/'build.json'
    assert bundle.is_dir() and manifest.is_file()
    nomination[name]={'source_root':str(root/name),'patch':None if name=='control' else str(patch),
                     'patch_sha256':None if name=='control' else sha(patch),
                     'build_manifest':str(manifest),'driver':str(bundle/'study-driver'),
                     'library':str(bundle/'splash.metallib'),'host_step':str(bundle/'host-step.metallib')}

def arm(name,rows,model):
    return {'variant':name,'rows':rows,'model_root':str(model),'loaded_model_layout_sha256':identities[str(model)]}

comparisons=[
 ('default8-final-v1',arm('control',8,ds),arm(variant,8,ds),root/'cohorts/kernel-smoke3-cap256-v1.txt',3,'nonregression',1),
 ('dspine16-final-v1',arm('control',8,ds),arm(variant,16,ds),historical,2,'improvement',1),
 ('dflash8-vs-dspine16-final-v1',arm(variant,8,df),arm(variant,16,ds),historical,2,'comparison',1),
 ('dflash8-vs-dspine16-b4-final-v1',arm(variant,8,df),arm(variant,16,ds),root/'cohorts/kernel-smoke3-cap256-v1.txt',1,'comparison',4),
 ('agent12-dflash8-vs-dspine16-final-v1',arm(variant,8,df),arm(variant,16,ds),agent,1,'comparison',1)]
queue=root/'queue.jsonl';jobs=[json.loads(s) for s in queue.read_text().splitlines()]
registered=[]
for label,a,b,cohort,samples,criterion,width in comparisons:
    protocol={'frozen_utc':dt.datetime.now(dt.timezone.utc).isoformat(),'prefix':label,'groups':3,
       'order_each_group':['control','candidate','candidate','control'],'arms':{'control':a,'candidate':b},
       'cohort':str(cohort),'cohort_sha256':sha(cohort),'cases':len(cohort.read_text().splitlines()),
       'samples_per_round':samples,'criterion':criterion,'context_tokens':32768,'temperature':0,
       'ane_ffn_share':0,'verify_rows':'all','clone_width':width,'primary_endpoint':'decode',
       'primary_metric':'Per-case median (wall-TTFT)/(returned tokens-1), then token-weighted aggregate.' if width==1 else 'Fixed physical clone width4; GPU-stream decode wall/decode output tokens, then token-weighted aggregate. Shared-prompt warm-model capacity, not heterogeneous HTTP latency.',
       'gates':'Exactly3ABBA groups. All complete arrays match; all per-case and aggregate decode spreads<=5%. Improvement exceeds max(2%,twice spread); nonregression requires aggregate and every case to pass its allowance. Cold request wall and TTFT each retain independent gates. Sampled AC, no swap and no serious/critical thermal state throughout each saved round. No repeat-to-pass.',
       'artifact_nomination':{n:nomination[n] for n in {a['variant'],b['variant']}},
       'operating_script_sha256':sha(root/'scripts/controlled_round.py'),
       'analyzer_file':'analyze_abba_v2.py','analyzer_sha256':sha(root/'scripts/analyze_abba_v2.py'),
       'abba_sha256':sha(root/'scripts/abba.py'),'required_receipts':selection['required_receipts']}
    if cohort==historical:protocol['exclude_primary_cases']=['count_secondary']
    if cohort==agent:
        protocol['categories']=dict(categories)
        protocol['scope']='Fresh twelve original synthetic software-agent prompts, four each at short/~4K/~16K context. Performance/exact-output fixtures, not scored agent task success. Source nomination is frozen before first output; no performance-driven candidate changes afterwards.'
    else:protocol['scope']='Historical calibration prompts; not independent heldout evidence.'
    path=root/'notes'/f'{label}.protocol.json';assert not path.exists();path.write_text(json.dumps(protocol,indent=2)+'\n')
    preflight='freeze-artifacts-'+label
    jobs.append({'id':preflight,'command':['python3',str(root/'scripts/freeze_abba_artifacts_v2.py'),str(path)],
      'artifacts':[str(path),str(root/'scripts/freeze_abba_artifacts_v2.py')],
      'requires':selection['required_receipts']+[f'build-study-{variant}-v2'], 'timeout_seconds':120})
    for group in range(1,4):
      for suffix in ['a1','b1','b2','a2']:
        selected=a if suffix.startswith('a') else b
        bundle=nomination[selected['variant']]
        ident=f'{label}-g{group}-{suffix}'
        command=[bundle['driver'],bundle['library'],selected['model_root'],'--draft-block-size',str(selected['rows']),
                 '--cohort',str(cohort),'--samples',str(samples),'--ane-ffn-share','0','--max-context','32768',
                 '--progress',str(root/'results'/f'{ident}.progress.jsonl')]
        if width>1:command+=['--study-width',str(width)]
        jobs.append({'id':ident,'command':['python3',str(root/'scripts/run_frozen_abba_round_v1.py'),str(path),ident,*command],
          'artifacts':[bundle[k] for k in ['driver','library','host_step']]+[str(cohort),str(path),str(root/'scripts/controlled_round.py'),str(root/'scripts/run_frozen_abba_round_v1.py')],
          'requires':[preflight],'timeout_seconds':1800,'classification':'Controlled production comparison; no concurrent owned GPU or heavy CPU/I/O'})
    jobs.append({'id':'analyze-'+label,'command':['python3',str(root/'scripts/analyze_abba_v2.py'),str(path),str(root/'results'/f'{label}.comparison.json')],
       'artifacts':[str(path),str(root/'scripts/analyze_abba_v2.py'),str(root/'scripts/abba.py')],'timeout_seconds':60})
    registered.append({'prefix':label,'protocol_sha256':sha(path)})
record={'frozen_utc':dt.datetime.now(dt.timezone.utc).isoformat(),'variant':variant,
        'selection':selection,'selection_sha256':sha(selection_path),'comparisons':registered,
        'agent_cohort_sha256':sha(agent),'sampling_cohort_sha256':sha(root/'cohorts/sampling4-v1.txt'),
        'scope':'Final source selected before any agent12 or sampling4 model outputs. Preserve every registered result; no source substitution based on these heldout outcomes.'}
(root/'notes/final-comparison-nominations-v1.json').write_text(json.dumps(record,indent=2)+'\n')
ids=[j['id'] for j in jobs];assert len(ids)==len(set(ids))
assert all(d in ids or (root/'results'/f'{d}.receipt.json').exists() for j in jobs for d in j.get('requires',[]))
t=queue.with_suffix('.tmp');t.write_text(''.join(json.dumps(j)+'\n' for j in jobs));t.replace(queue)
print(json.dumps(record,indent=2))

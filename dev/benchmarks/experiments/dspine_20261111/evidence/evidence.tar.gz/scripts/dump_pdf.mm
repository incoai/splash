#import <Foundation/Foundation.h>
#import <PDFKit/PDFKit.h>
#include <iostream>
int main(int argc, char **argv) {
  @autoreleasepool {
    if (argc != 2) return 2;
    PDFDocument *document = [[PDFDocument alloc] initWithURL:[NSURL fileURLWithPath:[NSString stringWithUTF8String:argv[1]]]];
    if (!document) return 1;
    std::cout << document.string.UTF8String;
  }
}

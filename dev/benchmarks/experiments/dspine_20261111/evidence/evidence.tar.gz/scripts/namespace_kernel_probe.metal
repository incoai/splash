#include <metal_stdlib>
using namespace metal;
namespace width8 {
[[host_name("geometry_probe8")]] kernel void probe(device uint *out [[buffer(0)]], uint tid [[thread_position_in_grid]]) { out[tid] = 8; }
}
namespace width16 {
[[host_name("geometry_probe16")]] kernel void probe(device uint *out [[buffer(0)]], uint tid [[thread_position_in_grid]]) { out[tid] = 16; }
}

"""Refuse any nominated artifact change before executing a timed round."""
from pathlib import Path
import hashlib
import json
import os
import sys

root = Path(__file__).resolve().parents[1]
protocol_path, ident, *command = sys.argv[1:]
protocol = json.loads(Path(protocol_path).read_text())
barrier = json.loads((root / 'notes' / f"{protocol['prefix']}.artifact-barrier.json").read_text())
for path, expected in barrier['sha256'].items():
    assert hashlib.sha256(Path(path).read_bytes()).hexdigest() == expected, 'nominated artifact changed: ' + path
os.execv(sys.executable, [sys.executable, str(root / 'scripts/controlled_round.py'), ident, *command])

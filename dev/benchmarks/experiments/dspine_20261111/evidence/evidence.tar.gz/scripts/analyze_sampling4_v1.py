"""Frozen independent-seed distribution regression screen; not an equivalence proof."""
from pathlib import Path
from collections import Counter, defaultdict
import hashlib, json
import numpy as np
from scipy.stats import chi2_contingency

r = Path(__file__).resolve().parents[1]
protocol = json.loads((r/'notes/sampling4-protocol-v1.json').read_text())
nomination = json.loads((r/'notes/sampling4-nominations-v1.json').read_text())
barrier = json.loads((r/'notes/sampling4-v1.artifact-barrier.json').read_text())
cohort = r/'cohorts'/protocol['cohort']
assert hashlib.sha256(cohort.read_bytes()).hexdigest() == protocol['cohort_sha256']
case_names = {line.split()[0] for line in cohort.read_text().splitlines()}

def load(arm):
    cases = defaultdict(dict); sources = []
    for ident in arm['jobs']:
        path = r/f'results/{ident}.stdout'
        receipt = json.loads((r/f'results/{ident}.receipt.json').read_text())
        assert receipt['exit_code'] == 0 and receipt['state'] == 'complete'
        d = json.loads(path.read_text())
        assert d['study_temperature'] == 1
        assert d['ane_ffn_share'] == 0 and d['max_context_tokens'] == protocol['settings']['context_limit']
        assert receipt['artifact_sha256'] == receipt['artifact_sha256_after'], 'artifact changed'
        nominated = nomination['artifact_nomination'][arm['variant']]
        for key in ['driver', 'library', 'host_step']:
            artifact = nominated[key]
            assert receipt['artifact_sha256'][artifact] == barrier['sha256'][artifact], 'artifact differs from nomination'
        assert receipt['artifact_sha256'][nomination['cohort']] == protocol['cohort_sha256'], 'executed cohort differs'
        assert receipt['job']['command'][3:6] == [nominated['driver'], nominated['library'], arm['model_root']], 'executed arm differs'
        assert d['identity']['loaded_model_layout_sha256'] == arm['loaded_model_layout_sha256']
        assert d['geometry']['verify_rows'] == arm['verify_rows']
        assert d['identity']['model_root'] == arm['model_root']
        for m in d['measurements']:
            seed = d['study_seed_base']+m['sample']; name = m['scenario']
            assert seed not in cases[name], 'duplicate sample seed'
            assert 0 <= len(m['output_tokens']) <= protocol['output_cap'], 'invalid output length'
            for cycle in m.get('draft_cycles', []):
                assert 0 <= cycle['accepted_draft_tokens'] <= cycle['drafted_tokens'] <= arm['verify_rows']-1
                assert 0 <= cycle['output_tokens'] <= arm['verify_rows']+1
            cases[name][seed] = m['output_tokens']
        sources.append({'job': ident, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
                        'build_id': d['build_id'], 'geometry': d['geometry']})
    expected = set(range(arm['seed_start'], arm['seed_start']+protocol['samples_per_arm_per_context']))
    assert set(cases) == case_names and len(cases) == protocol['contexts'] and all(set(v) == expected for v in cases.values())
    return cases, sources

def feature(sequence, indices):
    return tuple(sequence[i] if i < len(sequence) else -1 for i in indices)

def test(a, b):
    na, nb = sum(a.values()), sum(b.values()); total = a+b
    common = sorted((key for key, count in total.items() if count*min(na, nb)/(na+nb) >= 5), key=repr)
    bins = [[a[key], b[key]] for key in common]
    rare = [na-sum(v[0] for v in bins), nb-sum(v[1] for v in bins)]
    if sum(rare):
        if sum(rare)*min(na, nb)/(na+nb) >= 5 or not bins: bins.append(rare)
        else:
            largest = max(range(len(bins)), key=lambda i: sum(bins[i]))
            bins[largest] = [bins[largest][i]+rare[i] for i in range(2)]
    if len(bins) < 2:
        return {'pvalue': 1.0, 'informative': False, 'sample_counts': [na, nb], 'bins': len(bins)}
    table = np.array(bins, dtype=np.int64).T
    result = chi2_contingency(table, correction=False)
    assert result.expected_freq.min() >= 5-1e-9
    return {'pvalue': float(result.pvalue), 'statistic': float(result.statistic), 'degrees_of_freedom': result.dof,
            'minimum_expected_count': float(result.expected_freq.min()), 'bins': len(bins),
            'sample_counts': [na, nb], 'informative': True,
            'cramers_v': float(np.sqrt(result.statistic/(na+nb))),
            'empirical_pooled_total_variation': float(np.abs(table[0]/na-table[1]/nb).sum()/2),
            'note': 'Empirical distance includes finite-sample noise and pooling can hide rare-category changes.'}

errors = {}
baseline, baseline_sources = None, []
try:
    baseline, baseline_sources = load(nomination['control'])
except (OSError, ValueError, AssertionError, KeyError) as error:
    errors[nomination['control']['name']] = str(error)
features = [(i,) for i in protocol['positions']]+[(i, i+1) for i in protocol['adjacent_pair_starts']]
family_size = protocol['family_size_reserved']
results = []; candidate_sources = {}
for arm in nomination['candidates']:
    try:
        values, sources = load(arm)
    except (OSError, ValueError, AssertionError, KeyError) as error:
        errors[arm['name']] = str(error)
        continue
    candidate_sources[arm['name']] = sources
    if baseline is None:
        continue
    assert values.keys() == baseline.keys()
    for name in sorted(baseline):
        for indices in features + [None]:
            feature_value = (lambda v: len(v)) if indices is None else (lambda v: feature(v, indices))
            a = Counter(feature_value(v) for v in baseline[name].values())
            b = Counter(feature_value(v) for v in values[name].values())
            results.append(dict(candidate=arm['name'], context=name, feature='complete_output_length' if indices is None else 'tokens', positions_zero_based=list(indices) if indices else None, **test(a, b)))
assert len(results) <= family_size
ordered = sorted(range(len(results)), key=lambda i: results[i]['pvalue'])
previous = 0.0
for rank, index in enumerate(ordered):
    adjusted = min(1.0, max(previous, (family_size-rank)*results[index]['pvalue']))
    results[index]['holm_adjusted_pvalue'] = adjusted
    results[index]['reject_at_family_alpha_0_05'] = adjusted < 0.05
    previous = adjusted
record = {'protocol': protocol, 'nomination': nomination, 'baseline_sources': baseline_sources,
          'candidate_sources': candidate_sources, 'family_size_reserved': family_size, 'tests_observed': len(results),
          'status': 'complete' if not errors else 'incomplete', 'errors': errors,
          'unobserved_reserved_tests': family_size-len(results),
          'rejections': sum(v['reject_at_family_alpha_0_05'] for v in results), 'results': results,
          'interpretation': 'A finite regression screen. An incomplete arm is not replaced or analyzed as a smaller sample; its unobserved tests retain p=1 in the reserved family and no complete-screen verdict is inferred. No rejection is not proof of identical distributions, especially for rare outputs. Retain all comparisons and report uninformative tests.'}
(r/'results/sampling4-comparison-v1.json').write_text(json.dumps(record, indent=2)+'\n')
print(json.dumps({k: v for k, v in record.items() if k in ['status', 'errors', 'family_size_reserved', 'tests_observed', 'unobserved_reserved_tests', 'rejections']}))

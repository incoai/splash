"""Freeze baseline and candidate artifacts before their first model output."""
from pathlib import Path
import datetime as dt
import hashlib
import json
import subprocess
import sys

root = Path(__file__).resolve().parents[1]
protocol_path = Path(sys.argv[1])
protocol = json.loads(protocol_path.read_text())
base = json.loads((root/'session.json').read_text())['baseline_commit']


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


hashes = {str(protocol_path): sha(protocol_path)}
source_records = {}
cohort = Path(protocol['cohort'])
assert sha(cohort) == protocol['cohort_sha256'], 'cohort changed'
hashes[str(cohort)] = sha(cohort)
for variant, arm in protocol['artifact_nomination'].items():
    for key in ['build_manifest', 'driver', 'library', 'host_step']:
        hashes[arm[key]] = sha(arm[key])
    build = json.loads(Path(arm['build_manifest']).read_text())
    assert build['base'] == base, 'different source baseline'
    if arm['patch'] is None:
        assert build['patch'] is None and build['patch_sha256'] is None
        assert build['source_diff_sha256'] == hashlib.sha256(b'').hexdigest()
    else:
        hashes[arm['patch']] = sha(arm['patch'])
        assert hashes[arm['patch']] == arm['patch_sha256'], 'nominated patch changed'
        assert build['patch_sha256'] == arm['patch_sha256'], 'build does not match patch'
    tree = Path(arm['source_root'])
    paths = subprocess.check_output(['git', '-C', str(tree), 'ls-files', '-z',
                                    '--cached', '--others', '--exclude-standard']).decode().split('\0')
    manifest = {name: sha(tree/name) if (tree/name).is_file() else None
                for name in sorted(set(paths)) if name}
    manifest_sha = hashlib.sha256(json.dumps(manifest, sort_keys=True).encode()).hexdigest()
    if 'source_manifest' in build:
        assert manifest == build['source_manifest'], 'built source changed'
        assert manifest_sha == build['source_manifest_sha256']
    else:
        assert arm['patch'] is None, 'candidate lacks a complete source manifest'
        assert subprocess.check_output(['git', '-C', str(tree), 'rev-parse', 'HEAD']).decode().strip() == base
        assert not subprocess.check_output(['git', '-C', str(tree), 'status', '--porcelain']), 'baseline source changed'
    source_records[variant] = {'source_manifest_sha256': manifest_sha, 'files': len(manifest)}
    driver_path = Path(arm['driver']).parent/'build.json'
    hashes[str(driver_path)] = sha(driver_path)
    driver = json.loads(driver_path.read_text())
    assert driver['binary_sha256'] == hashes[arm['driver']], 'driver build mismatch'
    assert sha(Path(arm['build_manifest']).parent/'splash.metallib') == hashes[arm['library']], 'shader differs'
    assert sha(Path(arm['build_manifest']).parent/'host-step.metallib') == hashes[arm['host_step']], 'host step differs'
    for path, expected in driver['inputs'].items():
        assert sha(path) == expected, 'driver build input changed: ' + path
for name, key in [('controlled_round.py', 'operating_script_sha256'),
                  (protocol.get('analyzer_file', 'analyze_abba_v2.py'), 'analyzer_sha256'),
                  ('abba.py', 'abba_sha256')]:
    path = root/'scripts'/name
    hashes[str(path)] = sha(path)
    assert hashes[str(path)] == protocol[key], 'protocol implementation changed'
for name in ['run_frozen_abba_round_v1.py', 'run_frozen_job_v1.py']:
    path = root/'scripts'/name
    if path.exists():
        hashes[str(path)] = sha(path)
for ident in protocol.get('required_receipts', []):
    path = root/'results'/f'{ident}.receipt.json'
    receipt = json.loads(path.read_text())
    assert receipt['state'] == 'complete' and receipt['exit_code'] == 0, 'required validation failed: ' + ident
    hashes[str(path)] = sha(path)
path = root/'notes'/f"{protocol['prefix']}.artifact-barrier.json"
assert not path.exists(), 'artifact barrier already exists'
path.write_text(json.dumps({'frozen_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
                           'protocol': str(protocol_path), 'sha256': hashes,
                           'source_validation': source_records}, indent=2)+'\n')
print(path)

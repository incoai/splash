from pathlib import Path
import json,subprocess,sys,hashlib,shutil
r=Path(__file__).resolve().parents[1]
name=sys.argv[1]
tree=r/name;build=tree/'build';out=r/'artifacts'/f'study-{name}-v1';out.mkdir(exist_ok=False)
inputs=[r/'scripts/study_driver_v1.mm',build/'engine/libsplash.a',build/'engine/BuildIdentity.hpp',build/'splash.metallib',tree/'dev/benchmarks/PrefillWork.hpp',tree/'dev/benchmarks/TranscriptPrompts.hpp']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
before={str(p):sha(p) for p in inputs}
cmd=['xcrun','-sdk','macosx','clang++','-std=c++20','-O3','-Wall','-Wextra','-Werror','-I'+str(tree/'runtime'),'-I'+str(tree/'dev/benchmarks'),'-mmacosx-version-min=26.4','-fobjc-arc','-include',str(build/'engine/BuildIdentity.hpp'),str(r/'scripts/study_driver_v1.mm'),str(build/'engine/libsplash.a'),'-framework','Foundation','-framework','Metal','-framework','IOKit','-framework','IOSurface','-o',str(out/'study-driver')]
subprocess.run(cmd,check=True)
for f in ['splash.metallib','host-step.metallib']:shutil.copy2(build/f,out/f)
after={str(p):sha(p) for p in inputs}
assert before==after,'Study build inputs changed'
(out/'build.json').write_text(json.dumps({'variant':name,'command':cmd,'inputs':before,'binary_sha256':sha(out/'study-driver')},indent=2)+'\n')
print(out)

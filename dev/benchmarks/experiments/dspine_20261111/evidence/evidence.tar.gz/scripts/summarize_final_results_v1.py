"""Summarize every registered endpoint after the fixed research window ends."""

from pathlib import Path
import datetime as dt
import hashlib
import json
import subprocess
import sys
import time

root = Path(__file__).resolve().parents[1]
session = json.loads((root / 'session.json').read_text())
assert time.time() >= dt.datetime.fromisoformat(session['deadline_utc']).timestamp()
assert (root / 'runner-stopped.json').exists()
output = root / 'results/final-overview-v1.json'
assert not output.exists()
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
labels = ['default8-final-v1', 'dspine16-final-v1',
          'dflash8-vs-dspine16-final-v1', 'dflash8-vs-dspine16-b4-final-v1',
          'agent12-dflash8-vs-dspine16-final-v1', 'm48-b3-research-v1']


def analyze_missing(label, protocol, target):
    """Use the frozen analyzer once on retained partial data; never run a model."""
    assert not target.exists()
    script = root / 'scripts' / protocol['analyzer_file']
    assert sha(script) == protocol['analyzer_sha256']
    command = [sys.executable, str(script), str(root / 'notes' / (label + '.protocol.json')), str(target)]
    ident = 'postwindow-analyze-' + label
    began = time.monotonic()
    with (root / 'results' / (ident + '.stdout')).open('x') as out, \
            (root / 'logs' / (ident + '.stderr')).open('x') as err:
        result = subprocess.run(command, stdout=out, stderr=err)
    record = {'command': command, 'exit_code': result.returncode,
              'elapsed_seconds': time.monotonic() - began,
              'analyzer_sha256': sha(script), 'protocol_sha256': sha(root / 'notes' / (label + '.protocol.json')),
              'scope': 'Offline application of the original frozen analyzer after the owned runner stopped. No model execution, replacement group or fabricated benchmark receipt.'}
    (root / 'notes' / (ident + '.json')).write_text(json.dumps(record, indent=2) + '\n')
    assert result.returncode == 0


def endpoint(groups, name, criterion, category=None):
    values = []
    for group in groups:
        source = group.get('endpoint_summaries', {}) if category is None else group.get('registered_categories', {}).get(category, {})
        if name in source:
            values.append(source[name])
    complete = len(values) == 3
    all_qualified = complete and all(v['qualified'] for v in values)
    directions = sorted({v['direction'] for v in values})
    consistent = len(directions) == 1
    return {
        'groups_with_endpoint': len(values),
        'all_three_measurements_qualified': complete and all(v['measurement_qualified'] for v in values),
        'frozen_all_three_effects_qualified': all_qualified,
        'consistent_direction': consistent,
        'reportable_effect': all_qualified and (criterion == 'nonregression' or consistent),
        'directions': directions,
        'control_time_by_group': [v['abba']['baseline'] for v in values],
        'candidate_time_by_group': [v['abba']['candidate'] for v in values],
        'throughput_change_percent_by_group': [100 * (v['abba']['baseline'] / v['abba']['candidate'] - 1) for v in values],
        'latency_change_percent_by_group': [100 * (v['abba']['candidate'] / v['abba']['baseline'] - 1) for v in values],
    }


comparisons = []
for label in labels:
    path = root / 'notes' / (label + '.protocol.json')
    if not path.exists():
        comparisons.append({'label': label, 'status': 'not_registered', 'qualified': False})
        continue
    protocol = json.loads(path.read_text())
    result_path = root / 'results' / (label + '.comparison.json')
    if not result_path.exists():
        analyze_missing(label, protocol, result_path)
    result = json.loads(result_path.read_text())
    assert len(result['groups']) == protocol['groups'] == 3
    receipts = []
    for group in range(1, 4):
        for arm in ['a1', 'b1', 'b2', 'a2']:
            ident = f'{label}-g{group}-{arm}'
            receipt_path = root / 'results' / (ident + '.receipt.json')
            if receipt_path.exists():
                value = json.loads(receipt_path.read_text())
                receipts.append({'id': ident, 'state': value['state'], 'exit_code': value['exit_code']})
    problems = [p for group in result['groups'] for p in group['problems']]
    groups = result['groups']
    endpoints = {name: endpoint(groups, name, protocol['criterion']) for name in ['decode', 'request_wall', 'ttft']}
    # The original top-level decode verdict also gates every retained secondary control.
    endpoints['decode']['reportable_effect'] &= result['qualified']
    endpoints['decode']['frozen_primary_all_case_gate'] = result['qualified']
    successful_rounds = sum(v['state'] == 'complete' and v['exit_code'] == 0 for v in receipts)
    comparisons.append({
        'label': label,
        'status': 'all_scheduled_rounds_complete' if successful_rounds == 12 else 'interrupted_or_unrun',
        'scheduled_rounds': 12,
        'retained_round_receipts': receipts,
        'successful_rounds': successful_rounds,
        'frozen_primary_decode_qualified': result['qualified'],
        'qualified': endpoints['decode']['reportable_effect'],
        'endpoints': endpoints,
        'categories': {category: {name: endpoint(groups, name, protocol['criterion'], category) for name in ['decode', 'request_wall', 'ttft']}
                       for category in protocol.get('categories', {})},
        'group_output_agreement': [v.get('all_output_arrays_match') for v in groups],
        'group_decode_noise_gate': [v.get('all_case_noise_within_five_percent') for v in groups],
        'problems': problems,
        'protocol_sha256': sha(path), 'analysis_sha256': sha(result_path),
    })

sampling_path = root / 'results/sampling4-comparison-v1.json'
if not sampling_path.exists() and (root / 'notes/sampling4-v1.artifact-barrier.json').exists():
    command = ['/Users/linson/Documents/ai/splash-dspine-investigation-20261110/stats-venv/bin/python',
               str(root / 'scripts/analyze_sampling4_v1.py')]
    with (root / 'results/postwindow-analyze-sampling4-v1.stdout').open('x') as out, \
            (root / 'logs/postwindow-analyze-sampling4-v1.stderr').open('x') as err:
        completed = subprocess.run(command, stdout=out, stderr=err)
    assert completed.returncode == 0
if sampling_path.exists():
    value = json.loads(sampling_path.read_text())
    sampling = {k: value[k] for k in ['status', 'errors', 'family_size_reserved', 'tests_observed', 'unobserved_reserved_tests', 'rejections']}
    sampling['informative_tests'] = sum(v['informative'] for v in value['results'])
    sampling['rejections_by_candidate'] = {
        candidate: sum(v['reject_at_family_alpha_0_05'] for v in value['results'] if v['candidate'] == candidate)
        for candidate in sorted({v['candidate'] for v in value['results']})
    }
    sampling['analysis_sha256'] = sha(sampling_path)
else:
    sampling = {'status': 'not_started', 'family_size_reserved': 280, 'tests_observed': 0,
                'unobserved_reserved_tests': 280, 'complete_screen_verdict': False}

nomination_path = root / 'notes/sampling4-nominations-v1.json'
if nomination_path.exists():
    nomination = json.loads(nomination_path.read_text())
    sampling_protocol = json.loads((root / 'notes/sampling4-protocol-v1.json').read_text())
    names = {line.split()[0] for line in (root / 'cohorts' / sampling_protocol['cohort']).read_text().splitlines()}
    samples = sampling_protocol['samples_per_chunk']
    chunks = []
    for arm in [nomination['control'], *nomination['candidates']]:
        for ident in arm['jobs']:
            receipt_path = root / 'results' / (ident + '.receipt.json')
            receipt = json.loads(receipt_path.read_text()) if receipt_path.exists() else {}
            progress_path = root / 'results' / (ident + '.progress.jsonl')
            completed = set()
            malformed_lines = 0
            if progress_path.exists():
                for raw in progress_path.read_text().splitlines():
                    try:
                        event = json.loads(raw)
                    except json.JSONDecodeError:
                        malformed_lines += 1
                        continue
                    if event.get('event') == 'complete' and event.get('kind') == 'request':
                        case, sample = event['scenario'], event['sample']
                        assert case in names and 0 <= sample < samples
                        completed.add((case, sample))
            chunks.append({'arm': arm['name'], 'job': ident,
                'state': receipt.get('state', 'started_without_receipt' if progress_path.exists() else 'unrun'),
                'exit_code': receipt.get('exit_code'),
                'registered_requests': len(names) * samples,
                'request_completions_in_journal': len(completed),
                'malformed_progress_lines': malformed_lines})
    sampling['chunk_status'] = chunks
    sampling['request_completions_in_journals'] = sum(c['request_completions_in_journal'] for c in chunks)

termination_path = root / 'results/sampling-termination-v1.json'
if not termination_path.exists() and (root / 'notes/sampling4-nominations-v1.json').exists():
    subprocess.run([sys.executable, str(root / 'scripts/sampling_termination_audit_v1.py')], check=True)
if termination_path.exists():
    termination = json.loads(termination_path.read_text())
    sampling['termination_audit'] = {'status': termination['status'],
        'requests_from_complete_chunks': sum(c['requests_in_complete_chunks'] for a in termination['arms'] for c in a['contexts']),
        'requests_below_cap': sum(c['requests_below_cap'] for a in termination['arms'] for c in a['contexts']),
        'zero_output_requests': sum(c['zero_output_requests'] for a in termination['arms'] for c in a['contexts']),
        'specific_stop_reason_saved': False, 'sha256': sha(termination_path)}

record = {
    'created_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
    'research_window': {key: session.get(key) for key in ['start_utc', 'deadline_utc']},
    'comparisons': comparisons, 'sampling': sampling,
    'scope': 'All registered groups/endpoints retained. Directional reporting additionally requires consistent direction across all three qualified groups, as documented before fresh data. Nonregression retains its original criterion. No endpoint or category transfers qualification to another. Incomplete sampling is not a smaller complete screen.',
}
output.write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({'comparisons': [{'label': v['label'], 'status': v['status'], 'qualified': v['qualified']} for v in comparisons], 'sampling': sampling}, indent=2))

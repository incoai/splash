"""Open fresh cohorts only after the complete frozen integration gates pass."""
from pathlib import Path
import datetime as dt
import hashlib
import json

root = Path(__file__).resolve().parents[1]
variant = 'production-final-v1'
required = ['build-production-final-v1', 'build-study-production-final-v1-v2',
    'build-priority-production-final-v1-v1', 'full-metal-production-final-v1',
    'python-contracts-production-final-v1', 'final-smoke-dspine8-v1', 'final-smoke-dspine16-v1',
    'final-smoke-dflash8-v1', 'final-clone-b3-v1', 'final-clone-b4-v1',
    'final-unaligned-tail16-v1', 'final-priority16-v1', 'final-http16-v1',
    'final-cache-isolation-v2', 'final-historical31-control-r8-v1',
    'final-historical31-production-final-v1-r8-v1', 'final-architecture-v1', 'final-python-full-v2',
    'final-native-tools-build-v1', 'final-host-sanitizers-v1', 'final-app-tests-v2', 'final-python-static-v1', 'final-metal-tsan-v1']


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def receipt(ident):
    path = root / 'results' / (ident + '.receipt.json')
    value = json.loads(path.read_text())
    assert value['state'] == 'complete' and value['exit_code'] == 0, ident
    assert value['artifact_sha256'] == value['artifact_sha256_after'], ident + ': artifacts changed'
    return {'job': ident, 'receipt_sha256': sha(path), 'elapsed_seconds': value['elapsed_seconds']}


def doc(ident):
    receipt(ident)
    return json.loads((root / 'results' / (ident + '.stdout')).read_text())


def arrays(ident):
    value = doc(ident)
    return {m['scenario']: m['output_tokens'] for m in value['measurements']}


def same(a, b, count):
    left, right = arrays(a), arrays(b)
    assert left == right and len(left) == count, (a, b)
    return {'jobs': [a, b], 'cases': count, 'complete_arrays_match': True}


output = root / 'notes' / (variant + '-nomination.json')
assert not output.exists(), 'already nominated'
receipts = [receipt(ident) for ident in required]
selection_path = root / 'notes' / (variant + '-selection.json')
selection = json.loads(selection_path.read_text())
patch = root / 'patches' / (variant + '.patch')
assert selection['source_chosen'] and not selection['source_nominated']
assert selection['patch_sha256'] == sha(patch)
build_path = root / 'artifacts' / variant / 'build.json'
build = json.loads(build_path.read_text())
assert build['patch_sha256'] == sha(patch)
for relative, expected in build['source_manifest'].items():
    assert sha(root / variant / relative) == expected, relative
for relative, expected in build['test_libraries'].items():
    assert sha(root / variant / relative) == expected, relative
witness_path = root / 'notes/integration-source-witness-v2.json'
witness = json.loads(witness_path.read_text())
assert witness['all_other_manifest_source_bytes_match']
for relative, expected in build['source_manifest'].items():
    actual = witness['allowed_differences'].get(relative, {}).get('integrated', expected)
    assert sha(root / 'geometry' / relative) == actual, 'integration witness: ' + relative
checks = [same('final-historical31-control-r8-v1', 'final-historical31-production-final-v1-r8-v1', 31),
          same('calibration-baseline8-smoke3-v9', 'final-smoke-dspine8-v1', 3),
          same('calibration-candidate16-smoke3-v9', 'final-smoke-dspine16-v1', 3),
          same('calibration-dflash8-smoke3-v9', 'final-smoke-dflash8-v1', 3),
          same('unaligned-tail-runtime16-v12-r16', 'final-unaligned-tail16-v1', 1)]
clones = []
for width in [3, 4]:
    previous = doc(f'calibration-wide-gateup-v1-r16-b{width}-c32768')['decode_throughput']['samples']
    current = doc(f'final-clone-b{width}-v1')['decode_throughput']['samples']
    assert len(previous) == len(current) == 3
    before = {v['scenario']: v['lane_outputs'] for v in previous}
    after = {v['scenario']: v['lane_outputs'] for v in current}
    assert before == after and len(after) == 3
    assert all(len(v) == width and all(lane == v[0] for lane in v) for v in after.values())
    clones.append({'physical_width': width, 'cases': 3, 'all_complete_lane_arrays_match': True})
priority = [json.loads(s) for s in (root / 'results/final-priority16-v1.raw.jsonl').read_text().splitlines()]
assert len(priority) == 5 and max(v['prompt_tokens'] for v in priority) == 15246
for case in priority:
    assert case['priority_suspensions'] > 0 and case['resumptions'] > 0 and case['replay_tokens'] > 0
    assert case['all_four_output_arrays_match'] and len(case['outputs']) == 4
    assert all(v == case['outputs'][0] and len(v) == 256 for v in case['outputs'])
service = json.loads((root / 'http/final-http16-v1/result.json').read_text())
cache = json.loads((root / 'http/final-cache-isolation-v2/result.json').read_text())
assert service['passed'] and service['server_exit_code'] == 0
assert cache['passed'] and len(cache['runs']) == 9 and all(v['exit_code'] == 0 for v in cache['runs'])
assert len(cache['runs'][-1]['namespaces_after']) == 4
rollup = {'validation_complete_utc': dt.datetime.now(dt.timezone.utc).isoformat(), 'variant': variant,
    'source_manifest_sha256': build['source_manifest_sha256'], 'patch_sha256': sha(patch),
    'receipts': receipts, 'same_geometry_output_checks': checks, 'clones': clones,
    'priority': [{k: v for k, v in case.items() if k != 'outputs'} for case in priority],
    'full_service': {'passed': True, 'result_sha256': sha(root / 'http/final-http16-v1/result.json')},
    'cache_compatibility_and_isolation': {'passed': True, 'physical_namespaces': 4,
        'result_sha256': sha(root / 'http/final-cache-isolation-v2/result.json'),
        'retained_invalid_fixture': 'final-cache-isolation-v1:645-token baseline wrote no disk points below the unchanged2048tokenminimum; source namespace itself matched',
        'short_window_disk_restore_exercised': False},
    'dynamic_budget_bytes_32k': {name: doc('final-smoke-' + name + '-v1')['dynamic_budget_bytes']
                               for name in ['dspine8', 'dspine16', 'dflash8']},
    'integration_supplement': {'source_witness_sha256': sha(witness_path), 'integration_commit': witness['integration_commit'], 'patch_sha256': sha(root / 'patches/final-integration-only-v2.patch'), 'scope': 'Desktop launch option, its forwarding test, parser-default test fixture, CLI/status documentation and locale-correct expected text in two existing Swift assertions. Frozen production source17a0 and all measured binaries/libraries unchanged.', 'original_full_suite_failed_receipt': sha(root / 'results/final-python-full-v1.receipt.json')},
    'scope': 'Finite correctness/integration gates. Passing does not establish universal greedy parity across widths, sampling equivalence, cross-device support or throughput.'}
rollup_path = root / 'results/final-validation-v1.json'
assert not rollup_path.exists()
rollup_path.write_text(json.dumps(rollup, indent=2) + '\n')
nomination = {**selection, 'source_nominated': True,
    'nominated_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
    'initial_selection_sha256': sha(selection_path), 'required_receipts': required,
    'validation_sha256': sha(rollup_path), 'build_manifest_sha256': sha(build_path),
    'heldout_status': 'All final source/artifacts fixed before first agent12 or sampling4 model output. No source substitution from those outcomes.'}
output.write_text(json.dumps(nomination, indent=2) + '\n')
print(json.dumps({'source_nominated': True, 'required_gates': len(required),
                  'same_geometry_output_checks': checks, 'dynamic_budget_bytes_32k': rollup['dynamic_budget_bytes_32k']}, indent=2))

"""Freeze all three arms before any fresh positive-temperature output."""
from pathlib import Path
import datetime as dt
import hashlib
import json
import sys
root=Path(__file__).resolve().parents[1]
variant=sys.argv[1]
assert not (root/'notes/sampling4-nominations-v1.json').exists(), 'already nominated'
final=json.loads((root/'notes/final-comparison-nominations-v1.json').read_text())
assert final['variant']==variant
comparison=json.loads((root/'notes/dflash8-vs-dspine16-final-v1.protocol.json').read_text())
base_comparison=json.loads((root/'notes/dspine16-final-v1.protocol.json').read_text())
protocol=json.loads((root/'notes/sampling4-protocol-v1.json').read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
cohort=root/'cohorts'/protocol['cohort'];assert sha(cohort)==protocol['cohort_sha256']
control={**base_comparison['arms']['control'],'name':'DSpine8_control','verify_rows':8,'seed_start':4100000,'jobs':[]}
ds={**comparison['arms']['candidate'],'name':'DSpine16_candidate','verify_rows':16,'seed_start':4200000,'jobs':[]}
df={**comparison['arms']['control'],'name':'DFlash8_candidate','verify_rows':8,'seed_start':4300000,'jobs':[]}
nomination={'frozen_utc':dt.datetime.now(dt.timezone.utc).isoformat(),'prefix':'sampling4-v1',
 'cohort':str(cohort),'cohort_sha256':sha(cohort),'control':control,'candidates':[ds,df],
 'artifact_nomination':{**comparison['artifact_nomination'],**base_comparison['artifact_nomination']},
 'operating_script_sha256':sha(root/'scripts/controlled_round.py'),
 'analyzer_file':'analyze_sampling4_v1.py','analyzer_sha256':sha(root/'scripts/analyze_sampling4_v1.py'),
 'abba_sha256':sha(root/'scripts/abba.py'),'required_receipts':final['selection']['required_receipts'],
 'settings':protocol['settings'],'chunk_order':['DSpine8_0','DSpine16_0','DFlash8_0','DFlash8_1','DSpine16_1','DSpine8_1'],
 'scope':'Independent-seed functional distribution screen, never throughput evidence. All three source/runtime arms frozen before first positive-temperature output; no source substitution or retry-to-pass.'}
path=root/'notes/sampling4-nominations-v1.json'
queue=root/'queue.jsonl';jobs=[json.loads(x) for x in queue.read_text().splitlines()]
preflight='freeze-artifacts-sampling4-v1'
jobs.append({'id':preflight,'command':['python3',str(root/'scripts/freeze_abba_artifacts_v2.py'),str(path)],
 'artifacts':[str(path),str(root/'scripts/freeze_abba_artifacts_v2.py')],'requires':nomination['required_receipts'], 'timeout_seconds':120})
for arm,chunk in [(control,0),(ds,0),(df,0),(df,1),(ds,1),(control,1)]:
    ident=f"sampling4-{arm['name']}-chunk{chunk}-v1";arm['jobs'].append(ident)
    bundle=nomination['artifact_nomination'][arm['variant']]
    command=[bundle['driver'],bundle['library'],arm['model_root'],'--draft-block-size',str(arm['verify_rows']),
      '--cohort',str(cohort),'--samples','500','--temperature','1','--seed-base',str(arm['seed_start']+500*chunk),
      '--ane-ffn-share','0','--max-context','32768','--progress',str(root/'results'/f'{ident}.progress.jsonl')]
    jobs.append({'id':ident,'command':['python3',str(root/'scripts/run_frozen_job_v1.py'),str(path),*command],
      'artifacts':[bundle[k] for k in ['driver','library','host_step']]+[str(cohort),str(path),str(root/'scripts/run_frozen_job_v1.py')],
      'requires':[preflight],'timeout_seconds':3600,'classification':'Fresh independent-seed functional sampling screen, no throughput claim'})
path.write_text(json.dumps(nomination,indent=2)+'\n')
jobs.append({'id':'analyze-sampling4-v1','command':['/Users/linson/Documents/ai/splash-dspine-investigation-20261110/stats-venv/bin/python',str(root/'scripts/analyze_sampling4_v1.py')],
 'artifacts':[str(path),str(root/'scripts/analyze_sampling4_v1.py'),str(cohort)],'timeout_seconds':120})
ids=[j['id'] for j in jobs];assert len(ids)==len(set(ids))
assert all(d in ids or (root/'results'/f'{d}.receipt.json').exists() for j in jobs for d in j.get('requires',[]))
t=queue.with_suffix('.tmp');t.write_text(''.join(json.dumps(j)+'\n' for j in jobs));t.replace(queue)
print('Nominated all three arms; registered12000requests in six500-seed chunks and Holm280analysis')

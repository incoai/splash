"""Localize a retained failed equality gate without rerunning or selecting cases."""

from pathlib import Path
from collections import defaultdict
import datetime as dt
import hashlib
import json

root = Path(__file__).resolve().parents[1]
label = 'dspine16-final-v1'
original = json.loads((root / 'results' / (label + '.comparison.json')).read_text())
assert len(original['groups']) == 3
records = defaultdict(lambda: defaultdict(list))
sources = []
for group in range(1, 4):
    for suffix in ['a1', 'b1', 'b2', 'a2']:
        ident = f'{label}-g{group}-{suffix}'
        receipt = json.loads((root / 'results' / (ident + '.receipt.json')).read_text())
        assert receipt['state'] == 'complete' and receipt['exit_code'] == 0
        assert receipt['artifact_sha256'] == receipt['artifact_sha256_after']
        path = root / 'results' / (ident + '.stdout')
        value = json.loads(path.read_text())
        arm = 'control8' if suffix.startswith('a') else 'candidate16'
        for measurement in value['measurements']:
            tokens = measurement['output_tokens']
            digest = hashlib.sha256(json.dumps(tokens, separators=(',', ':')).encode()).hexdigest()
            records[measurement['scenario']][arm].append({
                'job': ident, 'sample': measurement['sample'], 'tokens': tokens, 'sha256': digest})
        sources.append({'job': ident, 'stdout_sha256': hashlib.sha256(path.read_bytes()).hexdigest()})


def first_difference(a, b):
    for index, (left, right) in enumerate(zip(a, b)):
        if left != right:
            return {'index_zero_based': index, 'kind': 'token', 'control_token': left, 'candidate_token': right}
    if len(a) != len(b):
        return {'index_zero_based': min(len(a), len(b)), 'kind': 'length'}
    return None


cases = []
for name in sorted(records):
    arms = records[name]
    assert set(arms) == {'control8', 'candidate16'}
    assert all(len(v) == 12 for v in arms.values()), name
    hashes = {arm: sorted({r['sha256'] for r in values}) for arm, values in arms.items()}
    stable = all(len(v) == 1 for v in hashes.values())
    first = {arm: values[0] for arm, values in arms.items()}
    difference = first_difference(first['control8']['tokens'], first['candidate16']['tokens'])
    cases.append({'case': name, 'within_width_unique_arrays': {arm: len(v) for arm, v in hashes.items()},
                  'within_width_repeatable': stable,
                  'all_cross_width_arrays_match': len(set(hashes['control8'] + hashes['candidate16'])) == 1,
                  'representative_pair': {arm: {k: v for k, v in row.items() if k != 'tokens'} for arm, row in first.items()},
                  'representative_lengths': {arm: len(row['tokens']) for arm, row in first.items()},
                  'representative_first_difference': difference,
                  'unique_array_sha256': hashes})
assert len(cases) == 31
result = {'created_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
          'original_qualified_verdict': original['qualified'],
          'arm_source_commits': {'control8': '425ad7400f3a00d2a1e6745bdacfa2881922d544', 'candidate16': '17a0ae2454ef567a599ccd64373d25fc7df9313b'},
          'all_cases_repeatable_within_each_width': all(c['within_width_repeatable'] for c in cases),
          'cases_with_any_array_difference': sum(not c['all_cross_width_arrays_match'] for c in cases),
          'stable_cross_width_differences': sum(c['within_width_repeatable'] and not c['all_cross_width_arrays_match'] for c in cases),
          'representative_first_token_differences': sum(c['representative_first_difference'] is not None and c['representative_first_difference']['index_zero_based'] == 0 for c in cases),
          'cases': cases, 'sources': sources,
          'scope': 'Post-hoc descriptive localization of the already failed complete-array gate across all31cases, all12rounds and both internal repetitions. No model run, replacement group, added significance test, source adjustment or favorable subset. The two arms differ in source as well as width. Stable differences do not identify a responsible operator, establish a width-only cause or prove numerical rather than semantic error.'}
path = root / 'results/dspine16-output-divergence-v1.json'
assert not path.exists()
path.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({k: result[k] for k in ['all_cases_repeatable_within_each_width', 'cases_with_any_array_difference', 'stable_cross_width_differences', 'representative_first_token_differences']}))

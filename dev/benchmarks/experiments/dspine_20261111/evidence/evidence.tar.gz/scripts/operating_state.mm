#import <Foundation/Foundation.h>
#include <IOKit/ps/IOPowerSources.h>
#include <IOKit/ps/IOPSKeys.h>
#include <iostream>
int main() {
  @autoreleasepool {
    CFTypeRef info = IOPSCopyPowerSourcesInfo();
    CFStringRef source = info ? IOPSGetProvidingPowerSourceType(info) : nullptr;
    const bool ac = source && CFEqual(source, CFSTR(kIOPSACPowerValue));
    if (info) CFRelease(info);
    std::cout << "{\"thermal_state\":" << static_cast<unsigned>(NSProcessInfo.processInfo.thermalState)
              << ",\"uptime_seconds\":" << NSProcessInfo.processInfo.systemUptime
              << ",\"ac_power\":" << (ac ? "true" : "false") << "}\n";
  }
}

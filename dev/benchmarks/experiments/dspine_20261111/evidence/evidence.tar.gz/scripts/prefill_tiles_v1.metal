#pragma clang fp reassociate(off)
#include "metal/kernels/common/gguf_staged_tile.h"
#include "metal/kernels/common/split_reduce.h"
struct PrefillWalkParams { GgufPrefillParams base; uint columns; };
template <class F, ushort RowsPerSG, ushort Simdgroups, ushort TileN, ushort KS, GgufEpilogue Ep = EpNone>
inline void experimental_prefill_tile(device bfloat *input, device uchar *w0, device uchar *w1, device uchar *meta, device bfloat *output,
                    uint input_size, uint output_origin, uint rows, threadgroup half *stage, threadgroup half2 *tl,
                    uint simd_lane, uint simd_group, uint out_stride, uint out_offset, device bfloat *aux = nullptr) {
  const bool owns_rows = simd_group * RowsPerSG < rows;   // uniform per simdgroup
  device bfloat *rows_input = input + ulong(simd_group) * RowsPerSG * input_size;
  auto acc = staged_accumulator<RowsPerSG, TileN, KS>(rows_input, input_size, stage);
  gguf_zero(acc);
  gguf_staged_steps<F, RowsPerSG, TileN, KS, Simdgroups * 32>(rows_input, w0, w1, meta, input_size, output_origin, stage, tl,
                                                              simd_group * 32 + simd_lane, 0, input_size / KS, 0, owns_rows,
                                                              acc);
  if (!owns_rows) return;
#pragma unroll
  for (ushort i = 0; i < acc.get_capacity(); ++i) {
    if (!acc.is_valid_element(i)) continue;
    auto index = acc.get_multidimensional_index(i);
    const ulong o = (ulong(simd_group) * RowsPerSG + index[1]) * out_stride + out_offset + output_origin + index[0];
    output[o] = gguf_epilogue<Ep>(acc[i], aux, o);
  }
}


kernel void gguf_prefill_af4g64_n32_a(device bfloat *input [[buffer(0)]], device uchar *w0 [[buffer(1)]],
    device uchar *w1 [[buffer(2)]], device uchar *meta [[buffer(3)]], device bfloat *output [[buffer(4)]],
    constant PrefillWalkParams &spec [[buffer(5)]],
    uint2 group [[threadgroup_position_in_grid]], uint simd_lane [[thread_index_in_simdgroup]],
    uint simd_group [[simdgroup_index_in_threadgroup]]) {
  constant GgufPrefillParams &p = spec.base;
  uint2 tile = group;
  threadgroup half stage[2 * 32 * GGUF_PREFILL_STEP];
  threadgroup half2 table[1];
  const uint first = tile.x * GGUF_PREFILL_ROWS;
  const uint rows = p.rows > first ? p.rows - first : 0;
  experimental_prefill_tile<FmtAF4G64, GGUF_PREFILL_SIMDGROUP_ROWS, GGUF_PREFILL_SIMDGROUPS,
      32, GGUF_PREFILL_STEP, EpNone>(input + ulong(first) * p.input_size,
      w0, w1, meta, output + ulong(first) * p.out_stride, p.input_size,
      tile.y * 32, rows, stage, table, simd_lane, simd_group, p.out_stride, p.out_offset);
}

kernel void gguf_prefill_af4g64_n32_r(device bfloat *input [[buffer(0)]], device uchar *w0 [[buffer(1)]],
    device uchar *w1 [[buffer(2)]], device uchar *meta [[buffer(3)]], device bfloat *output [[buffer(4)]],
    device bfloat *aux [[buffer(5)]],
    constant PrefillWalkParams &spec [[buffer(6)]],
    uint2 group [[threadgroup_position_in_grid]], uint simd_lane [[thread_index_in_simdgroup]],
    uint simd_group [[simdgroup_index_in_threadgroup]]) {
  constant GgufPrefillParams &p = spec.base;
  uint2 tile = group;
  threadgroup half stage[2 * 32 * GGUF_PREFILL_STEP];
  threadgroup half2 table[1];
  const uint first = tile.x * GGUF_PREFILL_ROWS;
  const uint rows = p.rows > first ? p.rows - first : 0;
  experimental_prefill_tile<FmtAF4G64, GGUF_PREFILL_SIMDGROUP_ROWS, GGUF_PREFILL_SIMDGROUPS,
      32, GGUF_PREFILL_STEP, EpResidual>(input + ulong(first) * p.input_size,
      w0, w1, meta, output + ulong(first) * p.out_stride, p.input_size,
      tile.y * 32, rows, stage, table, simd_lane, simd_group, p.out_stride, p.out_offset, aux + ulong(first) * p.out_stride);
}

kernel void gguf_prefill_af4g64_n32_g(device bfloat *input [[buffer(0)]], device uchar *w0 [[buffer(1)]],
    device uchar *w1 [[buffer(2)]], device uchar *meta [[buffer(3)]], device bfloat *output [[buffer(4)]],
    device bfloat *aux [[buffer(5)]],
    constant PrefillWalkParams &spec [[buffer(6)]],
    uint2 group [[threadgroup_position_in_grid]], uint simd_lane [[thread_index_in_simdgroup]],
    uint simd_group [[simdgroup_index_in_threadgroup]]) {
  constant GgufPrefillParams &p = spec.base;
  uint2 tile = group;
  threadgroup half stage[2 * 32 * GGUF_PREFILL_STEP];
  threadgroup half2 table[1];
  const uint first = tile.x * GGUF_PREFILL_ROWS;
  const uint rows = p.rows > first ? p.rows - first : 0;
  experimental_prefill_tile<FmtAF4G64, GGUF_PREFILL_SIMDGROUP_ROWS, GGUF_PREFILL_SIMDGROUPS,
      32, GGUF_PREFILL_STEP, EpUpWithGate>(input + ulong(first) * p.input_size,
      w0, w1, meta, output + ulong(first) * p.out_stride, p.input_size,
      tile.y * 32, rows, stage, table, simd_lane, simd_group, p.out_stride, p.out_offset, aux + ulong(first) * p.out_stride);
}

kernel void gguf_prefill_af4g64_n64_walk4_a(device bfloat *input [[buffer(0)]], device uchar *w0 [[buffer(1)]],
    device uchar *w1 [[buffer(2)]], device uchar *meta [[buffer(3)]], device bfloat *output [[buffer(4)]],
    constant PrefillWalkParams &spec [[buffer(5)]],
    uint2 group [[threadgroup_position_in_grid]], uint simd_lane [[thread_index_in_simdgroup]],
    uint simd_group [[simdgroup_index_in_threadgroup]]) {
  constant GgufPrefillParams &p = spec.base;
  uint2 tile = group;
  const uint mt = (p.rows + GGUF_PREFILL_ROWS - 1) / GGUF_PREFILL_ROWS;
  const uint nt = spec.columns / 64;
  const uint bm = min(mt, 4u), bn = min(nt, 4u);
  const uint blocks_m = (mt + bm - 1) / bm;
  const uint block = group.x / (bm * bn), local = group.x % (bm * bn);
  tile = uint2((block % blocks_m) * bm + local % bm,
               (block / blocks_m) * bn + local / bm);
  if (tile.x >= mt || tile.y >= nt) return;
  threadgroup half stage[2 * 64 * GGUF_PREFILL_STEP];
  threadgroup half2 table[1];
  const uint first = tile.x * GGUF_PREFILL_ROWS;
  const uint rows = p.rows > first ? p.rows - first : 0;
  experimental_prefill_tile<FmtAF4G64, GGUF_PREFILL_SIMDGROUP_ROWS, GGUF_PREFILL_SIMDGROUPS,
      64, GGUF_PREFILL_STEP, EpNone>(input + ulong(first) * p.input_size,
      w0, w1, meta, output + ulong(first) * p.out_stride, p.input_size,
      tile.y * 64, rows, stage, table, simd_lane, simd_group, p.out_stride, p.out_offset);
}

kernel void gguf_prefill_af4g64_n64_walk4_r(device bfloat *input [[buffer(0)]], device uchar *w0 [[buffer(1)]],
    device uchar *w1 [[buffer(2)]], device uchar *meta [[buffer(3)]], device bfloat *output [[buffer(4)]],
    device bfloat *aux [[buffer(5)]],
    constant PrefillWalkParams &spec [[buffer(6)]],
    uint2 group [[threadgroup_position_in_grid]], uint simd_lane [[thread_index_in_simdgroup]],
    uint simd_group [[simdgroup_index_in_threadgroup]]) {
  constant GgufPrefillParams &p = spec.base;
  uint2 tile = group;
  const uint mt = (p.rows + GGUF_PREFILL_ROWS - 1) / GGUF_PREFILL_ROWS;
  const uint nt = spec.columns / 64;
  const uint bm = min(mt, 4u), bn = min(nt, 4u);
  const uint blocks_m = (mt + bm - 1) / bm;
  const uint block = group.x / (bm * bn), local = group.x % (bm * bn);
  tile = uint2((block % blocks_m) * bm + local % bm,
               (block / blocks_m) * bn + local / bm);
  if (tile.x >= mt || tile.y >= nt) return;
  threadgroup half stage[2 * 64 * GGUF_PREFILL_STEP];
  threadgroup half2 table[1];
  const uint first = tile.x * GGUF_PREFILL_ROWS;
  const uint rows = p.rows > first ? p.rows - first : 0;
  experimental_prefill_tile<FmtAF4G64, GGUF_PREFILL_SIMDGROUP_ROWS, GGUF_PREFILL_SIMDGROUPS,
      64, GGUF_PREFILL_STEP, EpResidual>(input + ulong(first) * p.input_size,
      w0, w1, meta, output + ulong(first) * p.out_stride, p.input_size,
      tile.y * 64, rows, stage, table, simd_lane, simd_group, p.out_stride, p.out_offset, aux + ulong(first) * p.out_stride);
}

kernel void gguf_prefill_af4g64_n64_walk4_g(device bfloat *input [[buffer(0)]], device uchar *w0 [[buffer(1)]],
    device uchar *w1 [[buffer(2)]], device uchar *meta [[buffer(3)]], device bfloat *output [[buffer(4)]],
    device bfloat *aux [[buffer(5)]],
    constant PrefillWalkParams &spec [[buffer(6)]],
    uint2 group [[threadgroup_position_in_grid]], uint simd_lane [[thread_index_in_simdgroup]],
    uint simd_group [[simdgroup_index_in_threadgroup]]) {
  constant GgufPrefillParams &p = spec.base;
  uint2 tile = group;
  const uint mt = (p.rows + GGUF_PREFILL_ROWS - 1) / GGUF_PREFILL_ROWS;
  const uint nt = spec.columns / 64;
  const uint bm = min(mt, 4u), bn = min(nt, 4u);
  const uint blocks_m = (mt + bm - 1) / bm;
  const uint block = group.x / (bm * bn), local = group.x % (bm * bn);
  tile = uint2((block % blocks_m) * bm + local % bm,
               (block / blocks_m) * bn + local / bm);
  if (tile.x >= mt || tile.y >= nt) return;
  threadgroup half stage[2 * 64 * GGUF_PREFILL_STEP];
  threadgroup half2 table[1];
  const uint first = tile.x * GGUF_PREFILL_ROWS;
  const uint rows = p.rows > first ? p.rows - first : 0;
  experimental_prefill_tile<FmtAF4G64, GGUF_PREFILL_SIMDGROUP_ROWS, GGUF_PREFILL_SIMDGROUPS,
      64, GGUF_PREFILL_STEP, EpUpWithGate>(input + ulong(first) * p.input_size,
      w0, w1, meta, output + ulong(first) * p.out_stride, p.input_size,
      tile.y * 64, rows, stage, table, simd_lane, simd_group, p.out_stride, p.out_offset, aux + ulong(first) * p.out_stride);
}

kernel void gguf_prefill_af4g64_n32_walk4_a(device bfloat *input [[buffer(0)]], device uchar *w0 [[buffer(1)]],
    device uchar *w1 [[buffer(2)]], device uchar *meta [[buffer(3)]], device bfloat *output [[buffer(4)]],
    constant PrefillWalkParams &spec [[buffer(5)]],
    uint2 group [[threadgroup_position_in_grid]], uint simd_lane [[thread_index_in_simdgroup]],
    uint simd_group [[simdgroup_index_in_threadgroup]]) {
  constant GgufPrefillParams &p = spec.base;
  uint2 tile = group;
  const uint mt = (p.rows + GGUF_PREFILL_ROWS - 1) / GGUF_PREFILL_ROWS;
  const uint nt = spec.columns / 32;
  const uint bm = min(mt, 4u), bn = min(nt, 4u);
  const uint blocks_m = (mt + bm - 1) / bm;
  const uint block = group.x / (bm * bn), local = group.x % (bm * bn);
  tile = uint2((block % blocks_m) * bm + local % bm,
               (block / blocks_m) * bn + local / bm);
  if (tile.x >= mt || tile.y >= nt) return;
  threadgroup half stage[2 * 32 * GGUF_PREFILL_STEP];
  threadgroup half2 table[1];
  const uint first = tile.x * GGUF_PREFILL_ROWS;
  const uint rows = p.rows > first ? p.rows - first : 0;
  experimental_prefill_tile<FmtAF4G64, GGUF_PREFILL_SIMDGROUP_ROWS, GGUF_PREFILL_SIMDGROUPS,
      32, GGUF_PREFILL_STEP, EpNone>(input + ulong(first) * p.input_size,
      w0, w1, meta, output + ulong(first) * p.out_stride, p.input_size,
      tile.y * 32, rows, stage, table, simd_lane, simd_group, p.out_stride, p.out_offset);
}

kernel void gguf_prefill_af4g64_n32_walk4_r(device bfloat *input [[buffer(0)]], device uchar *w0 [[buffer(1)]],
    device uchar *w1 [[buffer(2)]], device uchar *meta [[buffer(3)]], device bfloat *output [[buffer(4)]],
    device bfloat *aux [[buffer(5)]],
    constant PrefillWalkParams &spec [[buffer(6)]],
    uint2 group [[threadgroup_position_in_grid]], uint simd_lane [[thread_index_in_simdgroup]],
    uint simd_group [[simdgroup_index_in_threadgroup]]) {
  constant GgufPrefillParams &p = spec.base;
  uint2 tile = group;
  const uint mt = (p.rows + GGUF_PREFILL_ROWS - 1) / GGUF_PREFILL_ROWS;
  const uint nt = spec.columns / 32;
  const uint bm = min(mt, 4u), bn = min(nt, 4u);
  const uint blocks_m = (mt + bm - 1) / bm;
  const uint block = group.x / (bm * bn), local = group.x % (bm * bn);
  tile = uint2((block % blocks_m) * bm + local % bm,
               (block / blocks_m) * bn + local / bm);
  if (tile.x >= mt || tile.y >= nt) return;
  threadgroup half stage[2 * 32 * GGUF_PREFILL_STEP];
  threadgroup half2 table[1];
  const uint first = tile.x * GGUF_PREFILL_ROWS;
  const uint rows = p.rows > first ? p.rows - first : 0;
  experimental_prefill_tile<FmtAF4G64, GGUF_PREFILL_SIMDGROUP_ROWS, GGUF_PREFILL_SIMDGROUPS,
      32, GGUF_PREFILL_STEP, EpResidual>(input + ulong(first) * p.input_size,
      w0, w1, meta, output + ulong(first) * p.out_stride, p.input_size,
      tile.y * 32, rows, stage, table, simd_lane, simd_group, p.out_stride, p.out_offset, aux + ulong(first) * p.out_stride);
}

kernel void gguf_prefill_af4g64_n32_walk4_g(device bfloat *input [[buffer(0)]], device uchar *w0 [[buffer(1)]],
    device uchar *w1 [[buffer(2)]], device uchar *meta [[buffer(3)]], device bfloat *output [[buffer(4)]],
    device bfloat *aux [[buffer(5)]],
    constant PrefillWalkParams &spec [[buffer(6)]],
    uint2 group [[threadgroup_position_in_grid]], uint simd_lane [[thread_index_in_simdgroup]],
    uint simd_group [[simdgroup_index_in_threadgroup]]) {
  constant GgufPrefillParams &p = spec.base;
  uint2 tile = group;
  const uint mt = (p.rows + GGUF_PREFILL_ROWS - 1) / GGUF_PREFILL_ROWS;
  const uint nt = spec.columns / 32;
  const uint bm = min(mt, 4u), bn = min(nt, 4u);
  const uint blocks_m = (mt + bm - 1) / bm;
  const uint block = group.x / (bm * bn), local = group.x % (bm * bn);
  tile = uint2((block % blocks_m) * bm + local % bm,
               (block / blocks_m) * bn + local / bm);
  if (tile.x >= mt || tile.y >= nt) return;
  threadgroup half stage[2 * 32 * GGUF_PREFILL_STEP];
  threadgroup half2 table[1];
  const uint first = tile.x * GGUF_PREFILL_ROWS;
  const uint rows = p.rows > first ? p.rows - first : 0;
  experimental_prefill_tile<FmtAF4G64, GGUF_PREFILL_SIMDGROUP_ROWS, GGUF_PREFILL_SIMDGROUPS,
      32, GGUF_PREFILL_STEP, EpUpWithGate>(input + ulong(first) * p.input_size,
      w0, w1, meta, output + ulong(first) * p.out_stride, p.input_size,
      tile.y * 32, rows, stage, table, simd_lane, simd_group, p.out_stride, p.out_offset, aux + ulong(first) * p.out_stride);
}

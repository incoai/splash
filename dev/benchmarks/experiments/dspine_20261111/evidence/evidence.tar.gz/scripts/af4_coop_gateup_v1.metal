#pragma clang fp reassociate(off)
#include "metal/kernels/common/gguf_staged_tile.h"
#include "metal/kernels/common/split_reduce.h"

// Use public cooperative-tensor coordinates, rather than assuming a particular
// compiler's lane layout. Unroll the small right operand so repeated chunk and
// metadata loads can be shared. AF4 metadata is BF16 scale/bias; decode with the
// same float FMA and half rounding as dequant32_chunks before each tensor op.
template<class F, class Right>
inline void affine_cooperative_half(thread Right &right, device uchar *w0, device uchar *w1,
                                    device uchar *meta, uint inputSize, uint origin, uint step) {
  const uint groups = inputSize / 32, units = groups / F::MetaGroups;
#pragma unroll
  for (ushort i = 0; i < right.get_capacity(); ++i) {
    if (!right.is_valid_element(i)) continue;
    const auto index = right.get_multidimensional_index(i);
    const uint k = index[0], column = origin + index[1];
    const uint tile = column / QUANT_TILE_ROWS, row = column % QUANT_TILE_ROWS;
    const ulong group = (ulong(tile) * groups + step) * QUANT_TILE_ROWS + row;
    const ulong unit = (ulong(tile) * units + step / F::MetaGroups) * QUANT_TILE_ROWS + row;
    const auto chunk = F::loadChunk(w0 + group * F::P0, w1 + group * F::P1, ushort((k % 16) / 4));
    const uint4 pairs = F::codes(chunk);
    const uint pair = pairs[(k % 4) / 2 + (k / 16) * 2];
    const uint code = (pair >> ((k % 2) * 16)) & 0xffffu;
    const QuantCoef coefficient = F::coef(F::loadMeta(meta + unit * F::MetaBytes), ushort(step % F::MetaGroups));
    const float scale = k < 16 ? coefficient.s.x : coefficient.s.y;
    const float bias = k < 16 ? coefficient.m.x : coefficient.m.y;
    right[i] = half(fma(float(code), scale, bias));
  }
}
template <class F, ushort Rows>
kernel void gguf_decode_coop_gate_up(device bfloat *input [[buffer(0)]], device uchar *gw0 [[buffer(1)]],
                                device uchar *gw1 [[buffer(2)]], device uchar *gmeta [[buffer(3)]],
                                device uchar *uw0 [[buffer(4)]], device uchar *uw1 [[buffer(5)]],
                                device uchar *umeta [[buffer(6)]], device bfloat *output [[buffer(7)]],
                                device coherent(device) float *partials [[buffer(8)]],
                                device atomic_uint *counters [[buffer(9)]], constant GgufDecodeParams &p [[buffer(10)]],
                                uint2 group [[threadgroup_position_in_grid]], uint lane [[thread_index_in_simdgroup]]) {
  threadgroup uint arrival;
  const uint per = p.input_size / GGUF_STAGED_STEP / p.splits, sb = group.y * per, se = sb + per,
             origin = group.x * GGUF_STAGED_COLUMNS, column0 = p.out_offset + origin;
  auto inputTensor = tensor(input, dextents<int, 2>{int(p.input_size), Rows},
                            array<int, 2>{1, int(p.input_size)});
  constexpr auto descriptor = matmul2d_descriptor(Rows, GGUF_STAGED_COLUMNS, GGUF_STAGED_STEP,
      false, true, false, matmul2d_descriptor::mode::multiply_accumulate);
  matmul2d<descriptor, execution_simdgroup> operation;
  auto right = operation.template get_right_input_cooperative_tensor<bfloat, half, float>();
  auto gate = operation.template get_destination_cooperative_tensor<decltype(inputTensor), decltype(right), float>();
  auto up = operation.template get_destination_cooperative_tensor<decltype(inputTensor), decltype(right), float>();
  gguf_zero(gate); gguf_zero(up);
  const uint sf = staged_first_step(group.x / 2, sb, se, p.spread);
  for (uint run = 0; run < 2; ++run) {
    const uint from = run ? sb : sf, to = run ? sf : se;
    for (uint step = from; step < to; ++step) {
      auto a = inputTensor.template slice<GGUF_STAGED_STEP, Rows>(step * GGUF_STAGED_STEP, 0);
      affine_cooperative_half<F>(right, gw0, gw1, gmeta, p.input_size, origin, step);
      operation.run(a, right, gate);
      affine_cooperative_half<F>(right, uw0, uw1, umeta, p.input_size, origin, step);
      operation.run(a, right, up);
    }
  }
  const auto value = [](float g, float u) { return bfloat(float(bfloat(u)) * splash_silu(float(bfloat(g)))); };
  const auto out = [&](uint row, uint column) { return ulong(row) * p.out_stride + column0 + column; };
  if (p.splits == 1) {
#pragma unroll
    for (ushort i = 0; i < gate.get_capacity(); ++i) {
      if (!gate.is_valid_element(i)) continue;
      const auto index = gate.get_multidimensional_index(i);
      output[out(index[1], index[0])] = value(gate[i], up[i]);
    }
    return;
  }
  const auto at = [&](uint s, uint row, uint column) {
    return (ulong(s) * Rows + row) * (2 * p.out_stride) + column0 + column;
  };
#pragma unroll
  for (ushort i = 0; i < gate.get_capacity(); ++i) {
    if (!gate.is_valid_element(i)) continue;
    const auto index = gate.get_multidimensional_index(i);
    partials[at(group.y, index[1], index[0])] = gate[i];
    partials[at(group.y, index[1], index[0]) + p.out_stride] = up[i];
  }
  device atomic_uint *counter = counters + p.out_offset / GGUF_STAGED_COLUMNS + group.x;
  if (!split_arrive_last(counter, p.splits, lane, &arrival)) return;
#pragma unroll
  for (ushort i = 0; i < gate.get_capacity(); ++i) {
    if (!gate.is_valid_element(i)) continue;
    const auto index = gate.get_multidimensional_index(i);
    const uint row = index[1], column = index[0];
    const float g = split_sum(float(gate[i]), group.y, p.splits, [&](uint s) { return partials[at(s, row, column)]; });
    const float u = split_sum(float(up[i]), group.y, p.splits,
                              [&](uint s) { return partials[at(s, row, column) + p.out_stride]; });
    output[out(row, column)] = value(g, u);
  }
  split_release(counter, lane);
}
using GgufDecodeGateUpKernel = void(device bfloat *, device uchar *, device uchar *, device uchar *, device uchar *,
                                    device uchar *, device uchar *, device bfloat *, device coherent(device) float *,
                                    device atomic_uint *, constant GgufDecodeParams &, uint2, uint);
template [[host_name("gguf_decode_af4g64_coop_m16_gate_up")]] kernel GgufDecodeGateUpKernel gguf_decode_coop_gate_up<FmtAF4G64, 16>;
template [[host_name("gguf_decode_af4g64_coop_m32_gate_up")]] kernel GgufDecodeGateUpKernel gguf_decode_coop_gate_up<FmtAF4G64, 32>;
template [[host_name("gguf_decode_af4g64_coop_m64_gate_up")]] kernel GgufDecodeGateUpKernel gguf_decode_coop_gate_up<FmtAF4G64, 64>;

"""Research only: compute the actual three-lane48rows without padding to64."""
from pathlib import Path
r=Path(__file__).resolve().parents[1]
s=(r/'runtime16-v10/runtime/metal/kernels/shared/gguf_linear.metal').read_text()
a=s.index('template <class F, ushort Rows, GgufEpilogue Ep, class Out>\nkernel void gguf_decode(')
b=s.index('#define GGUF_DECODE(',a)
body=s[a:b].replace('gguf_decode(', 'gguf_decode_rows48(')
prefix='#pragma clang fp reassociate(off)\n#include "metal/kernels/common/gguf_staged_tile.h"\n#include "metal/kernels/common/split_reduce.h"\n'
instances='\n'.join('template [[host_name("gguf_decode_af4g64_m48_'+suffix+'")]] kernel GgufDecodeKernel<bfloat> gguf_decode_rows48<FmtAF4G64,48,'+ep+',bfloat>;' for suffix,ep in [('a','EpNone'),('g','EpUpWithGate')])
(r/'scripts/af4_m48_v1.metal').write_text(prefix+body+instances+'\n')
s=(r/'scripts/af4_n16_oracle_v2.mm').read_text()
s=s.replace('std::vector<uint32_t>{0,2,2,0}:std::vector<uint32_t>{1,0,2}', 'std::vector<uint32_t>{0,3,3,0}:std::vector<uint32_t>{1,0,3}')
s=s.replace('      metal::CommandGraph graph;', '      std::memset(output.view.contents(),0xff,output.bytes); // Unwritten padding stays NaN.\n      metal::CommandGraph graph;')
s=s.replace('if(groupCount==0) {','if(groupCount==0||groupCount==3) {')
s=s.replace('const auto prefix="gguf_decode_af4g64_m"+std::to_string(rows);','const auto prefix="gguf_decode_af4g64_m"+std::to_string(groupCount==3?48:rows);')
s=s.replace('run(backend,64,64,17408,5120,true);','')
s=s.replace('for(uint32_t rows:{16u,32u,64u})','for(uint32_t rows:{64u})').replace('for(uint32_t live:{rows,rows*3/4})','for(uint32_t live:{48u})')
s=s.replace('\\\"simdgroups\\\":','\\\"arm\\\":')
s=s.replace('<<(groupCount?1:2)', '<<((groupCount==0||groupCount==3)?2:1)')
(r/'scripts/af4_m48_oracle_v1.mm').write_text(s)
print('Prepared M48 staged pair prototype; production source already chosen and unaffected.')

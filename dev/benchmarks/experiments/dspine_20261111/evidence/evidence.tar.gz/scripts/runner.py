"""Serial owned experiment runner, bounded by the user's thirteen-hour window."""
import datetime as dt,fcntl,hashlib,json,os,signal,subprocess,time
from pathlib import Path
r=Path(__file__).resolve().parents[1]
deadline=dt.datetime.fromisoformat(json.loads((r/'session.json').read_text())['deadline_utc']).timestamp()
def utc():return dt.datetime.now(dt.timezone.utc).isoformat()
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(path,value):
 tmp=path.with_suffix(path.suffix+'.tmp');tmp.write_text(json.dumps(value,indent=2)+'\n');tmp.replace(path)
lock=(r/'machine.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
try:
 while time.time()<deadline:
  jobs=[]
  queue=r/'queue.jsonl'
  if queue.exists():jobs=[json.loads(line) for line in queue.read_text().splitlines() if line.strip()]
  job=next((j for j in jobs if not (r/'results'/f"{j['id']}.receipt.json").exists()),None)
  if job is None:time.sleep(2);continue
  ident=job['id'];receipt=r/'results'/f'{ident}.receipt.json'
  dependencies=[json.loads((r/'results'/f'{d}.receipt.json').read_text()).get('exit_code') if (r/'results'/f'{d}.receipt.json').exists() else None for d in job.get('requires',[])]
  if any(v is None for v in dependencies):time.sleep(2);continue
  if any(v!=0 for v in dependencies):save(receipt,{'id':ident,'state':'prerequisite_failed','exit_code':125,'requires':job['requires']});continue
  record={'id':ident,'state':'running','start_utc':utc(),'job':job,'artifact_sha256':{f:(sha(f) if Path(f).is_file() else None) for f in job.get('artifacts',[])},'power_before':subprocess.run(['pmset','-g','batt'],capture_output=True,text=True).stdout}
  if any(v is None for v in record['artifact_sha256'].values()):record.update(state='artifact_missing',exit_code=124);save(receipt,record);continue
  expected=job.get('expected_sha256',{})
  if any(record['artifact_sha256'].get(f)!=h for f,h in expected.items()):record.update(state='artifact_mismatch',exit_code=124);save(receipt,record);continue
  state=json.loads((r/'session.json').read_text());state['phase']=ident;state['current_job']=ident;save(r/'session.json',state)
  save(r/'current.json',record)
  started=time.monotonic();env={**os.environ,**job.get('env',{})}
  with (r/'results'/f'{ident}.stdout').open('w') as out,(r/'logs'/f'{ident}.stderr').open('w') as err:
   p=subprocess.Popen(job['command'],cwd=job.get('cwd','/Users/linson/Documents/ai/splash'),env=env,stdout=out,stderr=err,start_new_session=True)
   record['pid']=p.pid;save(r/'current.json',record)
   timed_out=False
   try:p.wait(timeout=max(1,min(job.get('timeout_seconds',900),deadline-time.time())))
   except subprocess.TimeoutExpired:
    timed_out=True;os.killpg(p.pid,signal.SIGINT)
    try:p.wait(timeout=20)
    except subprocess.TimeoutExpired:
     os.killpg(p.pid,signal.SIGTERM)
     try:p.wait(timeout=10)
     except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=10)
  record.update(state='timeout' if timed_out else 'complete',exit_code=p.returncode,elapsed_seconds=time.monotonic()-started,end_utc=utc(),artifact_sha256_after={f:(sha(f) if Path(f).is_file() else None) for f in job.get('artifacts',[])},power_after=subprocess.run(['pmset','-g','batt'],capture_output=True,text=True).stdout)
  if record['artifact_sha256_after']!=record['artifact_sha256']:record.update(state='artifact_changed_during_job',exit_code=123)
  save(receipt,record);save(r/'current.json',record)
  print(json.dumps({'job':ident,'state':record['state'],'exit_code':record['exit_code'],'elapsed_seconds':record['elapsed_seconds']}),flush=True)
finally:
 save(r/'runner-stopped.json',{'utc':utc(),'deadline_reached':time.time()>=deadline})
 fcntl.flock(lock,fcntl.LOCK_UN);lock.close()

from pathlib import Path
import datetime as dt,json,math,subprocess,time
r=Path(__file__).resolve().parents[1]
deadline=dt.datetime.fromisoformat(json.loads((r/'session.json').read_text())['deadline_utc']).timestamp()
command=['caffeinate','-i','-t',str(max(1,math.ceil(deadline-time.time())))]
p=subprocess.Popen(command)
(r/'notes/awake.json').write_text(json.dumps({'pid':p.pid,'command':command,'start_unix':time.time(),'deadline_unix':deadline},indent=2)+'\n')
try:p.wait()
finally:
 if p.poll() is None:p.terminate();p.wait(timeout=5)

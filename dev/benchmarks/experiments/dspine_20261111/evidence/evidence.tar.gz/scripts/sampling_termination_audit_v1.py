"""Describe retained output lengths; add no statistical tests or model runs."""

from pathlib import Path
from collections import Counter, defaultdict
import hashlib
import json

root = Path(__file__).resolve().parents[1]
nomination = json.loads((root / 'notes/sampling4-nominations-v1.json').read_text())
protocol = json.loads((root / 'notes/sampling4-protocol-v1.json').read_text())
names = {line.split()[0] for line in (root / 'cohorts' / protocol['cohort']).read_text().splitlines()}
arms = []
for arm in [nomination['control'], *nomination['candidates']]:
    values = defaultdict(dict)
    errors, sources = [], []
    for ident in arm['jobs']:
        try:
            receipt = json.loads((root / 'results' / (ident + '.receipt.json')).read_text())
            assert receipt['exit_code'] == 0 and receipt['state'] == 'complete'
            path = root / 'results' / (ident + '.stdout')
            doc = json.loads(path.read_text())
            chunk = defaultdict(dict)
            for row in doc['measurements']:
                seed = doc['study_seed_base'] + row['sample']
                name, length = row['scenario'], len(row['output_tokens'])
                assert name in names and seed not in values[name] and seed not in chunk[name]
                assert 0 <= length <= protocol['output_cap']
                chunk[name][seed] = length
            chunk_seeds = set(range(doc['study_seed_base'], doc['study_seed_base'] + protocol['samples_per_chunk']))
            assert set(chunk) == names and all(set(v) == chunk_seeds for v in chunk.values())
            for name, rows in chunk.items():
                values[name].update(rows)
            sources.append({'job': ident, 'stdout_sha256': hashlib.sha256(path.read_bytes()).hexdigest()})
        except (OSError, ValueError, KeyError, AssertionError) as error:
            errors.append(ident + ': ' + str(error))
    expected = set(range(arm['seed_start'], arm['seed_start'] + protocol['samples_per_arm_per_context']))
    complete = not errors and set(values) == names and all(set(v) == expected for v in values.values())
    contexts = []
    for name in sorted(names):
        lengths = list(values[name].values())
        contexts.append({'context': name, 'requests_in_complete_chunks': len(lengths),
                         'zero_output_requests': sum(n == 0 for n in lengths),
                         'requests_below_cap': sum(n < protocol['output_cap'] for n in lengths),
                         'requests_at_cap': sum(n == protocol['output_cap'] for n in lengths),
                         'output_length_histogram': dict(sorted(Counter(lengths).items()))})
    arms.append({'name': arm['name'], 'status': 'complete' if complete else 'incomplete',
                 'errors': errors, 'sources': sources, 'contexts': contexts})
result = {'status': 'complete' if all(v['status'] == 'complete' for v in arms) else 'incomplete',
          'arms': arms, 'cap': protocol['output_cap'], 'additional_significance_tests': 0,
          'specific_stop_reason_saved': False,
          'scope': 'Descriptive output lengths from complete retained chunks. Below-cap completion is reported without assigning a specific EOS/EOT reason, which the original driver does not save. Zero-output requests are counted explicitly. Incomplete arms retain their actual count; this audit does not turn them into a smaller complete statistical screen.'}
path = root / 'results/sampling-termination-v1.json'
assert not path.exists()
path.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'status': result['status'], 'requests': sum(c['requests_in_complete_chunks'] for a in arms for c in a['contexts']),
                  'below_cap': sum(c['requests_below_cap'] for a in arms for c in a['contexts']),
                  'zero_output': sum(c['zero_output_requests'] for a in arms for c in a['contexts'])}))

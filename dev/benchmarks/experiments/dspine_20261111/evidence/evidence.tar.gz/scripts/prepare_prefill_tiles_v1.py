"""Prepare column-width and grid-locality experiments without changing the repo."""
from pathlib import Path
root = Path(__file__).resolve().parents[1]
original = (root / 'runtime16-v10/runtime/metal/kernels/shared/gguf_linear.metal').read_text()
start = original.index('template <class F, ushort RowsPerSG, ushort Simdgroups, ushort TileN')
end = original.index('// The two stages of a prefill tile.', start)
helper = original[start:end].replace('gguf_prefill_tile(', 'experimental_prefill_tile(')
source = '''#pragma clang fp reassociate(off)
#include "metal/kernels/common/gguf_staged_tile.h"
#include "metal/kernels/common/split_reduce.h"
struct PrefillWalkParams { GgufPrefillParams base; uint columns; };
'''+helper
for name, columns, walk in [('n32', 32, False), ('n64_walk4', 64, True), ('n32_walk4', 32, True)]:
    for suffix, epilogue in [('a', 'EpNone'), ('r', 'EpResidual'), ('g', 'EpUpWithGate')]:
        auxiliary = suffix != 'a'
        args = '''device bfloat *input [[buffer(0)]], device uchar *w0 [[buffer(1)]],
    device uchar *w1 [[buffer(2)]], device uchar *meta [[buffer(3)]], device bfloat *output [[buffer(4)]],'''
        if auxiliary:
            args += '\n    device bfloat *aux [[buffer(5)]],'
        args += '\n    constant PrefillWalkParams &spec [[buffer('+str(6 if auxiliary else 5)+')]],'
        args += '''
    uint2 group [[threadgroup_position_in_grid]], uint simd_lane [[thread_index_in_simdgroup]],
    uint simd_group [[simdgroup_index_in_threadgroup]]'''
        body = '  constant GgufPrefillParams &p = spec.base;\n  uint2 tile = group;\n'
        if walk:
            body += '''  const uint mt = (p.rows + GGUF_PREFILL_ROWS - 1) / GGUF_PREFILL_ROWS;
  const uint nt = spec.columns / '''+str(columns)+''';
  const uint bm = min(mt, 4u), bn = min(nt, 4u);
  const uint blocks_m = (mt + bm - 1) / bm;
  const uint block = group.x / (bm * bn), local = group.x % (bm * bn);
  tile = uint2((block % blocks_m) * bm + local % bm,
               (block / blocks_m) * bn + local / bm);
  if (tile.x >= mt || tile.y >= nt) return;
'''
        body += '  threadgroup half stage[2 * '+str(columns)+' * GGUF_PREFILL_STEP];\n'
        body += '''  threadgroup half2 table[1];
  const uint first = tile.x * GGUF_PREFILL_ROWS;
  const uint rows = p.rows > first ? p.rows - first : 0;
  experimental_prefill_tile<FmtAF4G64, GGUF_PREFILL_SIMDGROUP_ROWS, GGUF_PREFILL_SIMDGROUPS,
      '''+str(columns)+', GGUF_PREFILL_STEP, '+epilogue+'''>(input + ulong(first) * p.input_size,
      w0, w1, meta, output + ulong(first) * p.out_stride, p.input_size,
      tile.y * '''+str(columns)+''', rows, stage, table, simd_lane, simd_group, p.out_stride, p.out_offset'''
        if auxiliary:
            body += ', aux + ulong(first) * p.out_stride'
        body += ');\n'
        source += '\nkernel void gguf_prefill_af4g64_'+name+'_'+suffix+'('+args+') {\n'+body+'}\n'
(root / 'scripts/prefill_tiles_v1.metal').write_text(source)
print('Prepared three prefill variants, three epilogues each')

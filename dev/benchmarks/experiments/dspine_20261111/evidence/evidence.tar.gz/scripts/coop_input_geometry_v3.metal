#include <metal_stdlib>
#include <MetalPerformancePrimitives/MetalPerformancePrimitives.h>
using namespace metal;
using namespace mpp::tensor_ops;

template<ushort Rows, ushort Columns>
inline void describe(device uint *out, uint lane) {
  constexpr auto d = matmul2d_descriptor(Rows, Columns, 32, false, true, false,
                                       matmul2d_descriptor::mode::multiply_accumulate);
  matmul2d<d, execution_simdgroup> op;
  auto right = op.template get_right_input_cooperative_tensor<bfloat, half, float>();
  using Left = tensor<device bfloat, dextents<int, 2>, tensor_inline>;
  auto destination = op.template get_destination_cooperative_tensor<Left, decltype(right), float>();
  if (lane == 0) {
    out[0] = Rows;
    out[3] = Columns;
    out[1] = right.get_capacity();
    out[2] = destination.get_capacity();
  }
  if (right.get_capacity() > 128) return;
  for (uint i = 0; i < right.get_capacity(); ++i) {
    const auto at = right.get_multidimensional_index(i);
    const uint base = 64 + (lane * 128 + i) * 3;
    out[base] = right.is_valid_element(i);
    out[base + 1] = at[0];
    out[base + 2] = at[1];
  }
}
kernel void coop_input_geometry(device uint *out [[buffer(0)]], uint lane [[thread_index_in_simdgroup]]) {
  describe<32, 16>(out + 0, lane);
  describe<48, 16>(out + 16384, lane);
  describe<64, 16>(out + 32768, lane);
  describe<32, 32>(out + 49152, lane);
  describe<48, 32>(out + 65536, lane);
  describe<64, 32>(out + 81920, lane);
}

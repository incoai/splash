#pragma once
#include "model/RuntimeInstrumentation.hpp"
#include <cstdlib>

// Diagnostic only. The engine's batch-completed event runs after the command
// completed and before it starts the next command. Capture there rather than
// race a subsequent command's host-step copy from a polling observer.
struct LogitProbe;
inline LogitProbe *activeLogitProbe = nullptr;

struct LogitProbe {
  splash::model::Runtime &runtime;
  std::ofstream meta, binary;
  uint32_t vocabulary, cap, produced = 0;
  uint64_t offset = 0;
  std::vector<std::pair<uint32_t, uint32_t>> predictions;
  LogitProbe(splash::model::Runtime &r, const std::filesystem::path &directory,
             const std::string &scenario, uint32_t sample, uint32_t limit, uint32_t vocab)
      : runtime(r), vocabulary(vocab), cap(limit) {
    std::filesystem::create_directories(directory);
    const auto stem = directory / (scenario + "-s" + std::to_string(sample));
    meta.open(stem.string() + ".jsonl");
    binary.open(stem.string() + ".f32", std::ios::binary);
    if (!meta || !binary) throw std::runtime_error("cannot open diagnostic logits");
    splash::model::RuntimeInstrumentation::captureTargetLogits(runtime, true);
  }
  ~LogitProbe() {
    if (activeLogitProbe == this) activeLogitProbe = nullptr;
    splash::model::RuntimeInstrumentation::captureTargetLogits(runtime, false);
  }
  void batch(splash::model::WorkKind kind, uint32_t width, uint32_t outputs, uint32_t accepted) {
    auto lanes = splash::model::RuntimeInstrumentation::takeTargetLogits(runtime);
    if (!lanes.empty()) {
      if (width != 1 || lanes.size() != 1 || lanes[0].size() % vocabulary)
        throw std::runtime_error("diagnostic capture requires one complete lane");
      const bool prefill = kind == splash::model::WorkKind::Prefill;
      const uint32_t rows = std::min<uint32_t>(lanes[0].size() / vocabulary, prefill ? 1 : accepted + 1);
      for (uint32_t row = 0; row < rows; ++row) {
        const uint32_t position = prefill ? 0 : produced + 1 + row;
        if (position >= cap) continue;
        const float *values = lanes[0].data() + uint64_t(row) * vocabulary;
        std::vector<uint32_t> ids(vocabulary);
        std::iota(ids.begin(), ids.end(), 0u);
        std::partial_sort(ids.begin(), ids.begin() + 8, ids.end(), [&](uint32_t a, uint32_t b) {
          return values[a] != values[b] ? values[a] > values[b] : a < b;
        });
        predictions.emplace_back(position, ids[0]);
        constexpr std::array<uint32_t, 14> selected{0, 1, 7, 8, 15, 16, 31, 32, 33, 34, 35, 47, 48, 63};
        const bool keep = std::find(selected.begin(), selected.end(), position) != selected.end();
        meta << "{\"prediction_index\":" << position << ",\"prefill\":" << (prefill ? "true" : "false")
             << ",\"output_count_before\":" << produced << ",\"batch_outputs\":" << outputs
             << ",\"accepted\":" << accepted << ",\"row\":" << row
             << ",\"vocabulary\":" << vocabulary << ",\"binary_offset\":";
        if (keep) {
          meta << offset;
          binary.write(reinterpret_cast<const char *>(values), uint64_t(vocabulary) * sizeof(float));
          offset += uint64_t(vocabulary) * sizeof(float);
        } else meta << "null";
        meta << ",\"top8\":[";
        for (uint32_t i = 0; i < 8; ++i)
          meta << (i ? "," : "") << "[" << ids[i] << "," << std::setprecision(10) << values[ids[i]] << "]";
        meta << "]}\n";
      }
    }
    produced += outputs;
    meta.flush(); binary.flush();
    if (!meta || !binary) throw std::runtime_error("diagnostic write failed");
  }
  void validate(const std::vector<uint32_t> &outputs) const {
    for (const auto &[position, argmax] : predictions)
      if (position < outputs.size() && argmax != outputs[position])
        throw std::runtime_error("diagnostic row/returned-token mapping differs at index " + std::to_string(position));
  }
};

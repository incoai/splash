"""Audit an explicitly bounded trace snapshot, including missing coverage."""
from collections import Counter
from pathlib import Path
import argparse
import datetime as dt
import hashlib
import json
import statistics

root = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser()
parser.add_argument('--partial', action='store_true')
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
session = json.loads((root / 'session.json').read_text())
start = dt.datetime.fromisoformat(session['start_utc']).timestamp()
deadline = dt.datetime.fromisoformat(session['deadline_utc']).timestamp()
if not args.partial:
    assert dt.datetime.now(dt.timezone.utc).timestamp() >= deadline
    assert (root / 'runner-stopped.json').exists(), 'runner has not stopped'
source = root / 'results/hardware.jsonl'
with source.open('rb') as stream:
    contents = stream.read(source.stat().st_size)
trailing = 0
if not contents.endswith(b'\n'):
    assert args.partial, 'incomplete final telemetry line'
    kept = contents.rfind(b'\n') + 1
    trailing = len(contents) - kept
    contents = contents[:kept]
count = Counter()
first = last = previous = None
gaps = []
long_gaps = []
maxima = {'ram_usage_bytes': 0, 'swap_usage_bytes': 0, 'gpu_frequency_mhz': 0,
          'gpu_power_watts': 0, 'cpu_temperature_c': 0, 'gpu_temperature_c': 0}
for line in contents.splitlines():
    value = json.loads(line)
    when = value['recorded_unix']
    if first is None:
        first = when
    if previous is not None:
        gap = when - previous['recorded_unix']
        assert gap > 0, 'trace time is not strictly increasing'
        gaps.append(gap)
        if gap > 5:
            long_gaps.append({'gap_seconds': gap, 'before_utc': previous['timestamp'],
                             'after_utc': value['timestamp'],
                             'before_phase': previous.get('investigation_phase'),
                             'after_phase': value.get('investigation_phase')})
    count[value.get('investigation_phase', 'unknown')] += 1
    for key, candidate in [('ram_usage_bytes', value['memory']['ram_usage']),
        ('swap_usage_bytes', value['memory']['swap_usage']), ('gpu_frequency_mhz', value['gpu_freq_mhz']),
        ('gpu_power_watts', value['gpu_power']), ('cpu_temperature_c', value['temp']['cpu_temp_avg']),
        ('gpu_temperature_c', value['temp']['gpu_temp_avg'])]:
        maxima[key] = max(maxima[key], candidate)
    previous = value
    last = when
assert gaps and first is not None and last is not None
iso = lambda value: dt.datetime.fromtimestamp(value, dt.timezone.utc).isoformat()
ordered = sorted(gaps)
record = {'partial': args.partial, 'audited_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
    'input': 'results/hardware.jsonl', 'input_complete_line_bytes': len(contents),
    'input_complete_line_prefix_sha256': hashlib.sha256(contents).hexdigest(),
    'trailing_partial_bytes_excluded': trailing, 'samples': sum(count.values()),
    'first_utc': iso(first), 'last_utc': iso(last),
    'initial_uncovered_seconds': max(0, first - start),
    'seconds_to_deadline_after_last_sample': max(0, deadline - last),
    'median_sample_gap_seconds': statistics.median(gaps),
    'p99_sample_gap_seconds': ordered[min(len(ordered) - 1, int(.99 * len(ordered)))],
    'maximum_sample_gap_seconds': max(gaps), 'gaps_over_five_seconds': long_gaps,
    'maxima': maxima, 'samples_by_phase': dict(count),
    'scope': 'Recorded wall-clock telemetry coverage, including initialization gap and every >5s sample gap. Maxima span functional/research/controlled work and are not controlled benchmark endpoints. macmon does not record AC source or OS thermal state; controlled rounds have their separate sampled operating receipts.'}
assert not args.output.exists()
args.output.write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({k: record[k] for k in ['partial', 'samples', 'first_utc', 'last_utc',
    'initial_uncovered_seconds', 'maximum_sample_gap_seconds', 'maxima']}, indent=2))

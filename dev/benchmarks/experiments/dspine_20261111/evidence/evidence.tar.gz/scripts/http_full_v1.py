"""Real loopback service integration, retaining status, answers and clean shutdown."""
from pathlib import Path
import json
import os
import signal
import subprocess
import sys
import time

root = Path(__file__).resolve().parents[1]
ident, variant, rows = sys.argv[1:]
tree = root / variant
sys.path.insert(0, str(tree))
from dev.tests import smoke_real as smoke

directory = root / 'http' / ident
directory.mkdir(parents=True, exist_ok=False)
model_root = Path('/Users/linson/Documents/ai/splash/build/dspine/model-root.txt').read_text().strip()
port = smoke.available_port()
model = 'local/dspine-13h'
command = [sys.executable, '-m', 'server.server', model_root,
           '--binary', str(root / 'artifacts' / variant / 'splash'), '--model', model,
           '--host', '127.0.0.1', '--port', str(port), '--max-context', '32768',
           '--kv-format', 'int8', '--state-format', 'fp32', '--disable-ane',
           '--verify-rows', 'all', '--draft-block-size', rows]
record = {'id': ident, 'variant': variant, 'rows': int(rows), 'command': command,
          'shader_validation': os.environ.get('MTL_SHADER_VALIDATION'), 'passed': False}


def save():
    p = directory / 'result.json.tmp'
    p.write_text(json.dumps(record, indent=2) + '\n')
    p.replace(directory / 'result.json')


# Keep complete request/response evidence. Concurrent calls are one JSON line
# each; writes use one append call and the real model's existing smoke checks.
original_request = smoke.request


def recorded_request(*args, **kwargs):
    answer = original_request(*args, **kwargs)
    value = {'arguments': args, 'options': kwargs, 'answer': answer}
    data = (json.dumps(value, ensure_ascii=False) + '\n').encode()
    fd = os.open(directory / 'requests.jsonl', os.O_WRONLY | os.O_APPEND | os.O_CREAT, 0o600)
    try:
        os.write(fd, data)
    finally:
        os.close(fd)
    return answer


smoke.request = recorded_request
save()
with (directory / 'server.log').open('w') as log:
    process = subprocess.Popen(command, cwd=tree, stdout=log, stderr=subprocess.STDOUT)
    record['server_pid'] = process.pid
    save()
    try:
        deadline = time.monotonic() + 300
        while time.monotonic() < deadline:
            smoke.require(process.poll() is None, 'service exited during startup')
            try:
                code, status = smoke.request(port, 'GET', '/status', timeout=1)
                if code == 200 and status.get('ready'):
                    break
            except (OSError, smoke.SmokeFailure):
                pass
            time.sleep(.25)
        else:
            raise RuntimeError('service startup timed out')
        smoke.validate_status(status, 'int8')
        smoke.require(status.get('draft_block_size', 8) == int(rows), 'service geometry differs')
        record['status_start'] = status
        save()
        smoke.run(port, model)
        record['status_end'] = smoke.runtime_status(port)
        smoke.validate_status(record['status_end'], 'int8')
        record['passed'] = True
        save()
        print('Full HTTP service smoke passed', flush=True)
    except BaseException as error:
        record['error'] = repr(error)
        save()
        raise
    finally:
        if process.poll() is None:
            process.send_signal(signal.SIGINT)
        try:
            process.wait(timeout=45)
        except subprocess.TimeoutExpired:
            process.terminate()
            try:
                process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait(timeout=10)
        record['server_exit_code'] = process.returncode
        save()
        smoke.require(process.returncode == 0, 'service did not stop cleanly')

"""Validate the permanent test helper against a consistent frozen v12 ABI."""
from pathlib import Path
import hashlib,json,shutil,subprocess
r=Path(__file__).resolve().parents[1];tree=r/'runtime16-v12';out=r/'artifacts/register16-permanent-v1';out.mkdir(exist_ok=False)
src=r/'scripts/gguf_projection_permanent_v1.mm';inputs=[src,tree/'build/engine/libsplash.a',tree/'build/splash.metallib',tree/'dev/tests/engine/GgufFormatReference.hpp']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();before={str(p):sha(p) for p in inputs}
cmd=['xcrun','-sdk','macosx','clang++','-std=c++20','-O3','-Wall','-Wextra','-Werror','-mmacosx-version-min=26.4','-fobjc-arc','-I'+str(tree/'runtime'),'-I'+str(tree/'dev/tests/engine'),str(src),str(tree/'build/engine/libsplash.a'),'-framework','Foundation','-framework','Metal','-framework','IOKit','-framework','IOSurface','-o',str(out/'oracle')]
subprocess.run(cmd,check=True)
assert before=={str(p):sha(p) for p in inputs}
for name in ['splash.metallib','host-step.metallib']:shutil.copy2(tree/'build'/name,out/name)
(out/'build.json').write_text(json.dumps({'command':cmd,'inputs':before,'artifacts':{p.name:sha(p) for p in out.iterdir()},'scope':'Numerical preflight of exact permanent test source with consistent v12 headers/library; final full Metal run still required against combined source.'},indent=2)+'\n')

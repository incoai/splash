#include "GgufFormatReference.hpp"
#include "metal/CommandGraph.hpp"
#include "metal/abi/Gguf.h"
#include <array>
#include <cstring>
#include <iostream>
#include <random>
#include <stdexcept>
using namespace splash;
using namespace gguf_reference;

struct Guarded {
  metal::MetalBuffer base, view;
  uint64_t bytes;
  Guarded(metal::MetalBackend &b, uint64_t size, uint8_t fill = 0) : bytes(size) {
    base = b.allocateBuffer(size + 256, metal::BufferStorage::Shared, "prefill oracle");
    std::memset(base.contents(), fill, size);
    std::memset(static_cast<uint8_t *>(base.contents()) + size, 0xa5, 256);
    view = b.view(base, 0, size);
  }
  void check() const {
    const auto *p = static_cast<const uint8_t *>(base.contents()) + bytes;
    if (!std::all_of(p, p + 256, [](uint8_t x) { return x == 0xa5; }))
      throw std::runtime_error("prefill guard overwritten");
  }
};
struct Weight { metal::MetalBuffer code, other, meta; std::vector<float> reference; };
Weight weight(metal::MetalBackend &b, uint32_t n, uint32_t k, std::mt19937 &rng, bool reference) {
  const auto native = makeNative(Fmt(GGUF_FMT_AF4G64), n, k, rng);
  Weight w;
  const auto packed = repack(Fmt(GGUF_FMT_AF4G64), native, n, k, reference ? &w.reference : nullptr);
  const auto upload = [&](const auto &v) {
    auto result = b.allocateBuffer(v.size(), metal::BufferStorage::Shared, "prefill AF4 planes");
    std::memcpy(result.contents(), v.data(), v.size()); return result;
  };
  w.code = upload(packed.w0); w.other = upload(packed.w1); w.meta = upload(packed.meta);
  return w;
}
struct WalkParams { GgufPrefillParams base; uint32_t columns; };
static_assert(sizeof(WalkParams) == sizeof(GgufPrefillParams) + 4);
float rounded(double x) { return test::bf16ToFloat(test::floatToBf16(float(x))); }
double silu(double x) { return x / (1 + std::exp(-x)); }

void run(metal::MetalBackend &backend, uint32_t rows, uint32_t n, uint32_t k, bool benchmark, uint32_t filter) {
  std::mt19937 rng(81921 + rows + n + k);
  auto w = weight(backend, n, k, rng, !benchmark);
  const uint32_t stored = (rows + 127) / 128 * 128, stride = n + 64;
  Guarded input(backend, uint64_t(stored) * k * 2), output(backend, uint64_t(stored) * stride * 2, 0xcd),
          auxiliary(backend, uint64_t(stored) * stride * 2);
  auto *x = static_cast<uint16_t *>(input.view.contents()), *aux = static_cast<uint16_t *>(auxiliary.view.contents());
  std::vector<float> xf(uint64_t(rows) * k);
  std::uniform_real_distribution<float> dist(-.2f, .2f);
  for (uint32_t r = 0; r < stored; ++r) {
    for (uint32_t c = 0; c < k; ++c) {
      const auto at = uint64_t(r) * k + c;
      x[at] = r < rows ? test::floatToBf16(dist(rng)) : 0x7fc0;
      if (r < rows) xf[at] = test::bf16ToFloat(x[at]);
    }
    for (uint32_t c = 0; c < stride; ++c)
      aux[uint64_t(r) * stride + c] = r < rows ? test::floatToBf16(dist(rng)) : 0x7fc0;
  }
  uint64_t comparisons = 0, fp64 = 0;
  for (char ep : {'a', 'r', 'g'}) {
    std::vector<uint16_t> baseline;
    const std::vector<uint32_t> modes = filter
        ? (benchmark ? std::vector<uint32_t>{0, filter, filter, 0} : std::vector<uint32_t>{0, filter})
        : (benchmark ? std::vector<uint32_t>{0, 1, 2, 3, 3, 2, 1, 0} : std::vector<uint32_t>{0, 1, 2, 3});
    for (uint32_t mode : modes) {
      const std::array<std::string, 4> prefixes{"gguf_prefill_af4g64_", "gguf_prefill_af4g64_n32_",
          "gguf_prefill_af4g64_n64_walk4_", "gguf_prefill_af4g64_n32_walk4_"};
      const std::string kernel = prefixes[mode] + ep;
      const uint32_t columns = mode == 1 || mode == 3 ? 32 : 64, mt = stored / 128, nt = n / columns;
      metal::DispatchSize grid{mt, nt, 1};
      if (mode >= 2) {
        const uint32_t bm = std::min(mt, 4u), bn = std::min(nt, 4u);
        grid = {uint64_t((mt + bm - 1) / bm) * ((nt + bn - 1) / bn) * bm * bn, 1, 1};
      }
      GgufPrefillParams p{k, rows, stride, 0};
      std::vector<metal::MetalBuffer> bindings{input.view, w.code, w.other, w.meta, output.view};
      if (ep != 'a') bindings.push_back(auxiliary.view);
      const auto graph = [&](uint32_t count) {
        metal::CommandGraph result;
        for (uint32_t i = 0; i < count; ++i) {
          if (mode == 0) result.add(kernel, bindings, p, grid, {128, 1, 1});
          else result.add(kernel, bindings, WalkParams{p, n}, grid, {128, 1, 1});
        }
        return result;
      };
      auto work = graph(benchmark ? 16 : 1);
      backend.preparePipelines(work.dispatches());
      if (benchmark) { auto warm = graph(2); (void)backend.submitCommandAsync(warm.dispatches()).wait(); }
      std::memset(output.view.contents(), 0xcd, output.bytes);
      const auto seconds = backend.submitCommandAsync(work.dispatches()).wait().gpuSeconds;
      input.check(); output.check(); auxiliary.check();
      const auto *out = static_cast<const uint16_t *>(output.view.contents());
      if (mode == 0) baseline.assign(out, out + uint64_t(rows) * stride);
      else {
        comparisons += uint64_t(rows) * stride;
        if (!std::equal(baseline.begin(), baseline.end(), out)) throw std::runtime_error("prefill bits differ");
      }
      const uint32_t touched = (rows + 31) / 32 * 32;
      for (uint32_t r = 0; r < stored; ++r) for (uint32_t c = 0; c < stride; ++c) {
        const auto value = out[uint64_t(r) * stride + c];
        if ((r >= touched || c >= n) && value != 0xcdcd) throw std::runtime_error("padding destination written");
        if (r >= rows && r < touched && c < n && !std::isnan(test::bf16ToFloat(value)))
          throw std::runtime_error("NaN padding not isolated");
      }
      if (!benchmark) for (uint32_t r : {0u, rows / 2, rows - 1}) for (uint32_t c : {0u, n / 2, n - 1}) {
        const auto d = dot(xf.data() + uint64_t(r) * k, w.reference.data() + uint64_t(c) * k, k);
        const double error = projectionBound(d, true), av = test::bf16ToFloat(aux[uint64_t(r) * stride + c]);
        double lo = d.value - error, hi = d.value + error;
        if (ep == 'r') { lo += av; hi += av; }
        if (ep == 'g') {
          const double center = silu(av), t = std::fabs(av) * 1.4426950408889634;
          const double rel = (2 * (3 + std::floor(2 * t)) + 2 * std::log(2.0) * t + 6) * 0x1p-24;
          const double radius = std::fabs(center) * rel;
          double low = INFINITY, high = -INFINITY;
          for (double u : {double(rounded(lo)), double(rounded(hi))})
            for (double s : {center - radius, center + radius}) { low = std::min(low, u * s); high = std::max(high, u * s); }
          lo = low; hi = high;
        }
        const float value = test::bf16ToFloat(out[uint64_t(r) * stride + c]);
        ++fp64;
        if (!std::isfinite(value) || value < rounded(lo) || value > rounded(hi))
          throw std::runtime_error("prefill outside independent FP64 interval");
      }
      if (benchmark) std::cout << "{\"rows\":" << rows << ",\"outputs\":" << n << ",\"inputs\":" << k
          << ",\"epilogue\":\"" << ep << "\",\"mode\":" << mode << ",\"gpu_ms\":" << seconds * 1000 / 16 << "}\n";
    }
  }
  std::cout << "{\"case_passed\":true,\"rows\":" << rows << ",\"outputs\":" << n << ",\"inputs\":" << k
            << ",\"bitwise_comparisons\":" << comparisons << ",\"independent_fp64_checks\":" << fp64 << "}\n";
}
int main(int argc, char **argv) {
  try {
    if (argc < 2 || argc > 3) throw std::invalid_argument("usage: prefill-tiles-oracle LIBRARY [--benchmark]");
    const std::string option = argc == 3 ? argv[2] : "";
    const bool benchmark = option == "--benchmark" || option.starts_with("--benchmark-variant=");
    uint32_t filter = 0;
    if (option.starts_with("--variant=") || option.starts_with("--benchmark-variant=")) {
      if (option.back() < '1' || option.back() > '3' || option[option.size() - 2] != '=')
        throw std::invalid_argument("invalid variant");
      filter = uint32_t(option.back() - '0');
    } else if (!option.empty() && !benchmark) throw std::invalid_argument("unknown option");
    metal::MetalBackend backend(argv[1]);
    if (benchmark) for (uint32_t rows : {128u, 512u, 2048u})
      for (auto [n, k] : {std::pair{17408u, 5120u}, std::pair{5120u, 17408u}, std::pair{12288u, 5120u}})
        run(backend, rows, n, k, true, filter);
    else for (uint32_t rows : {1u, 31u, 32u, 33u, 64u, 65u, 127u, 128u, 129u, 263u})
      for (uint32_t n : {128u, 192u}) for (uint32_t k : {512u, 1152u}) run(backend, rows, n, k, false, filter);
  } catch (const std::exception &e) { std::cerr << e.what() << '\n'; return 1; }
}

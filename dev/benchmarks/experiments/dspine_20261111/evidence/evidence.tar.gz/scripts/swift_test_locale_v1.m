#import <Foundation/Foundation.h>
#include <stdlib.h>
#include <string.h>

// Test-process fixture only. NSArgumentDomain is volatile: no defaults file or
// user/system setting is written. Preserve all existing launch arguments.
__attribute__((constructor)) static void testLocale(void) {
  const char *locale = getenv("DSPINE_TEST_LOCALE");
  if (!locale || strcmp(locale, "en_US")) return;
  @autoreleasepool {
    NSUserDefaults *defaults = NSUserDefaults.standardUserDefaults;
    NSMutableDictionary *arguments =
        [[defaults volatileDomainForName:NSArgumentDomain] mutableCopy];
    if (!arguments) arguments = [NSMutableDictionary dictionary];
    arguments[@"AppleLocale"] = @"en_US";
    [defaults setVolatileDomain:arguments forName:NSArgumentDomain];
  }
}

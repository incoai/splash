"""Finish components not completed within the broad run's wall-time budget."""
from pathlib import Path
import json
import os
import shlex
import subprocess

root = Path(__file__).resolve().parents[1]
tree = root / 'runtime16-v10'
receipt = json.loads((root / 'results/full-metal-regression-v10.receipt.json').read_text())
if receipt['exit_code'] == 0:
    print('The original broad Metal run completed; no component repetition needed.', flush=True)
    raise SystemExit(0)
assert receipt['state'] == 'timeout', 'a real test failure must not be treated as a timeout'
commands = (root / 'notes/full-metal-commands-v10.txt').read_text().splitlines()
output = set((root / 'results/full-metal-regression-v10.stdout').read_text().splitlines())
started = [i for i, line in enumerate(commands) if line in output]
assert started, 'no echoed command found'
last = max(started)
summary = {'original_receipt': receipt['id'], 'original_state': receipt['state'],
           'original_last_started': commands[last], 'components': [], 'passed': False}
for raw in commands[last:]:
    argv = shlex.split(raw)
    env = dict(os.environ)
    while argv and '=' in argv[0] and not argv[0].startswith('/'):
        key, value = argv.pop(0).split('=', 1)
        env[key] = value
    assert argv and argv[0].startswith('build/engine-tests/'), 'unexpected recipe command'
    name = Path(argv[0]).name
    targeted = root / 'results' / f'runtime16-v10-{name}-shader.receipt.json'
    if targeted.exists() and json.loads(targeted.read_text())['exit_code'] == 0:
        summary['components'].append({'command': raw, 'status': 'already passed targeted check',
                                      'receipt': str(targeted)})
        continue
    print('Remaining component: ' + raw, flush=True)
    result = subprocess.run(argv, cwd=tree, env=env)
    summary['components'].append({'command': raw, 'exit_code': result.returncode})
    (root / 'results/metal-tail-v10-components.json').write_text(json.dumps(summary, indent=2) + '\n')
    if result.returncode:
        raise SystemExit(result.returncode)
summary['passed'] = True
(root / 'results/metal-tail-v10-components.json').write_text(json.dumps(summary, indent=2) + '\n')
print('All remaining broad Metal components passed; original timed-out receipt retained.', flush=True)

"""Exercise eligible disk points and test short-window namespaces honestly."""
from pathlib import Path
import datetime as dt
import fcntl
import hashlib
import json
import os
import signal
import stat
import subprocess
import sys
import time

root = Path(__file__).resolve().parents[1]
ident, variant = sys.argv[1:]
sys.path.insert(0, str(root / variant))
from dev.tests import smoke_real as smoke

out = root / 'http' / ident
out.mkdir(exist_ok=False)
cache = out / 'cache'
model = 'local/dspine-cache-isolation'
model_root = Path('/Users/linson/Documents/ai/splash/build/dspine/model-root.txt').read_text().strip()
record = {'id': ident, 'variant': variant, 'runs': [], 'passed': False,
    'shader_validation': os.environ.get('MTL_SHADER_VALIDATION'),
    'fixture_correction': 'V1 used645prompttokens, below the existing WriteBehind2048token minimum; the old baseline wrote no disk points. V2 uses the previously retained15928-token long lifecycle prompt for actual takeover/restore. Short layouts retain the645-token fixture and correctly expect no disk writes. Source compatibility compares old/new warm disk-restored modes, not different cold/warm chunk decompositions.'}


def save():
    p = out / 'result.json.tmp'
    p.write_text(json.dumps(record, indent=2) + '\n')
    p.replace(out / 'result.json')


def namespaces():
    return sorted(p.name for p in cache.iterdir() if p.is_dir()) if cache.exists() else []


def closed():
    for path in cache.iterdir():
        smoke.require(smoke.CACHE_NAMESPACE.fullmatch(path.name) is not None and path.is_dir(), 'invalid namespace')
        smoke.require(stat.S_IMODE(path.stat().st_mode) == 0o700, 'namespace permissions')
        smoke.require({p.name for p in path.iterdir()} == smoke.CACHE_FILES | {'lock'}, 'unclean namespace')
        with (path / 'lock').open('rb') as lock:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)


long_prompt = smoke.filler('dspine20261110', 'long-lifecycle', 500) + '\nUsing the appendix as irrelevant background, write an iterative Python function that checks if a number is prime. Return only code.'
short_prompt = smoke.filler('dspine13h', 'layout-isolation', 24) + '\nWrite an iterative Python function that checks whether an integer is prime. Return only code.'
bodies = {kind: smoke.chat_body(model, prompt, max_completion_tokens=96, seed=20261110,
    cache_salt=ident + '-same-lineage') for kind, prompt in [('long', long_prompt), ('short', short_prompt)]}
# The first warm old8 run is the like-for-like source-compatibility reference.
# Two warm sixteen-row restarts test stable restoration without assuming every
# cold/warm prefill decomposition is bitwise identical.
runs = [
    ('old8_seed', 'control', 8, 32768, 'long', 'new', None),
    ('old8_restored', 'control', 8, 32768, 'long', 'reuse', None),
    ('final8_restored', variant, 8, 32768, 'long', 'reuse', 'old8_restored'),
    ('final16_seed', variant, 16, 32768, 'long', 'new', None),
    ('final16_restored', variant, 16, 32768, 'long', 'reuse', None),
    ('final16_restored_again', variant, 16, 32768, 'long', 'reuse', 'final16_restored'),
    ('short8', variant, 8, 2048, 'short', 'new', None),
    ('short16', variant, 16, 2048, 'short', 'new', None),
    ('short16_restart', variant, 16, 2048, 'short', 'empty_reuse', 'short16'),
]
for name, source, rows, context, kind, expected, reference in runs:
    tree = root / source
    port = smoke.available_port()
    command = [sys.executable, '-m', 'server.server', model_root, '--binary', str(root / 'artifacts' / source / 'splash'),
        '--model', model, '--host', '127.0.0.1', '--port', str(port), '--max-context', str(context),
        '--kv-format', 'int8', '--state-format', 'fp32', '--disable-ane', '--verify-rows', 'all',
        '--persistent-cache', '--cache-dir', str(cache), '--max-cache-disk', '4G']
    if source != 'control':
        command += ['--draft-block-size', str(rows)]
    before = namespaces()
    run = {'name': name, 'source': source, 'rows': rows, 'context': context, 'kind': kind,
        'expected': expected, 'reference': reference, 'command': command, 'namespaces_before': before}
    record['runs'].append(run)
    save()
    log_path = out / (name + '.server.log')
    with log_path.open('w') as log:
        process = subprocess.Popen(command, cwd=tree, stdout=log, stderr=subprocess.STDOUT)
        try:
            deadline = time.monotonic() + 300
            while time.monotonic() < deadline:
                smoke.require(process.poll() is None, 'server exited during startup')
                try:
                    code, status = smoke.request(port, 'GET', '/status', timeout=1)
                    if code == 200 and status.get('ready'):
                        break
                except (OSError, smoke.SmokeFailure):
                    pass
                time.sleep(.25)
            else:
                raise RuntimeError('startup timeout')
            smoke.validate_status(status, 'int8')
            smoke.require(status.get('draft_block_size', 8) == rows, 'width differs')
            run['status_start'] = status
            taken = status['disk']['taken_back']
            if expected == 'reuse':
                smoke.require(taken['states'] >= 1 and taken['kv_blocks'] >= 1, name + ': no eligible disk points restored')
            else:
                smoke.require(taken['states'] == 0, name + ': wrong state namespace reused')
            code, answer = smoke.request(port, 'POST', '/v1/chat/completions', bodies[kind], timeout=600)
            smoke.require(code == 200, f'{name}: HTTP{code}: {answer}')
            content = answer['choices'][0]['message']['content']
            smoke.require(bool(content), 'empty answer')
            (out / (name + '.answer.json')).write_text(json.dumps(answer, indent=2) + '\n')
            run['output_sha256'] = hashlib.sha256(content.encode()).hexdigest()
            run['usage'] = answer['usage']
            run['status_end'] = smoke.runtime_status(port)
            n = answer['usage']['prompt_tokens']
            cached = answer['usage']['prompt_tokens_details']['cached_tokens']
            if kind == 'long':
                smoke.require(12000 <= n < 24000, 'long fixture no longer crosses8Kwindow')
                if expected == 'reuse':
                    smoke.require(cached >= n * .9, 'long prefix was not restored')
                    run['disk_state_hits'] = run['status_end']['state']['disk_hits'] - status['state']['disk_hits']
                    run['disk_kv_hit_tokens'] = run['status_end']['cache']['kv_disk_hit_tokens'] - status['cache']['kv_disk_hit_tokens']
                    smoke.require(run['disk_state_hits'] >= 1 and run['disk_kv_hit_tokens'] >= n * .9, 'no actual disk restore')
                else:
                    smoke.require(cached == 0, 'new layout unexpectedly reused prefix')
                    writes = run['status_end']['disk']['write_behind']
                    smoke.require(writes['waiting'] + writes['durable'] >= 1, 'eligible seed queued no disk point')
            else:
                smoke.require(n + 96 < 2048 and cached == 0, 'short fixture policy differs')
                writes = run['status_end']['disk']['write_behind']
                smoke.require(writes['waiting'] + writes['durable'] == 0, 'short fixture unexpectedly became disk eligible')
                run['short_disk_restore_exercised'] = False
            if reference:
                previous = next(v for v in record['runs'] if v['name'] == reference)
                smoke.require(run['output_sha256'] == previous['output_sha256'], 'matched-mode restored output differs')
                smoke.require(cached == previous['usage']['prompt_tokens_details']['cached_tokens'], 'matched-mode replay geometry differs')
            save()
        except BaseException as error:
            run['error'] = repr(error)
            save()
            raise
        finally:
            if process.poll() is None:
                process.send_signal(signal.SIGINT)
            try:
                process.wait(timeout=45)
            except subprocess.TimeoutExpired:
                process.terminate()
                try:
                    process.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait(timeout=10)
            run['exit_code'] = process.returncode
            save()
            smoke.require(process.returncode == 0, 'unclean server shutdown')
    closed()
    after = namespaces()
    run['namespaces_after'] = after
    smoke.require(len(after) == len(before) + (expected == 'new'), 'wrong namespace count')
    window = 2048 if kind == 'short' else 8192
    smoke.require(f'{rows} rows, {window} context tokens.' in log_path.read_text(), 'actual draft window differs')
    run['draft_window_confirmed'] = window
    save()
    print(json.dumps({'run': name, 'namespaces': len(after), 'prompt_tokens': run['usage']['prompt_tokens'],
        'cached_tokens': run['usage']['prompt_tokens_details']['cached_tokens'], 'passed': True}), flush=True)
smoke.require(len(namespaces()) == 4, 'wrong total physical namespaces')
record['passed'] = True
record['completed_utc'] = dt.datetime.now(dt.timezone.utc).isoformat()
save()
print('PASS actual old8/new8 disk takeover,16rowrestore,short-window namespace isolation and expected short no-write policy')

"""Compare the retained functional eight-row run with the timed sixteen-row arm."""

import hashlib
import json
from pathlib import Path

results = Path(__file__).resolve().parents[1] / "results"


def read(name):
    path = results / name
    raw = path.read_bytes()
    return json.loads(raw), hashlib.sha256(raw).hexdigest()


def retained_run(ident, expected_rows, expected_count):
    receipt, receipt_sha = read(ident + ".receipt.json")
    assert receipt["state"] == "complete" and receipt["exit_code"] == 0
    artifacts = receipt["artifact_sha256"]
    assert artifacts == receipt["artifact_sha256_after"]
    value, stdout_sha = read(ident + ".stdout")
    assert value["geometry"]["verify_rows"] == expected_rows
    assert len(value["measurements"]) == expected_count
    assert all(request["cache_status"] == "miss" for request in value["measurements"])
    identity = {
        "driver_sha256": next(
            v for p, v in artifacts.items() if p.endswith("/study-driver")
        ),
        "library_sha256": next(
            v for p, v in artifacts.items() if p.endswith("/splash.metallib")
        ),
        "cohort_sha256": next(
            v for p, v in artifacts.items() if "/cohorts/historical31" in p
        ),
        "build_id": value["build_id"],
        "model_root": value["identity"]["model_root"],
        "loaded_model_layout_sha256": value["identity"]["loaded_model_layout_sha256"],
        "temperature": value["study_temperature"],
        "ane_ffn_share": value["ane_ffn_share"],
        "context_limit": value["max_context_tokens"],
    }
    return (
        value,
        identity,
        {"job": ident, "receipt_sha256": receipt_sha, "stdout_sha256": stdout_sha},
    )


eight, identity8, source8 = retained_run(
    "final-historical31-production-final-v1-r8-v1", 8, 31
)
_, identity16, source16 = retained_run("dspine16-final-v1-g1-b1", 16, 62)
assert identity8 == identity16
audit, audit_sha = read("historical-greedy-arms-v1.json")
assert audit["within_arm_all_repetitions_match"]
assert source16["stdout_sha256"] == next(
    row["stdout_sha256"] for row in audit["rounds"] if row["job"] == source16["job"]
)
historical = {
    row["case"]: row["unique_output_sha256_per_arm"] for row in audit["cases"]
}
rows = []
for request in eight["measurements"]:
    tokens = request["output_tokens"]
    encoded = json.dumps(tokens, separators=(",", ":")).encode()
    digest = hashlib.sha256(encoded).hexdigest()
    name = request["scenario"]
    compared = historical.pop(name)
    rows.append(
        {
            "case": name,
            "final_eight_rows_sha256": digest,
            "matches_committed_eight_rows": compared["committed_dspine8"] == [digest],
            "matches_final_dflash2": compared["final_dflash2"] == [digest],
            "matches_final_sixteen_rows": compared["final_dspine16"] == [digest],
        }
    )
assert not historical
report = {
    "shared_recorded_identity": identity8,
    "sources": [source8, source16],
    "historical_greedy_audit_sha256": audit_sha,
    "cases": rows,
    "functional_eight_matches_committed_count": sum(
        row["matches_committed_eight_rows"] for row in rows
    ),
    "functional_eight_matches_dflash2_count": sum(
        row["matches_final_dflash2"] for row in rows
    ),
    "same_build_width_mismatches": sum(
        not row["matches_final_sixteen_rows"] for row in rows
    ),
    "scope": (
        "Descriptive cross-check using one retained eight-row functional pass and the "
        "repeatable sixteen-row timed outputs from the same recorded driver, library, "
        "model and cohort. This isolates the configured width path from source and drafter "
        "changes at the whole-request level. The exact responsible operator or state "
        "transition remains unresolved. No separate performance or repeatability claim "
        "for the single functional pass."
    ),
}
with (results / "historical-same-build-width-v1.json").open("x") as output:
    json.dump(report, output, indent=2)
    output.write("\n")
print(
    json.dumps(
        {k: v for k, v in report.items() if k.endswith(("_count", "_mismatches"))}
    )
)

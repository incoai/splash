#import <Foundation/Foundation.h>
#import <Metal/Metal.h>
#include <cstring>
#include <fstream>
#include <iostream>
#include <stdexcept>
int main(int argc, char **argv) {
  @autoreleasepool {
    try {
      if (argc != 3) throw std::invalid_argument("usage: coop-input-geometry LIBRARY OUTPUT");
      id<MTLDevice> device = MTLCreateSystemDefaultDevice();
      NSError *error = nil;
      id<MTLLibrary> library = [device newLibraryWithURL:[NSURL fileURLWithPath:@(argv[1])] error:&error];
      if (!library) throw std::runtime_error(error.localizedDescription.UTF8String);
      id<MTLComputePipelineState> pipeline = [device newComputePipelineStateWithFunction:
          [library newFunctionWithName:@"coop_input_geometry"] error:&error];
      if (!pipeline) throw std::runtime_error(error.localizedDescription.UTF8String);
      constexpr uint64_t bytes = 3 * 16384 * sizeof(uint32_t);
      id<MTLBuffer> output = [device newBufferWithLength:bytes + 256 options:MTLResourceStorageModeShared];
      std::memset(output.contents, 0, bytes);
      std::memset(static_cast<char *>(output.contents) + bytes, 0xa5, 256);
      id<MTLCommandQueue> queue = [device newCommandQueue];
      id<MTLCommandBuffer> command = [queue commandBuffer];
      id<MTLComputeCommandEncoder> encoder = [command computeCommandEncoder];
      [encoder setComputePipelineState:pipeline];
      [encoder setBuffer:output offset:0 atIndex:0];
      [encoder dispatchThreadgroups:MTLSizeMake(1, 1, 1) threadsPerThreadgroup:MTLSizeMake(32, 1, 1)];
      [encoder endEncoding]; [command commit]; [command waitUntilCompleted];
      if (command.status != MTLCommandBufferStatusCompleted)
        throw std::runtime_error(command.error.localizedDescription.UTF8String);
      const auto *guard = static_cast<unsigned char *>(output.contents) + bytes;
      for (uint32_t i = 0; i < 256; ++i)
        if (guard[i] != 0xa5) throw std::runtime_error("probe output guard overwritten");
      std::ofstream out(argv[2], std::ios::binary);
      out.write(static_cast<const char *>(output.contents), bytes);
      if (!out) throw std::runtime_error("cannot write probe output");
      const auto *values = static_cast<const uint32_t *>(output.contents);
      for (uint32_t i = 0; i < 3; ++i) {
        const auto *p = values + i * 16384;
        std::cout << "{\"rows\":" << p[0] << ",\"right_capacity_per_thread\":" << p[1]
                  << ",\"destination_capacity_per_thread\":" << p[2] << "}\n";
      }
    } catch (const std::exception &e) { std::cerr << e.what() << '\n'; return 1; }
  }
}

"""Validate peripheral CLI/app integration without changing frozen inference evidence."""

from pathlib import Path
import datetime as dt
import hashlib
import json

root = Path(__file__).resolve().parents[1]
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
required = ['final-app-tests-v3', 'final-cli-option-scope-v1']
receipts = {}
for ident in required:
    path = root / 'results' / (ident + '.receipt.json')
    receipt = json.loads(path.read_text())
    assert receipt['state'] == 'complete' and receipt['exit_code'] == 0, ident
    assert receipt['artifact_sha256'] == receipt['artifact_sha256_after'], ident
    receipts[ident] = {'sha256': sha(path), 'elapsed_seconds': receipt['elapsed_seconds']}
witness_path = root / 'notes/integration-source-witness-v3.json'
witness = json.loads(witness_path.read_text())
build_path = root / 'artifacts/production-final-v1/build.json'
build = json.loads(build_path.read_text())
for name, expected in build['source_manifest'].items():
    assert sha(root / 'production-final-v1' / name) == expected, name
    integrated = witness['allowed_differences'].get(name, {}).get('integrated', expected)
    assert sha(root / 'geometry' / name) == integrated, 'integration: ' + name
for name in ['splash', 'splash.metallib', 'host-step.metallib']:
    assert sha(root / 'artifacts/production-final-v1' / name) == build['artifacts'][name], name
record = {'validated_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
          'integration_commit': witness['integration_commit'],
          'receipts': receipts, 'source_witness_sha256': sha(witness_path),
          'original_native_nomination_sha256': sha(root / 'notes/production-final-v1-nomination.json'),
          'original_23_gate_validation_sha256': sha(root / 'results/final-validation-v1.json'),
          'frozen_runtime_source_and_artifacts_unchanged': True,
          'allowed_peripheral_files': sorted(witness['allowed_differences']),
          'scope': 'Final app offers no sixteen-row setting without a custom drafter selector; the per-model CLI/server flag remains. Revalidated full Swift suite and the affected Python option-table contract only, between complete comparisons. No inference/kernel/server implementation or timing artifact changed; original source choice/nomination and all benchmark records remain immutable.'}
path = root / 'results/final-integration-v3-validation.json'
assert not path.exists()
path.write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({'validated': True, 'integration_commit': witness['integration_commit'], 'new_gates': len(required)}))

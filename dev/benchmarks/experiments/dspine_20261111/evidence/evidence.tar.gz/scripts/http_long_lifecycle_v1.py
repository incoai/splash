"""Loopback-only long context, prefix/suffix reuse and clean disk-restart check."""
from pathlib import Path
import contextlib, hashlib, json, os, signal, subprocess, sys, time
tree=Path(__file__).resolve().parents[1]/'runtime16-v10'
sys.path.insert(0, str(tree))
from dev.tests import smoke_real as smoke
r=Path(__file__).resolve().parents[1]
ident,binary=sys.argv[1:];directory=r/'http'/ident;directory.mkdir(parents=True,exist_ok=False)
model_root=Path('/Users/linson/Documents/ai/splash/build/dspine/model-root.txt').read_text().strip()
cache=directory/'cache';model='local/dspine-lifecycle'
record={'id':ident,'binary':binary,'shader_validation':os.environ.get('MTL_SHADER_VALIDATION'),'checks':[],'server_runs':[]}
def save():
 p=directory/'result.json.tmp';p.write_text(json.dumps(record,indent=2)+'\n');p.replace(directory/'result.json')
@contextlib.contextmanager
def serving(name):
 port=smoke.available_port();command=[sys.executable,'-m','server.server',model_root,'--binary',binary,'--model',model,'--host','127.0.0.1','--port',str(port),'--max-context','32768','--kv-format','int8','--state-format','fp32','--disable-ane','--verify-rows','all','--draft-block-size','16','--persistent-cache','--cache-dir',str(cache),'--max-cache-disk','4G']
 run={'name':name,'command':command};record['server_runs'].append(run);save()
 with (directory/(name+'.server.log')).open('w') as log:
  process=subprocess.Popen(command,cwd=tree,stdout=log,stderr=subprocess.STDOUT)
  try:
   deadline=time.monotonic()+300
   while time.monotonic()<deadline:
    smoke.require(process.poll() is None,'server exited during startup')
    try:
     code,status=smoke.request(port,'GET','/status',timeout=1)
     if code==200 and status.get('ready'):break
    except (OSError,smoke.SmokeFailure):pass
    time.sleep(.25)
   else:raise RuntimeError('startup timeout')
   smoke.validate_status(status,'int8');smoke.require(status.get('draft_block_size')==16,'not sixteen rows');run['status_start']=status;save();yield port,status
   run['status_end']=smoke.runtime_status(port);smoke.validate_status(run['status_end'],'int8');save()
  finally:
   if process.poll() is None:process.send_signal(signal.SIGINT)
   try:process.wait(timeout=45)
   except subprocess.TimeoutExpired:
    process.terminate()
    try:process.wait(timeout=10)
    except subprocess.TimeoutExpired:process.kill();process.wait(timeout=10)
   run['exit_code']=process.returncode;save();smoke.require(process.returncode==0,'server did not stop cleanly')
 smoke.require_closed_cache(cache)
def complete(port,name,body):
 began=time.monotonic();code,answer=smoke.request(port,'POST','/v1/chat/completions',body,timeout=600)
 smoke.require(code==200,f'{name}: HTTP{code}: {answer}')
 content=answer['choices'][0]['message']['content'];smoke.require(bool(content),name+': empty output')
 (directory/(name+'.json')).write_text(json.dumps(answer,indent=2)+'\n')
 summary={'name':name,'usage':answer['usage'],'cache':answer['metrics']['cache'],'speculation':answer['metrics']['speculation'],'output_sha256':hashlib.sha256(content.encode()).hexdigest(),'client_seconds':time.monotonic()-began}
 record['checks'].append(summary);save();print(json.dumps(summary),flush=True);return answer,summary
prompt=smoke.filler('dspine20261110','long-lifecycle',500)+'\nUsing the appendix as irrelevant background, write an iterative Python function that checks if a number is prime. Return only code.'
body=smoke.chat_body(model,prompt,max_completion_tokens=96,seed=20261110,cache_salt=ident+'-lineage')
with serving('initial') as (port,status):
 cold,cold_summary=complete(port,'long-cold',body);n=cold['usage']['prompt_tokens'];record['long_prompt_tokens']=n
 smoke.require(12000<=n<24000,'long prompt did not cross8192draftwindow within32Kcontext')
 smoke.require(cold['usage']['prompt_tokens_details']['cached_tokens']==0,'cold prompt unexpectedly reused cache')
 warm,warm_summary=complete(port,'long-warm',body)
 smoke.require(warm['usage']['prompt_tokens_details']['cached_tokens']>=n*.9,'warm prompt reused less than90percent')
 smoke.require(cold_summary['output_sha256']==warm_summary['output_sha256'],'warm output differs from cold')
 suffix=json.loads(json.dumps(body));suffix['messages'][0]['content']+='\nInclude a short docstring.'
 suffix_answer,suffix_summary=complete(port,'long-suffix',suffix)
 smoke.require(suffix_answer['usage']['prompt_tokens_details']['cached_tokens']>=n*.9,'suffix reused less than90percent')
 disk_before=smoke.runtime_status(port)['disk']['write_behind'];record['before_restart_write_behind']=disk_before
 smoke.require(disk_before['waiting']+disk_before['durable']>=1,'no restore point before clean stop')
with serving('restarted') as (port,status):
 record['taken_back']=status['disk']['taken_back'];smoke.require(record['taken_back']['states']>=1 and record['taken_back']['kv_blocks']>=1,'restart took back no state orKV')
 before=smoke.runtime_status(port)
 restored,restored_summary=complete(port,'long-disk-restore',suffix)
 after=smoke.runtime_status(port)
 record['disk_state_hits']=after['state']['disk_hits']-before['state']['disk_hits']
 record['disk_kv_hit_tokens']=after['cache']['kv_disk_hit_tokens']-before['cache']['kv_disk_hit_tokens']
 smoke.require(record['disk_state_hits']>=1,'no state restored from disk')
 smoke.require(record['disk_kv_hit_tokens']>=n*.9,'disk restored less than90percent oflongKV')
 smoke.require(restored_summary['output_sha256']==suffix_summary['output_sha256'],'disk-restored output differs from original suffix output')
record['passed']=True;save();print('Long context/prefix/suffix/disk lifecycle passed',flush=True)

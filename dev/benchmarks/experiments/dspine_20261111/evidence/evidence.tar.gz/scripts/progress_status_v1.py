"""Read current job and ordinal progress; omit outputs and timing measurements."""

from pathlib import Path
import datetime as dt
import json

root = Path(__file__).resolve().parents[1]
current = json.loads((root / 'current.json').read_text())
record = {'utc': dt.datetime.now(dt.timezone.utc).isoformat(), 'job': current['id']}
command = current.get('job', {}).get('command', [])
if '--cohort' in command and '--samples' in command:
    path = Path(command[command.index('--cohort') + 1])
    names = [line.split(maxsplit=1)[0] for line in path.read_text().splitlines()]
    record['registered_requests'] = len(names) * int(command[command.index('--samples') + 1])
    lanes = int(command[command.index('--study-width') + 1]) if '--study-width' in command else 1
    progress = root / 'results' / (current['id'] + '.progress.jsonl')
    if progress.exists():
        with progress.open('rb') as stream:
            if lanes == 1:
                stream.seek(max(0, progress.stat().st_size - 16384))
            lines = stream.read().splitlines()
        completed_clones = 0
        for raw in reversed(lines):
            try:
                value = json.loads(raw)
            except ValueError:
                continue
            if value.get('event') != 'complete':
                continue
            if lanes > 1 and value.get('kind') == 'decode_throughput':
                completed_clones += 1
            if lanes == 1 and value.get('kind') == 'request' and value.get('scenario') in names:
                record['completed_requests'] = value['sample'] * len(names) + names.index(value['scenario']) + 1
                break
        if lanes > 1:
            record['physical_lanes'] = lanes
            record['completed_requests'] = completed_clones
print(json.dumps(record))

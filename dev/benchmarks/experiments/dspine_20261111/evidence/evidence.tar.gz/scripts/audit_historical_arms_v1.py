"""Compare all retained greedy outputs across the historical serial arms."""

import hashlib
import json
from collections import defaultdict
from pathlib import Path

root = Path(__file__).resolve().parents[1]
results = root / "results"
cases = defaultdict(lambda: defaultdict(list))
rounds = []
comparisons = {
    "dspine16-final-v1": "committed_dspine8",
    "dflash8-vs-dspine16-final-v1": "final_dflash2",
}
expected_counts = {
    "committed_dspine8": 12,
    "final_dflash2": 12,
    "final_dspine16": 24,
}
for label, control in comparisons.items():
    verdict = json.loads((results / (label + ".comparison.json")).read_text())
    assert len(verdict["groups"]) == 3
    for group in verdict["groups"]:
        assert len(group["sources"]) == 4
        for source in group["sources"]:
            ident = source["job"]
            arm = control if ident.endswith(("a1", "a2")) else "final_dspine16"
            raw = (results / (ident + ".stdout")).read_bytes()
            assert hashlib.sha256(raw).hexdigest() == source["sha256"]
            document = json.loads(raw)
            assert len(document["measurements"]) == 62
            for request in document["measurements"]:
                tokens = request["output_tokens"]
                encoded = json.dumps(tokens, separators=(",", ":")).encode()
                cases[request["scenario"]][arm].append(
                    hashlib.sha256(encoded).hexdigest()
                )
            rounds.append({"job": ident, "arm": arm, "stdout_sha256": source["sha256"]})

assert len(cases) == 31
rows = []
for name, arms in sorted(cases.items()):
    assert {arm: len(hashes) for arm, hashes in arms.items()} == expected_counts
    hashes = {arm: sorted(set(values)) for arm, values in sorted(arms.items())}
    rows.append(
        {
            "case": name,
            "arrays_per_arm": expected_counts,
            "unique_output_sha256_per_arm": hashes,
            "eight_row_outputs_match": hashes["committed_dspine8"]
            == hashes["final_dflash2"],
            "all_three_outputs_match": len(
                {v for values in hashes.values() for v in values}
            )
            == 1,
        }
    )
report = {
    "rounds": rounds,
    "cases": rows,
    "arrays_audited": len(cases) * sum(expected_counts.values()),
    "within_arm_all_repetitions_match": all(
        len(hashes) == 1
        for row in rows
        for hashes in row["unique_output_sha256_per_arm"].values()
    ),
    "cases_where_both_eight_row_outputs_match": sum(
        row["eight_row_outputs_match"] for row in rows
    ),
    "cases_where_all_three_outputs_match": sum(
        row["all_three_outputs_match"] for row in rows
    ),
    "scope": (
        "Post-hoc descriptive comparison of all 24 retained serial rounds and both internal "
        "repetitions from the two historical protocols. Source revisions, drafters and "
        "widths differ across arms. Original qualification verdicts are retained."
    ),
}
with (results / "historical-greedy-arms-v1.json").open("x") as output:
    json.dump(report, output, indent=2)
    output.write("\n")
print(json.dumps({k: v for k, v in report.items() if k not in {"rounds", "cases"}}))

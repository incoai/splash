#pragma once

#include "model/DFlashDraft.hpp"
#include <algorithm>
#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <set>
#include <stdexcept>

namespace splash::model {

// Research-only host copies. This executable is never a timing artifact.
inline void captureRefinementResearch(metal::CommandGraph &graph,
    const DFlashDraftWeights &weights, const ops::DSpineBuffers &bridge,
    const ops::DraftSelectorBuffers &selection, std::span<const uint32_t> anchors,
    std::span<const ops::SamplingPolicy> policies, ops::DecodeGeometry geometry) {
  static bool claimed = false;
  const char *destination = std::getenv("DSPINE_REFINEMENT_CAPTURE");
  if (!destination || claimed || anchors.size() != 1 || policies[0].temperature != 1.0f)
    return;
  claimed = true;
  const auto out = std::filesystem::path(destination);
  const auto anchor = anchors.front();
  const auto shape = weights.layout;
  graph.host([out, anchor, shape, geometry, bridge, selection, &weights] {
    if (!std::filesystem::create_directories(out))
      throw std::runtime_error("refinement capture destination already exists");
    const auto write = [&](const std::string &name, const void *data, uint64_t bytes) {
      if (!data || !bytes) throw std::runtime_error("unreadable research capture: " + name);
      std::ofstream file(out / name, std::ios::binary);
      file.write(static_cast<const char *>(data), static_cast<std::streamsize>(bytes));
      if (!file) throw std::runtime_error("research capture write failed: " + name);
    };
    const auto buffer = [&](const std::string &name, const metal::MetalBuffer &b, uint64_t bytes) {
      if (bytes > b.sizeBytes()) throw std::runtime_error("research capture exceeds buffer: " + name);
      write(name, b.contents(), bytes);
    };
    const uint64_t rows = geometry.rows(), positions = geometry.proposals();
    const uint64_t hidden = shape.hiddenSize, code = shape.bridgeCodeSize, rank = shape.bridgeRank;
    buffer("raw.bf16", bridge.raw, rows * hidden * 2);
    buffer("rms.f32", bridge.rms, rows * 4);
    buffer("packed.bf16", bridge.packed, rows * 3 * rank * 2);
    buffer("candidate-head.bf16", bridge.candidateHead, positions * SPLASH_DRAFT_CANDIDATES * hidden * 2);
    buffer("candidates.u32", selection.candidates, positions * SPLASH_DRAFT_CANDIDATES * 4);
    buffer("proposed.u32", selection.proposedTokens, positions * 4);
    buffer("probabilities.f32", selection.proposalProbabilities, positions * SPLASH_DRAFT_CANDIDATES * 4);
    buffer("confidence.f32", selection.confidence, positions * 4);
    buffer("uniforms.f32", selection.uniforms, geometry.uniformCount() * 4);
    buffer("gate-bias.bf16", weights.bridge.gateBias, rank * 2);
    buffer("predecessor-gate.bf16", weights.bridge.predecessorGate, rank * code * 2);
    buffer("previous.bf16", weights.bridge.previous, rank * code * 2);
    buffer("write.bf16", weights.bridge.write.back().blocks().segments.front().plane0, hidden * rank * 2);
    buffer("norm.bf16", weights.finalNorm.buffer, hidden * 2);
    const auto *candidates = static_cast<const uint32_t *>(selection.candidates.contents());
    std::set<uint32_t> unique{anchor};
    unique.insert(candidates, candidates + positions * SPLASH_DRAFT_CANDIDATES);
    const std::vector<uint32_t> ids(unique.begin(), unique.end());
    write("codebook-ids.u32", ids.data(), ids.size() * 4);
    const auto *book = static_cast<const uint16_t *>(weights.bridge.codebook.contents());
    if (!book) throw std::runtime_error("codebook is not readable");
    std::vector<uint16_t> selected;
    for (uint32_t id : ids) {
      if (id >= shape.vocabularySize) throw std::runtime_error("capture candidate exceeds vocabulary");
      selected.insert(selected.end(), book + uint64_t{id} * code, book + uint64_t{id + 1} * code);
    }
    write("codebook.bf16", selected.data(), selected.size() * 2);
    std::ofstream meta(out / "capture.json");
    meta << "{\"rows\":" << rows << ",\"hidden\":" << hidden << ",\"code\":" << code
         << ",\"rank\":" << rank << ",\"anchor\":" << anchor
         << ",\"temperature\":1,\"top_k_proposal\":16,\"top_p_proposal\":1,\"codebook_rows\":"
         << ids.size() << ",\"scope\":\"Exact-sender conditional proposal arithmetic given identical captured final-layer stash, support, BF16 bridge weights and dequantized candidate head rows; excludes target and draft backbone drift.\"}\n";
    if (!meta) throw std::runtime_error("capture metadata write failed");
  });
}

} // namespace splash::model

"""Compare archived reports against portable reanalysis of their evidence."""

import argparse
import hashlib
import json
import math
import re
import subprocess
import sys
import tempfile
from pathlib import Path

missing_result = re.compile(r"(?<=No such file or directory: ')/[^']+/results/")
top_token_text = re.compile(r"/[ab]_top2/[01]/1$")


def compare_reports(actual, expected, action):
    numeric_differences = []
    relocated_diagnostics = []
    unavailable_token_text = []

    def compare(left, right, field=""):
        if isinstance(left, bool) or isinstance(right, bool):
            assert type(left) is type(right) and left == right, field
        elif isinstance(left, float) and isinstance(right, float):
            assert math.isclose(left, right, rel_tol=1e-12, abs_tol=1e-12), (
                field,
                left,
                right,
            )
            if left != right:
                numeric_differences.append(abs(left - right))
        elif isinstance(left, dict) and isinstance(right, dict):
            assert left.keys() == right.keys(), field
            for key in left:
                compare(left[key], right[key], f"{field}/{key}")
        elif isinstance(left, list) and isinstance(right, list):
            assert len(left) == len(right), field
            for index, (a, b) in enumerate(zip(left, right)):
                compare(a, b, f"{field}/{index}")
        elif (
            ("/problems/" in field or field.startswith("/errors/"))
            and isinstance(left, str)
            and isinstance(right, str)
            and left != right
        ):
            a = missing_result.sub("results/", left)
            b = missing_result.sub("results/", right)
            assert a == b and a != left and b != right, (field, left, right)
            relocated_diagnostics.append(field)
        elif (
            action == "prefix"
            and left is None
            and isinstance(right, str)
            and top_token_text.search(field)
        ):
            unavailable_token_text.append(field)
        else:
            assert type(left) is type(right) and left == right, (field, left, right)

    compare(actual, expected)
    return {
        "all_verdicts_and_identities_match": True,
        "numeric_fields_with_rounding_difference": len(numeric_differences),
        "maximum_absolute_numeric_delta": max(numeric_differences, default=0),
        "relocated_missing_result_paths": relocated_diagnostics,
        "unavailable_optional_token_text_fields": unavailable_token_text,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--evidence", type=Path, required=True)
    parser.add_argument("--tool", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    records = []
    with tempfile.TemporaryDirectory(prefix="dspine-portable-check-") as temporary:

        def check(path, action, extra):
            target = Path(temporary) / path.name
            command = [
                sys.executable,
                str(args.tool),
                action,
                "--evidence",
                str(args.evidence),
                "--output",
                str(target),
                *extra,
            ]
            process = subprocess.run(
                command, check=True, capture_output=True, text=True
            )
            actual = json.loads(target.read_text())
            expected = json.loads(path.read_text())
            records.append(
                {
                    "report": path.name,
                    "action": action,
                    "qualified": actual.get("qualified"),
                    "status": actual.get("status"),
                    **compare_reports(actual, expected, action),
                    "recorded_stdout_sha256": hashlib.sha256(
                        process.stdout.encode()
                    ).hexdigest(),
                }
            )

        for path in sorted((args.evidence / "results").glob("*.comparison.json")):
            label = path.name.removesuffix(".comparison.json")
            protocol_path = args.evidence / "notes" / (label + ".protocol.json")
            if protocol_path.exists():
                protocol = json.loads(protocol_path.read_text())
                if {"groups", "prefix", "analyzer_sha256"}.issubset(protocol):
                    check(path, "analyze", ["--comparison", label])

        for action, filename in [
            ("sampling", "sampling4-comparison-v1.json"),
            ("prefix", "prefix-numerics-v2.json"),
            ("refinement", "refinement-saved-check-v1.json"),
        ]:
            path = args.evidence / "results" / filename
            if path.exists():
                check(path, action, [])

    assert records
    record = {
        "python": sys.version,
        "tool_sha256": hashlib.sha256(args.tool.read_bytes()).hexdigest(),
        "reports": records,
        "numeric_comparison": (
            "Relative and absolute tolerance 1e-12 for report rounding only. "
            "Boolean verdicts, identities, token IDs and array hashes are exact."
        ),
        "scope": (
            "Offline reanalysis from extracted evidence. The evidence root can "
            "change in missing-file diagnostics. Decoded token strings are "
            "optional in the prefix report."
        ),
    }
    with args.output.open("x") as output:
        json.dump(record, output, indent=2)
        output.write("\n")
    print(json.dumps(record, indent=2))


if __name__ == "__main__":
    main()

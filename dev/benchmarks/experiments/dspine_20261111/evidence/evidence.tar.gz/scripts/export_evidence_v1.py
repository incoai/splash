"""Archive original owned evidence bytes; exclude weights, binaries and caches."""
from pathlib import Path
import argparse
import datetime as dt
import gzip
import hashlib
import io
import json
import tarfile

root = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser()
parser.add_argument('kind', choices=['small', 'logits', 'hardware'])
parser.add_argument('--output', type=Path, required=True)
parser.add_argument('--manifest', type=Path, required=True)
args = parser.parse_args()
session = json.loads((root / 'session.json').read_text())
assert dt.datetime.now(dt.timezone.utc) >= dt.datetime.fromisoformat(session['deadline_utc'])
assert (root / 'runner-stopped.json').exists(), 'owned runner has not stopped'
assert not args.output.exists() and not args.manifest.exists()


def candidates():
    if args.kind == 'hardware':
        return [root / 'results/hardware.jsonl']
    if args.kind == 'logits':
        return sorted(p for p in (root / 'logit-probes').rglob('*') if p.is_file())
    files = []
    for name in ['results', 'notes', 'scripts', 'cohorts', 'patches', 'logs']:
        files += [p for p in (root / name).rglob('*') if p.is_file()
                  and '__pycache__' not in p.parts and p.suffix not in ['.pyc', '.tmp']
                  and p.name != 'hardware.jsonl']
    files += [root / name for name in ['session.json', 'queue.jsonl', 'runner-stopped.json']]
    for name in ['artifacts', 'http', 'refinement-probes', 'logit-probes']:
        directory = root / name
        if not directory.exists():
            continue
        for p in directory.rglob('*'):
            if not p.is_file() or 'cache' in p.relative_to(directory).parts:
                continue
            if name == 'artifacts' and p.name == 'build.json':
                files.append(p)
            if name == 'http' and p.suffix in ['.json', '.jsonl', '.log', '.stderr']:
                files.append(p)
            if (name in ['refinement-probes', 'logit-probes'] and p.suffix in ['.json', '.jsonl']) or (name == 'refinement-probes' and p.name in ['candidates.u32', 'probabilities.f32', 'proposed.u32', 'uniforms.f32']):
                files.append(p)
    files += sorted((root / 'references').glob('github-state-*.json'))
    return sorted(set(files))


def contents(path):
    before = path.stat()
    data = path.read_bytes()
    after = path.stat()
    assert before.st_size == after.st_size == len(data)
    assert before.st_mtime_ns == after.st_mtime_ns, 'evidence changed: ' + str(path)
    return data


files = candidates()
assert files
entries = {}
args.output.parent.mkdir(parents=True, exist_ok=True)
with args.output.open('xb') as raw:
    with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0, compresslevel=6) as compressed:
        if args.kind == 'hardware':
            data = contents(files[0])
            compressed.write(data)
            entries[files[0].relative_to(root).as_posix()] = {
                'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
        else:
            with tarfile.open(fileobj=compressed, mode='w', format=tarfile.PAX_FORMAT) as archive:
                for path in files:
                    relative = path.relative_to(root).as_posix()
                    data = contents(path)
                    info = tarfile.TarInfo(relative)
                    info.size = len(data)
                    info.mode = 0o644
                    info.mtime = 0
                    info.uid = info.gid = 0
                    info.uname = info.gname = ''
                    archive.addfile(info, io.BytesIO(data))
                    entries[relative] = {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
record = {'kind': args.kind, 'created_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
    'archive': args.output.name, 'archive_bytes': args.output.stat().st_size,
    'archive_sha256': hashlib.sha256(args.output.read_bytes()).hexdigest(),
    'files': entries,
    'scope': 'Original bytes and relative layout. Absolute provenance keys inside receipts are unchanged. No compiled artifacts, model weights, physical HTTP cache payloads or Apple documents. The logit archive contains derived pre-policy outputs; the hardware archive contains raw telemetry.'}
args.manifest.write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({k: v for k, v in record.items() if k != 'files'}, indent=2))

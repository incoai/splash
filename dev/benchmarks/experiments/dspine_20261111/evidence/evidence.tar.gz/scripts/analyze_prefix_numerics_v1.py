"""Compare actual pre-policy rows only while their conditional prefixes match."""
from pathlib import Path
import hashlib
import json
import numpy as np
from tokenizers import Tokenizer

root = Path(__file__).resolve().parents[1]
model = Path('/Users/linson/Documents/ai/splash/build/dspine/model-root.txt').read_text().strip()
tokenizer = Tokenizer.from_file(model + '/tokenizer/tokenizer.json')


def load(ident):
    receipt = json.loads((root / 'results' / f'{ident}.receipt.json').read_text())
    assert receipt['state'] == 'complete' and receipt['exit_code'] == 0, 'row mapping/capture did not validate'
    doc = json.loads((root / 'results' / f'{ident}.stdout').read_text())
    values = {m['scenario'].removeprefix('runtime_cache_'): m['output_tokens'] for m in doc['measurements']}
    captures = {}
    for phase in ['cold', 'hit']:
        base = root / 'logit-probes' / ident / f'runtime_cache_{phase}-s0'
        captures[phase] = {}
        for line in base.with_suffix('.jsonl').read_text().splitlines():
            row = json.loads(line)
            if row['binary_offset'] is None:
                continue
            array = np.fromfile(base.with_suffix('.f32'), dtype='<f4', count=row['vocabulary'], offset=row['binary_offset'])
            assert len(array) == row['vocabulary'] and np.isfinite(array).all()
            assert int(np.argmax(array)) == values[phase][row['prediction_index']], 'captured argmax differs'
            captures[phase][row['prediction_index']] = array
    return values, captures


def compare_rows(a, b):
    a, b = a.astype(np.float64), b.astype(np.float64)
    delta = b - a
    ea = np.exp(a - a.max()); eb = np.exp(b - b.max())
    loga = a - a.max() - np.log(ea.sum()); logb = b - b.max() - np.log(eb.sum())
    pa = np.exp(loga); pb = np.exp(logb)
    sa = np.argsort(a)[-2:][::-1]; sb = np.argsort(b)[-2:][::-1]
    return {'raw_rms_delta': float(np.sqrt(np.mean(delta**2))),
            'mean_delta': float(delta.mean()), 'maximum_absolute_delta': float(np.abs(delta).max()),
            'centered_relative_rms_delta': float(np.sqrt(np.mean((delta - delta.mean())**2)) / np.std(a)),
            'temperature1_full_vocab_total_variation': float(np.abs(pa - pb).sum() / 2),
            'temperature1_full_vocab_kl_a_to_b': float(np.sum(pa * (loga - logb))),
            'a_top2': [[int(i), tokenizer.decode([int(i)]), float(a[i])] for i in sa],
            'b_top2': [[int(i), tokenizer.decode([int(i)]), float(b[i])] for i in sb],
            'a_top2_margin': float(a[sa[0]] - a[sa[1]]),
            'b_top2_margin': float(b[sb[0]] - b[sb[1]])}


records = {}
loaded = {}
for ident in ['prefix-logit-probe-control8-v2', 'prefix-logit-probe-core8-v2',
              'prefix-logit-probe-core16-v2', 'prefix-logit-probe-dflash8-v2',
              'aligned-prefix-logit-probe-control8-v2', 'aligned-prefix-logit-probe-core16-v2']:
    outputs, captures = load(ident)
    loaded[ident] = outputs, captures
    first = next((i for i, (a, b) in enumerate(zip(outputs['cold'], outputs['hit'])) if a != b), None)
    if first is None and len(outputs['cold']) != len(outputs['hit']):
        first = min(len(outputs['cold']), len(outputs['hit']))
    common = sorted(captures['cold'].keys() & captures['hit'].keys())
    valid = [i for i in common if first is None or i <= first]
    records[ident] = {'cold_hit_arrays_match': outputs['cold'] == outputs['hit'],
                      'first_different_output_index': first,
                      'positions_with_matching_conditional_prefix': valid,
                      'rows': {str(i): compare_rows(captures['cold'][i], captures['hit'][i]) for i in valid}}

control_outputs, control = loaded['prefix-logit-probe-control8-v2']
new_outputs, new = loaded['prefix-logit-probe-core8-v2']
preservation = {}
for phase in ['cold', 'hit']:
    same = control_outputs[phase] == new_outputs[phase]
    assert same, 'default-width source arrays differ'
    indices = sorted(control[phase].keys() & new[phase].keys())
    preservation[phase] = {'arrays_match': same, 'rows_compared': indices,
                           'all_selected_full_vocabulary_rows_bitwise_match': all(
                               np.array_equal(control[phase][i], new[phase][i]) for i in indices)}
result = {'scope': 'One historical8193-token prompt, greedy64outputs, actual pre-policy target rows; every captured argmax mapping validated against returned tokens. Differences are compared only before/at the first token divergence, while conditioning is identical. This is not a quality or distribution-equivalence proof.',
          'default8_source_preservation': preservation, 'runs': records,
          'interpretation_rule': 'A flipped near tie plus different prefill partitions is consistent with chunk-dependent floating-point rounding. It does not identify a particular operator or prove all cache behavior correct. Aligned seeding is an additional diagnostic and never replaces the retained fixed64-suffix failure.'}
(root / 'results/prefix-numerics-v1.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'default8_source_preservation': preservation,
                  'runs': {k: {a: b for a, b in v.items() if a != 'rows'} for k, v in records.items()},
                  'baseline_divergence_row': records['prefix-logit-probe-control8-v2']['rows'].get('34')}, indent=2))

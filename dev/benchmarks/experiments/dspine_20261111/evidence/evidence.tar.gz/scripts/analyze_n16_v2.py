"""Evaluate the predeclared N16 operator screen without selecting cases."""
from collections import defaultdict
from pathlib import Path
import hashlib
import json

root = Path(__file__).resolve().parents[1]


def read(ident):
    receipt_path = root / 'results' / f'{ident}.receipt.json'
    receipt = json.loads(receipt_path.read_text())
    assert receipt['exit_code'] == 0 and receipt['state'] == 'complete'
    assert receipt['artifact_sha256'] == receipt['artifact_sha256_after']
    path = root / 'results' / f'{ident}.stdout'
    return [json.loads(line) for line in path.read_text().splitlines()], {
        'job': ident,
        'stdout_sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
        'receipt_sha256': hashlib.sha256(receipt_path.read_bytes()).hexdigest(),
    }


oracle, oracle_source = read('af4-n16-oracle-v2')
numerical = [v for v in oracle if v.get('case_passed')]
assert len(numerical) == 12 and all(v['case_passed'] for v in numerical)
diagnostic, diagnostic_source = read('af4-n16-diagnostic-v2')
grouped = defaultdict(list)
for row in diagnostic:
    if 'gpu_ms_per_projection' in row:
        grouped[tuple(row[k] for k in ['rows', 'live_rows', 'splits', 'spread'])].append(row)
assert len(grouped) == 8
cases = []
for key, rows in grouped.items():
    assert [v['simdgroups'] for v in rows] == [0, 2, 2, 0]
    assert all(v['repeats'] == 50 for v in rows)
    control = (rows[0]['gpu_ms_per_projection'] + rows[3]['gpu_ms_per_projection']) / 2
    candidate = (rows[1]['gpu_ms_per_projection'] + rows[2]['gpu_ms_per_projection']) / 2
    cases.append(dict(zip(['rows', 'live_rows', 'splits', 'spread'], key),
                      control_ms=control, candidate_ms=candidate,
                      throughput_change=control / candidate - 1,
                      latency_change=candidate / control - 1))
primary = [v for v in cases if v['splits'] == 1 and v['spread']]
assert len(primary) == 2 and {v['live_rows'] for v in primary} == {48, 64}
resources, resources_source = read('af4-n16-resources-v1')
first = json.loads((root / 'results/af4-n16-diagnostic-v1.receipt.json').read_text())
result = {
    'scope': 'Balanced finite operator nomination screen on this M5 Pro, on battery. Not controlled whole-model throughput or a cross-device result.',
    'candidate': 'One SIMD group, sixteen output columns, paired gate/up staging; same AF4G64 half dequantization, K32 accumulation and partition count.',
    'legacy_raw_field': 'simdgroups is an arm selector: 0 means existing two-pass; 2 means the new one-SIMD-group N16 pair. It is not the number of SIMD groups.',
    'numerical': {
        'cases': len(numerical),
        'bitwise_comparisons': sum(v['bitwise_comparisons'] for v in numerical),
        'independent_fp64_checks': sum(v['independent_fp64_checks'] for v in numerical),
        'source': oracle_source,
    },
    'cases': cases,
    'primary_cases': primary,
    'nomination_rule': 'Both primary production shapes must gain at least 5% projection throughput, with all guarded bitwise/independent FP64 checks passing.',
    'nomination_rule_met': all(v['throughput_change'] >= .05 for v in primary),
    'production_nominated': False,
    'resources': resources,
    'sources': [diagnostic_source, resources_source],
    'fixture_failure_retained': {
        'job': first['id'], 'state': first['state'], 'exit_code': first['exit_code'],
        'cause': 'V1 balanced timing order began with the two-pass reference but reset stored outputs only on the one-pass arm. The next K split compared its baseline against stale outputs. V2 clears the reference at each split/spread pair; the shader library is unchanged. This was a fixture failure, not a demonstrated shader error.',
    },
    'interpretation': 'The N16 pair misses the prospective speed criterion. Lower static threadgroup storage does not establish better register occupancy or less spilling; neither was measured. Keep the existing two-pass production choice.',
}
assert not result['nomination_rule_met']
path = root / 'results/n16-operator-v2.json'
assert not path.exists()
path.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({k: result[k] for k in ['numerical', 'primary_cases', 'nomination_rule_met']}, indent=2))

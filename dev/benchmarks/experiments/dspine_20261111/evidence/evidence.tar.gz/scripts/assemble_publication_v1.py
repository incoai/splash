"""Assemble a repository-ready report from reviewed publications and evidence."""

import datetime as dt
import hashlib
import json
import shutil
from pathlib import Path

root = Path(__file__).resolve().parents[1]
publication = root / "publication"
session = json.loads((root / "session.json").read_text())
assert dt.datetime.now(dt.timezone.utc) >= dt.datetime.fromisoformat(
    session["deadline_utc"]
)
assert (root / "runner-stopped.json").exists()
report = publication / "final-report"
report.mkdir()


def copy(source, name):
    destination = report / name
    destination.parent.mkdir(parents=True, exist_ok=True)
    assert not destination.exists()
    shutil.copy2(source, destination)


for name in [
    "README.md",
    "MECHANISMS.md",
    "M48_NEXT.md",
    "reproduce.py",
    "plot_results.py",
    "requirements-analysis.txt",
]:
    copy(publication / name, name)
for name in ["figures", "results"]:
    for path in sorted((publication / name).iterdir()):
        assert path.is_file()
        copy(path, f"{name}/{path.name}")

for name in [
    "calibration-smoke3-v1.txt",
    "kernel-smoke3-cap256-v1.txt",
    "historical31-v1.txt",
    "agent12-v1.txt",
    "sampling4-v1.txt",
]:
    copy(root / "cohorts" / name, "cohorts/" + name)
for name in [
    "production-final-v1.patch",
    "m48-research-v1.patch",
    "m48-research-only-v1.patch",
    "final-integration-only-v3.patch",
]:
    copy(root / "patches" / name, "patches/" + name)
copy(root / "scripts/study_driver_v2.mm", "sources/study_driver_v2.mm")

overview_path = root / "results/final-overview-v1.json"
overview = json.loads(overview_path.read_text())
for row in overview["comparisons"]:
    name = row["label"] + ".comparison.json"
    copy(root / "results" / name, "results/" + name)
for name in [
    "final-overview-v1.json",
    "decode-work-v1.json",
    "final-validation-v1.json",
    "final-integration-v3-validation.json",
    "dspine16-output-divergence-v1.json",
    "historical-greedy-arms-v1.json",
    "historical-same-build-width-v1.json",
    "sampling-termination-v1.json",
    "prefix-numerics-v2.json",
    "refinement-saved-check-v1.json",
    "telemetry-final-v1.json",
    "wide-gateup-b3-v1.comparison.json",
    "wide-gateup-b4-v1.comparison.json",
]:
    copy(root / "results" / name, "results/" + name)
if overview["sampling"].get("analysis_sha256"):
    name = "sampling4-comparison-v1.json"
    copy(root / "results" / name, "results/" + name)
copy(publication / "portable-reanalysis-v1.json", "results/portable-reanalysis-v1.json")
copy(
    root / "notes/integration-source-witness-v3.json",
    "results/integration-source-witness-v3.json",
)

archives = {}
for kind in ["evidence", "hardware", "logits"]:
    name = kind + "-manifest.json"
    manifest_path = publication / "evidence" / name
    manifest = json.loads(manifest_path.read_text())
    copy(manifest_path, "evidence/" + name)
    archive = manifest["archive"]
    archives[kind] = {
        "archive": archive,
        "manifest": "evidence/" + name,
        "bytes": manifest["archive_bytes"],
        "sha256": manifest["archive_sha256"],
    }
    if kind == "logits":
        assert (publication / archive).stat().st_size == manifest["archive_bytes"]
        archives[kind]["release_url"] = (
            "https://github.com/linson007/splash/releases/download/dspine-13h-20261111-v1/"
            + archive
        )
    else:
        source = publication / "evidence" / archive
        assert source.stat().st_size == manifest["archive_bytes"] < 100 * 1024**2
        archives[kind]["archive"] = "evidence/" + archive
        copy(source, "evidence/" + archive)

report_path = "dev/benchmarks/experiments/dspine_20261111"
index = {
    "report": report_path + "/README.md",
    "mechanisms": report_path + "/MECHANISMS.md",
    "pull_request": "https://github.com/incoai/splash/pull/731",
    "baseline_commit": session["baseline_commit"],
    "timed_source_commit": "17a0ae2454ef567a599ccd64373d25fc7df9313b",
    "integration_commit": "fb429642850299f81def93e730b84131fb075cde",
    "research_window": overview["research_window"],
    "overview": report_path + "/results/final-overview-v1.json",
    "overview_sha256": hashlib.sha256(overview_path.read_bytes()).hexdigest(),
    "comparison_status": [
        {key: row[key] for key in ["label", "status", "successful_rounds", "qualified"]}
        for row in overview["comparisons"]
    ],
    "sampling": overview["sampling"],
    "archives_relative_to_report_directory": archives,
}
index_path = publication / "dspine-followup-qwen38-27b-2026-11-11.json"
with index_path.open("x") as output:
    json.dump(index, output, indent=2)
    output.write("\n")
print(report)
print(index_path)

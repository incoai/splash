"""Render the report and PR body from the retained verdicts."""

import json
from pathlib import Path

root = Path(__file__).resolve().parents[1]
publication = root / "publication"
release = "https://github.com/linson007/splash/releases/tag/dspine-13h-20261111-v1"
report = "https://github.com/linson007/splash/blob/experimental/dspine/dev/benchmarks/experiments/dspine_20261111/README.md"
previous = "https://github.com/linson007/splash/blob/425ad7400f3a00d2a1e6745bdacfa2881922d544/dev/benchmarks/experiments/dspine_20261110/README.md"


def load(path):
    return json.loads((root / path).read_text())


def percent_span(values):
    if not values:
        return ""
    low, high = min(values), max(values)
    if f"{low:+.2f}" == f"{high:+.2f}":
        return f"{low:+.2f}%"
    return f"{low:+.2f}% to {high:+.2f}%"


def endpoint_cell(row, name, endpoint):
    completed = endpoint["groups_with_endpoint"]
    if (
        completed == 0
        and name == "ttft"
        and row["label"]
        in {
            "dflash8-vs-dspine16-b4-final-v1",
            "m48-b3-research-v1",
        }
    ):
        return "—"
    if not row["retained_round_receipts"]:
        return "Unrun (0/12 rounds)"
    if row["status"] == "interrupted_or_unrun":
        return f"Incomplete ({row['successful_rounds']}/12 successful rounds)"
    if completed < 3:
        return f"Unqualified ({completed}/3 analyzed groups)"
    values = endpoint[
        "throughput_change_percent_by_group"
        if name == "decode"
        else "latency_change_percent_by_group"
    ]
    change = percent_span(values)
    if endpoint["reportable_effect"]:
        if row["label"] == "default8-final-v1":
            return f"Passed non-regression ({change})"
        return f"Qualified ({change})"
    return f"Unqualified ({change} observed)"


def decode_tps_cell(endpoint):
    if endpoint["groups_with_endpoint"] != 3:
        return "—"
    arms = []
    for name in ("control_time_by_group", "candidate_time_by_group"):
        rates = [1000 / value for value in endpoint[name]]
        low, high = f"{min(rates):.1f}", f"{max(rates):.1f}"
        arms.append(low if low == high else f"{low}–{high}")
    return " → ".join(arms)


overview = load("results/final-overview-v1.json")
telemetry = load("results/telemetry-final-v1.json")
rows = {row["label"]: row for row in overview["comparisons"]}
names = {
    "default8-final-v1": "Committed DSpine (8 rows) → final DSpine (8 rows), three historical cases",
    "dspine16-final-v1": "Committed DSpine (8 rows) → final DSpine (16 rows), 31 historical cases",
    "dflash8-vs-dspine16-final-v1": "DFlash2 → DSpine (16 rows), 31 historical cases",
    "dflash8-vs-dspine16-b4-final-v1": "DFlash2 → DSpine (16 rows), four cloned lanes",
    "agent12-dflash8-vs-dspine16-final-v1": "DFlash2 → DSpine (16 rows), 12 synthetic agent prompts",
    "m48-b3-research-v1": "M64 → M48, three cloned sixteen-row lanes",
}
endpoints = ["decode", "request_wall", "ttft"]
table = [
    "| Control → candidate | Decode tok/s | Decode change | Request-wall change | TTFT change | Verdict file |",
    "| --- | --- | --- | --- | --- | --- |",
]
pr_table = [
    "| Control → candidate | Decode tok/s | Decode change and verdict |",
    "| --- | --- | --- |",
]
for label, name in names.items():
    row = rows[label]
    cells = [
        endpoint_cell(row, endpoint, row["endpoints"][endpoint])
        for endpoint in endpoints
    ]
    tps = decode_tps_cell(row["endpoints"]["decode"])
    table.append(
        f"| {name} | {tps} | {' | '.join(cells)} | [JSON](results/{label}.comparison.json) |"
    )
    pr_table.append(f"| {name} | {tps} | {cells[0]} |")

details = [
    "Decode rates show the control and candidate ranges across the three groups, "
    "aggregating tokens across lanes in the clone fixtures. Decode percentages "
    "measure candidate throughput relative to control. Request-wall and TTFT "
    "percentages measure elapsed time, so negative values indicate shorter waits.",
]
for label, name in names.items():
    data = load(f"results/{label}.comparison.json")
    if not rows[label]["retained_round_receipts"]:
        details.append(f"The protocol for {name} remained unrun at the research cutoff.")
        continue
    notes = []
    for group in data["groups"]:
        cases = group.get("cases", [])
        mismatches = sum(not case["output_arrays_match"] for case in cases)
        noisy = sum(case["decode_abba"]["noise"] > 0.05 for case in cases)
        findings = []
        if mismatches:
            findings.append(f"{mismatches} cases with differing complete output arrays")
        if noisy:
            findings.append(f"{noisy} cases above the 5% decode spread limit")
        if group["problems"]:
            findings.append(f"{len(group['problems'])} missing or failed round checks")
        if findings:
            notes.append(f"group {group['group']} had {' and '.join(findings)}")
    if notes:
        details.append(f"For {name}, " + ", ".join(notes) + ".")

agent = rows["agent12-dflash8-vs-dspine16-final-v1"]
categories = [
    "| Agent context | Decode TPS change | Request-wall change | TTFT change |",
    "| --- | --- | --- | --- |",
]
for category, title in [
    ("short", "Short"),
    ("medium", "Around 4K"),
    ("long", "Around 16K"),
]:
    cells = [
        endpoint_cell(agent, endpoint, agent["categories"][category][endpoint])
        for endpoint in endpoints
    ]
    categories.append(f"| {title} | {' | '.join(cells)} |")

sampling = overview["sampling"]
termination = sampling.get("termination_audit", {})
observed = sampling.get("tests_observed", 0)
reserved = sampling["family_size_reserved"]
if sampling["status"] == "complete":
    sampling_text = (
        f"The screen evaluated all {observed} reserved tests. "
        f"After pooling, {sampling['informative_tests']} had at least two bins. "
        f"Holm correction left {sampling['rejections']} rejections at family α = 0.05."
    )
else:
    sampling_text = (
        "The research cutoff interrupted the final control chunk. "
        f"The screen ended with {observed} of {reserved} reserved tests evaluated. "
        f"The remaining {reserved - observed} tests retain the prespecified p = 1 "
        "assignment for unobserved tests. The full screen is incomplete."
    )
    if sampling.get("request_completions_in_journals"):
        sampling_text += (
            f" Progress journals recorded {sampling['request_completions_in_journals']:,} "
            "completed requests across all started chunks."
        )
if termination:
    sampling_text += (
        f" The length audit covers {termination['requests_from_complete_chunks']:,} "
        f"requests from complete chunks. Of these, {termination['requests_below_cap']:,} "
        f"ended below the cap, including {termination['zero_output_requests']:,} "
        "with zero output tokens."
    )

divergence_path = root / "results/dspine16-output-divergence-v1.json"
historical = load("results/historical-greedy-arms-v1.json")
details.append(
    f"The serial audit covers {historical['arrays_audited']:,} complete arrays. "
    f"Committed eight-row DSpine and final DFlash2 match on "
    f"{historical['cases_where_both_eight_row_outputs_match']} of 31 prompts. "
    f"All three arms agree on {historical['cases_where_all_three_outputs_match']} prompts. "
    + (
        "Every arm reproduces its complete array on each repetition. "
        if historical["within_arm_all_repetitions_match"]
        else ""
    )
    + "[Three-arm audit](results/historical-greedy-arms-v1.json)"
)
width_witness = load("results/historical-same-build-width-v1.json")
details.append(
    "The final eight-row functional pass uses the same recorded driver, "
    "Metal library, DSpine layout, cohort and greedy settings as the timed "
    "sixteen-row arm. It matches the committed eight-row control on "
    f"{width_witness['functional_eight_matches_committed_count']} of 31 prompts "
    f"and differs from the final sixteen-row arm on "
    f"{width_witness['same_build_width_mismatches']}. This gives a same-build "
    "starting point for matched-prefix logit probes. "
    "[Same-build output comparison](results/historical-same-build-width-v1.json)"
)
if divergence_path.exists():
    divergence = json.loads(divergence_path.read_text())
    indices = [
        case["representative_first_difference"]["index_zero_based"]
        for case in divergence["cases"]
        if case["representative_first_difference"] is not None
    ]
    length_changes = [
        case["representative_lengths"]["candidate16"]
        - case["representative_lengths"]["control8"]
        for case in divergence["cases"]
    ]
    detail = "In the timed comparison with the committed eight-row source,"
    if indices:
        detail += f" first differences span indices {min(indices)}–{max(indices)} (zero-based)."
    if any(length_changes):
        detail += (
            f" Output lengths differ on {sum(delta != 0 for delta in length_changes)} "
            f"prompts, with {sum(length_changes):+d} tokens across one pass through the cohort."
        )
    details.append(
        detail + " [Output audit](results/dspine16-output-divergence-v1.json)"
    )

body = (publication / "README.draft.md").read_text()
table_text = "\n".join(table) + "\n\n" + "\n\n".join(details)
if agent["successful_rounds"]:
    table_text += "\n\n" + "\n".join(categories)
replacements = {
    "FINAL_COMPARISON_TABLE": table_text,
    "M48_WHOLE_MODEL_RESULT": (
        "The comparison with the corrected M64 path appears in the final "
        "comparisons table. [Whole-model verdict](results/m48-b3-research-v1.comparison.json)"
    ),
    "SAMPLING_RESULT": (
        sampling_text
        + (
            " [Sampling verdict](results/sampling4-comparison-v1.json)"
            if sampling.get("analysis_sha256")
            else ""
        )
        + (
            " [Output length audit](results/sampling-termination-v1.json)"
            if termination
            else ""
        )
    ),
    "FINAL_TELEMETRY": (
        f"The hardware trace contains {telemetry['samples']:,} samples through "
        f"`{telemetry['last_utc']}`, with a largest inter-sample gap of "
        f"{telemetry['maximum_sample_gap_seconds']:.3f} s. The final sample is "
        f"{telemetry['seconds_to_deadline_after_last_sample']:.3f} s before the deadline. "
        f"The trace records {len(telemetry['gaps_over_five_seconds'])} gaps over five seconds. "
        "[Coverage audit](results/telemetry-final-v1.json)"
    ),
    "EVIDENCE_LOCATION": (
        "The repository carries the protocols, arrays and source evidence in the evidence "
        "archive and the hardware trace in a separate gzip file. The release carries "
        "`logits.tar.gz` for the prefix reanalysis. "
        "[Evidence archive](evidence/evidence.tar.gz) "
        "[Hardware trace](evidence/hardware.jsonl.gz) "
        "[Release assets](" + release + ")"
    ),
}
for placeholder, text in replacements.items():
    marker = "<!-- " + placeholder + " -->"
    assert body.count(marker) == 1, placeholder
    body = body.replace(marker, text)
assert "<!--" not in body
(publication / "README.md").write_text(body)

work_rows = [
    "| Control → candidate | Complete groups | GPU time per batch | Emitted tokens per lane per batch | GPU token rate |",
    "| --- | ---: | ---: | ---: | ---: |",
]
work = load("results/decode-work-v1.json")
for comparison in work["comparisons"]:
    groups = [
        group["candidate_divided_by_control"]
        for group in comparison["groups"]
        if "candidate_divided_by_control" in group
    ]
    cells = []
    for key in (
        "gpu_ms_per_batch",
        "emitted_tokens_per_lane_batch",
        "gpu_emitted_tokens_per_second",
    ):
        values = [100 * (group[key] - 1) for group in groups]
        cells.append(percent_span(values) if values else "—")
    work_rows.append(
        f"| {names[comparison['label']]} | {len(groups)}/3 | {' | '.join(cells)} |"
    )
mechanisms = (publication / "MECHANISMS.draft.md").read_text()
assert mechanisms.count("<!-- DECODE_WORK_TABLE -->") == 1
mechanisms = mechanisms.replace(
    "<!-- DECODE_WORK_TABLE -->",
    "\n".join(work_rows),
)
(publication / "MECHANISMS.md").write_text(mechanisms)

pr_body = (
    """This adds native Metal support for Tencent's Qwen3.8-27B DSpine draft.
Use `--draft-model tencent/Qwen3.8-27B-DSpine-b16` to select it and
`--draft-block-size 16` to opt into the full trained block. Eight rows remain
the default execution width. The change carries geometry per model, corrects
eight-row Table16 packing and register dispatch, and isolates the sixteen-row
persistent state layout.

On the 20-core M5 Pro, choosing separate AF4 gate and up passes improved
three-lane sixteen-row decode by **73.9–75.5%** against the original sixteen-row
M64 policy. Explicit 32K context saves **95.24 MiB** of sixteen-row attention
scratch. An explicit 2K context freed **564.38 MiB** of state allocations in
the four-lane fixture.

The table shows each three-group comparison's decode verdict on the same
quantized target. The historical cases use native serial requests. The
four-lane fixture uses a warmed shared prefix.

"""
    + "\n".join(pr_table)
    + """

The serial sixteen-row comparisons differ on nine of 31 prompts. The final
eight-row functional run matches both eight-row controls on all 31, using
the same DSpine build and checkpoint as the sixteen-row arm.

The separate M48 prototype improves the primary operator screen by **34.78%**.
The report includes its source patch and numerical and functional checks.

"""
    + sampling_text
    + """

The full native CPU and Metal suites, host and Metal sanitizer suites,
1,606-test Python discovery (30 skipped) and 134-test Swift run passed their
recorded gates. Long-context boundaries, priority replay and SSD-cache takeover
passed their integration fixtures.

[Thirteen-hour report and reproduction commands]("""
    + report
    + """) ·
[Eight-hour study]("""
    + previous
    + """) · [Release assets]("""
    + release
    + """)

Refs #724.
"""
)
(publication / "pr-body.md").write_text(pr_body)
print(publication / "README.md")

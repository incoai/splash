"""Owned CPU-only sanitizer gate; finish before controlled GPU comparisons."""
from pathlib import Path
import datetime as dt
import hashlib
import json
import os
import signal
import subprocess
import time

root = Path(__file__).resolve().parents[1]
tree = root / 'production-final-v1'
ident = 'final-host-sanitizers-v1'
receipt = root / 'results' / (ident + '.receipt.json')
assert not receipt.exists()
assert not (root / 'notes/final-comparison-nominations-v1.json').exists()
assert json.loads((root / 'results/full-metal-production-final-v1.receipt.json').read_text())['exit_code'] == 0
assert (root / 'results/af4-m48-diagnostic-v3.receipt.json').exists(), 'M48 operator timing has not finished'
deadline = dt.datetime.fromisoformat(json.loads((root / 'session.json').read_text())['deadline_utc']).timestamp()
command = ['make', '-j4', 'test-sanitizers',
           'BUILD_ID_PYTHON=/Users/linson/Documents/ai/splash/.venv/bin/python']
protected = [tree / 'Makefile', tree / 'dev/native.mk', tree / 'build/splash', tree / 'build/splash.metallib',
             tree / 'build/engine/libsplash.a', tree / 'build/engine/BuildIdentity.hpp',
             root / 'patches/production-final-v1.patch']
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
utc = lambda: dt.datetime.now(dt.timezone.utc).isoformat()
record = {'id': ident, 'state': 'running', 'start_utc': utc(),
    'job': {'command': command, 'cwd': str(tree), 'classification': 'CPU-only full host ASan/UBSan/TSan suite. May overlap functional GPU tests; must finish before any controlled final comparison.'},
    'artifact_sha256': {str(p): sha(p) for p in protected},
    'power_before': subprocess.check_output(['pmset', '-g', 'batt'], text=True)}
start = time.monotonic()
with (root / 'results' / (ident + '.stdout')).open('x') as output, \
     (root / 'logs' / (ident + '.stderr')).open('x') as errors:
    process = subprocess.Popen(command, cwd=tree, stdout=output, stderr=errors, start_new_session=True)
    record['pid'] = process.pid
    (root / 'notes/host-sanitizers-active-v1.json').write_text(json.dumps(record, indent=2) + '\n')
    timed_out = False
    try:
        process.wait(timeout=max(1, min(5400, deadline - time.time())))
    except (subprocess.TimeoutExpired, KeyboardInterrupt):
        timed_out = True
        os.killpg(process.pid, signal.SIGINT)
        try:
            process.wait(timeout=20)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGTERM)
            try:
                process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
                process.wait(timeout=10)
record.update(state='timeout' if timed_out else 'complete', exit_code=process.returncode,
    end_utc=utc(), elapsed_seconds=time.monotonic() - start,
    artifact_sha256_after={str(p): sha(p) for p in protected},
    power_after=subprocess.check_output(['pmset', '-g', 'batt'], text=True))
if record['artifact_sha256'] != record['artifact_sha256_after']:
    record.update(state='artifact_changed_during_job', exit_code=123)
temporary = receipt.with_suffix('.tmp')
temporary.write_text(json.dumps(record, indent=2) + '\n')
temporary.replace(receipt)
out = root / 'artifacts/host-sanitizers-v1'
out.mkdir(exist_ok=False)
(out / 'build.json').write_text(json.dumps({'command': command, 'source_patch_sha256': sha(root / 'patches/production-final-v1.patch'),
    'binaries': {p.relative_to(tree).as_posix(): sha(p) for p in (tree / 'build/sanitizers').glob('*') if p.is_file() and os.access(p, os.X_OK)},
    'scope': 'Host control-plane tests only; no Metal sanitizer or cross-device claim. Uses the repository recipe and its declared engine-sim exclusion unchanged.'}, indent=2) + '\n')
print(json.dumps({k: record[k] for k in ['id', 'state', 'exit_code', 'elapsed_seconds']}, indent=2), flush=True)
raise SystemExit(record['exit_code'])

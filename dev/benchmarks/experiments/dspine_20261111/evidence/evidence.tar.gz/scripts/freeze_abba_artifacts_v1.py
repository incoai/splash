"""Generate an immutable artifact barrier before any controlled comparison."""
from pathlib import Path
import datetime as dt
import hashlib
import json
import sys

root = Path(__file__).resolve().parents[1]
protocol_path = Path(sys.argv[1])
protocol = json.loads(protocol_path.read_text())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


hashes = {str(protocol_path): sha(protocol_path)}
for variant, arm in protocol['artifact_nomination'].items():
    for key in ['patch', 'build_manifest', 'driver', 'library', 'host_step']:
        hashes[arm[key]] = sha(arm[key])
    assert hashes[arm['patch']] == arm['patch_sha256'], 'nominated patch changed'
    build = json.loads(Path(arm['build_manifest']).read_text())
    assert build['patch_sha256'] == arm['patch_sha256'], 'build does not match patch'
    driver_build = Path(arm['driver']).parent / 'build.json'
    hashes[str(driver_build)] = sha(driver_build)
    driver = json.loads(driver_build.read_text())
    assert driver['binary_sha256'] == hashes[arm['driver']], 'driver build mismatch'
    assert sha(Path(arm['build_manifest']).parent / 'splash.metallib') == hashes[arm['library']], 'driver shader differs'
for name, key in [('controlled_round.py', 'operating_script_sha256'),
                  ('analyze_abba_v1.py', 'analyzer_sha256'), ('abba.py', 'abba_sha256')]:
    path = root / 'scripts' / name
    hashes[str(path)] = sha(path)
    assert hashes[str(path)] == protocol[key], 'protocol implementation changed'
path = root / 'notes' / f"{protocol['prefix']}.artifact-barrier.json"
assert not path.exists(), 'artifact barrier already exists'
path.write_text(json.dumps({'frozen_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
                            'protocol': str(protocol_path), 'sha256': hashes}, indent=2) + '\n')
print(path)

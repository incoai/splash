"""One fixed timing round with read-only operating gates and continuous thermal observations."""
from pathlib import Path
import datetime as dt, json, subprocess, sys, time
r = Path(__file__).resolve().parents[1]
ident, *command = sys.argv[1:]
state_tool = r/'artifacts/operating-state'
record = {'id': ident, 'protocol': 'AC source required at launch and continuously during measurement. At least60s idle, nominal thermal state, GPU<=65C, CPUactive<=15%, GPUpower<1W andfreshtelemetry for three observations before launch; at most300s cooling. Runtime serious/critical thermal state orswap invalidates qualification. No external services are stopped.'}
def state():
    d = json.loads(subprocess.check_output([str(state_tool)], text=True))
    with (r/'results/hardware.jsonl').open('rb') as f:
        f.seek(max(0, f.seek(0, 2)-16384)); data = f.read().splitlines()
    h = None
    for raw in reversed(data):
        try:
            h = json.loads(raw)
            if 'recorded_unix' in h: break
        except json.JSONDecodeError:
            pass
    if h is None: raise RuntimeError('no complete hardware observation')
    d.update(utc=dt.datetime.now(dt.timezone.utc).isoformat(), gpu_temp=h['temp']['gpu_temp_avg'],
             gpu_freq_mhz=h['gpu_freq_mhz'], cpu_active_ratio=h['cpu_active_ratio'],
             memory=h['memory'], gpu_power=h['gpu_power'], telemetry_age_seconds=time.time()-h['recorded_unix'])
    return d
events = []; stable = 0; began = time.monotonic()
while time.monotonic()-began < 300:
    d = state(); events.append(dict(phase='cooldown', **d))
    stable = stable+1 if time.monotonic()-began >= 60 and d['ac_power'] and d['thermal_state'] == 0 and d['gpu_temp'] <= 65 and d['cpu_active_ratio'] <= 0.15 and d['gpu_power'] < 1 and d['telemetry_age_seconds'] <= 8 else 0
    if stable >= 3: break
    time.sleep(2)
record['operating_gate_passed'] = stable >= 3
record['cooldown_seconds'] = time.monotonic()-began
if stable < 3:
    record.update(events=events, exit_code=126, reason='operating gate did not clear')
    (r/f'results/{ident}.operating.json').write_text(json.dumps(record, indent=2)+'\n')
    sys.exit(126)
record['command'] = command; record['started_utc'] = dt.datetime.now(dt.timezone.utc).isoformat()
p = subprocess.Popen(command)
while p.poll() is None:
    d = state(); events.append(dict(phase='measurement', **d))
    time.sleep(5)
record.update(exit_code=p.returncode, ended_utc=dt.datetime.now(dt.timezone.utc).isoformat(), events=events)
record['no_serious_or_critical_state'] = all(e['thermal_state'] < 2 for e in events if e['phase'] == 'measurement')
record['ac_throughout_measurement'] = all(e['ac_power'] for e in events if e['phase'] == 'measurement')
record['no_swap'] = all(e['memory']['swap_usage'] == 0 for e in events if e['phase'] == 'measurement')
(r/f'results/{ident}.operating.json').write_text(json.dumps(record, indent=2)+'\n')
sys.exit(p.returncode)

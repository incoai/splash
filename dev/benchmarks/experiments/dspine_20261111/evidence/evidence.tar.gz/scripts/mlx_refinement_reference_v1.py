"""Run the pinned upstream exact-sender equations on identical native inputs."""
from pathlib import Path
import argparse
import hashlib
import importlib.metadata
import inspect
import json
import subprocess
import sys

import mlx.core as mx
import numpy as np

parser = argparse.ArgumentParser()
parser.add_argument('capture', type=Path)
parser.add_argument('output', type=Path)
args = parser.parse_args()
upstream = Path('/Users/linson/Documents/ai/splash-dspine-investigation-20261110/external/DSpine')
sys.path.insert(0, str(upstream / 'dspine_mlx'))
from dspine_mlx.propose import RefinementTail
from dspine_mlx.config import DraftConfig

root = args.capture
meta = json.loads((root / 'capture.json').read_text())
t, h, c, r = [meta[k] for k in ['rows', 'hidden', 'code', 'rank']]
n, k = t - 1, 16


def bf16(name, shape):
    bits = np.fromfile(root / name, dtype='<u2').reshape(shape)
    values = (bits.astype(np.uint32) << 16).view(np.float32)
    return mx.array(values).astype(mx.bfloat16)


ids = np.fromfile(root / 'codebook-ids.u32', dtype='<u4')
book = bf16('codebook.bf16', (len(ids), c))


class SparseBook:
    def __getitem__(self, query):
        values = np.asarray(query)
        at = np.searchsorted(ids, values)
        assert np.all(at < len(ids)) and np.array_equal(ids[at], values)
        return book[mx.array(at)]


candidates = np.fromfile(root / 'candidates.u32', dtype='<u4').reshape(n, k)
head = bf16('candidate-head.bf16', (n, k, h))


class MatchedHead:
    def rows(self, query):
        assert np.array_equal(np.asarray(query), candidates)
        return head


tail = RefinementTail.__new__(RefinementTail)
tail.rank = r
tail.code_size = c
tail.sqrt_c = c ** .5
tail.norm_w = bf16('norm.bf16', (h,)).astype(mx.float32)
tail.eps = 1e-6
tail.gate_b = bf16('gate-bias.bf16', (r,)).astype(mx.float32)
tail.codebook = SparseBook()
tail.pred_gate_w = bf16('predecessor-gate.bf16', (r, c)).astype(mx.float32)
tail.prev_w = bf16('previous.bf16', (r, c)).astype(mx.float32)
tail.write_w = bf16('write.bf16', (h, r)).astype(mx.float32)
tail.head = MatchedHead()
tail.candidates = lambda rows: mx.array(candidates, dtype=mx.int32)
stash = {'raw': bf16('raw.bf16', (t, h)),
         'rms': mx.array(np.fromfile(root / 'rms.f32', dtype='<f4')),
         'packed': bf16('packed.bf16', (t, 3 * r))}
table, support = tail.sampled_table(mx.zeros((n, h)), stash, meta['anchor'])
mx.eval(table, support)
scores = np.asarray(table).astype(np.float64)
tokens = np.fromfile(root / 'proposed.u32', dtype='<u4')
native = np.fromfile(root / 'probabilities.f32', dtype='<f4').reshape(n, k).astype(np.float64)
uniforms = np.fromfile(root / 'uniforms.f32', dtype='<f4')
conditional = []
for pos in range(n):
    sender = 0 if pos == 0 else int(np.flatnonzero(candidates[pos - 1] == tokens[pos - 1]).item())
    row = scores[pos, sender]
    p = np.exp(row - row.max()); p /= p.sum()
    q = native[pos]
    assert np.isfinite(p).all() and np.isfinite(q).all() and np.all(q >= 0)
    choice = min(int(np.searchsorted(np.cumsum(p), uniforms[1 + pos], side='right')), k - 1)
    conditional.append({'position': pos, 'native_predecessor': meta['anchor'] if pos == 0 else int(tokens[pos - 1]),
        'native_token': int(tokens[pos]), 'reference_token_same_uniform': int(candidates[pos, choice]),
        'same_uniform_token_agrees': int(tokens[pos]) == int(candidates[pos, choice]),
        'argmax_agrees': int(p.argmax()) == int(q.argmax()),
        'total_variation': float(np.abs(p - q).sum() / 2),
        'max_probability_error': float(np.abs(p - q).max()), 'native_mass': float(q.sum()),
        'reference_top_probability': float(p.max())})
np.asarray(table, dtype='<f4').tofile(args.output.with_suffix('.table.f32'))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
module = Path(inspect.getsourcefile(RefinementTail))
result = {'capture': meta, 'conditional_positions': conditional,
    'maximum_total_variation': max(v['total_variation'] for v in conditional),
    'same_uniform_tokens_agree': all(v['same_uniform_token_agrees'] for v in conditional),
    'all_argmaxes_agree': all(v['argmax_agrees'] for v in conditional),
    'mlx_version': importlib.metadata.version('mlx'), 'mlx_lm_version': importlib.metadata.version('mlx-lm'),
    'upstream_commit': subprocess.check_output(['git', '-C', str(upstream), 'rev-parse', 'HEAD'], text=True).strip(),
    'upstream_module_sha256': sha(module), 'capture_sha256': {p.name: sha(p) for p in root.iterdir() if p.is_file()},
    'scope': 'Conditional proposal probabilities from upstream RefinementTail.sampled_table at the actual native predecessor chain, identical captured stash/support/BF16 weights/head rows, temperature1 and unfiltered sixteen-candidate proposal. Does not compare full draft backbone, candidate generation, target-feature quality or prove distribution equivalence. The pinned upstream full-model loader rejects this checkpoint sliding-window configuration; it is not used or modified here.'}
config_path = Path('/Users/linson/Documents/ai/splash/build/dspine/checkpoint/config.json')
try:
    DraftConfig.from_dict(json.loads(config_path.read_text()), config_path)
except ValueError as error:
    result['upstream_unmodified_config_validation'] = {'accepted': False, 'error': str(error),
        'checkpoint_config_sha256': sha(config_path)}
else:
    raise AssertionError('Expected loader constraint changed; review diagnostic scope')
assert not args.output.exists()
args.output.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({k: result[k] for k in ['maximum_total_variation', 'same_uniform_tokens_agree', 'all_argmaxes_agree']}, indent=2))

from pathlib import Path
import hashlib,json,shutil,subprocess
r=Path(__file__).resolve().parents[1];out=r/'artifacts/af4-m48-operator-v2';out.mkdir(exist_ok=False)
old=json.loads((r/'artifacts/af4-coop-operator-v1/build.json').read_text())
def convert(s):return s.replace('af4-coop-operator-v1','af4-m48-operator-v2').replace('af4_coop_gateup_v1.metal','af4_m48_v2.metal').replace('af4_coop_oracle_v1.mm','af4_m48_oracle_v1.mm').replace('/coop.air','/m48.air')
commands=[[convert(s) for s in c] for c in old['commands']]
inputs={convert(p):hashlib.sha256(Path(convert(p)).read_bytes()).hexdigest() for p in old['inputs']}
for command in commands:subprocess.run(command,check=True)
shutil.copy2(r/'runtime16-v10/build/host-step.metallib',out/'host-step.metallib')
(out/'build.json').write_text(json.dumps({'commands':commands,'inputs':inputs,'artifacts':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in out.iterdir()},'scope':'Research-only M48operator. Final production source excludes it; no performance-driven substitution after heldout data.'},indent=2)+'\n')

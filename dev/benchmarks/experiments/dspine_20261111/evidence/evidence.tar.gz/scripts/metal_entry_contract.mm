#import <Foundation/Foundation.h>
#import <Metal/Metal.h>
#include <iostream>
#include <stdexcept>
int main(int argc, char **argv) {
  @autoreleasepool {
    try {
      if (argc != 3) throw std::runtime_error("usage: metal-entry-contract LIB ABI2_BOOL");
      const bool abi2 = std::string(argv[2]) == "1";
      id<MTLDevice> device = MTLCreateSystemDefaultDevice();
      NSError *error = nil;
      id<MTLLibrary> library = [device newLibraryWithURL:[NSURL fileURLWithPath:@(argv[1])] error:&error];
      if (!library) throw std::runtime_error(error.localizedDescription.UTF8String);
      for (NSString *base in @[@"draft_verify_rows", @"decode_sample_thinking_cutoff", @"decode_draft_thinking_cutoff"]) {
        const bool old = [library.functionNames containsObject:base];
        const bool current = [library.functionNames containsObject:[base stringByAppendingString:@"_abi2"]];
        const bool wide = [library.functionNames containsObject:[base stringByAppendingString:@"_abi2_v16"]];
        if (old == abi2 || current != abi2 || wide != abi2)
          throw std::runtime_error("control-parameter ABI entry names disagree");
      }
      std::cout << "control-parameter entry ABI contract: PASS\n";
      return 0;
    } catch (const std::exception &error) {
      std::cerr << error.what() << '\n'; return 1;
    }
  }
}

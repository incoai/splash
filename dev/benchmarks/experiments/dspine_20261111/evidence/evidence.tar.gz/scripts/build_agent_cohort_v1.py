"""Freeze original synthetic repository/tool-trace prompts before their first model outputs."""
from pathlib import Path
import datetime as dt, hashlib, json
from tokenizers import Tokenizer
r=Path(__file__).resolve().parents[1]
out=r/'cohorts';out.mkdir(exist_ok=True)
model_root=Path('/Users/linson/Documents/ai/splash/build/dspine/model-root.txt').read_text().strip()
tokenizer=Tokenizer.from_file(model_root+'/tokenizer/tokenizer.json')
tasks=[
 ('short_async',0,'A worker processes async jobs. Cancellation during queue.get leaves unfinished_tasks nonzero and join hangs. Write a corrected Python worker with task_done in the right place, bounded concurrency, explicit shutdown, and two focused tests.'),
 ('short_arena',0,'Review this C++ arena API: allocate returns a span; grow replaces the backing vector; the parser stores spans while recursively allocating. Explain the lifetime bug and implement a stable allocation strategy with checked sizes and a small regression test.'),
 ('short_sql',0,'A background importer retries a batch after its connection drops. Each record has a stable external id, but the importer increments a counter before committing. Give a transaction design and SQL pseudocode that makes replay idempotent and keeps the counter exact.'),
 ('short_rust',0,'A Rust producer sends tasks through a bounded channel and then waits for every worker while keeping its Sender alive. Workers wait forever for recv to finish. Write a corrected shutdown sequence, explain ownership, and give a deterministic test without sleeps.'),
 ('medium_cancel',4096,'Use the tool trace to diagnose why cancelled work leaves a reservation in the ledger. Propose a minimal Python patch that releases once after completion or cancellation and tests both orders of the race. Cite the relevant operation ids.'),
 ('medium_cache',4096,'Use the repository notes to design a cache key that distinguishes payload version, tokenizer version, and execution width. Show code for canonical encoding and tests for field order, missing fields, and incompatible versions.'),
 ('medium_stream',4096,'The trace includes a stream retry after the client has received some tokens. Design a sequence-number protocol that suppresses duplicates, preserves ordering, and clearly reports a missing chunk. Implement a small reference receiver and tests.'),
 ('medium_router',4096,'Inspect the trace and implement a stable request router: priority first, then admission sequence, with cancellation removing queued work. Explain a starvation bound and test equal-priority ordering and removal.'),
 ('long_checkpoint',16384,'Inspect the tool trace and repository excerpts. A checkpoint may be published only after both KV pages and recurrent state are committed at the same token boundary. Write an audit plan and a minimal state-machine implementation that rejects mixed boundaries, with tests.'),
 ('long_budget',16384,'A memory planner confuses a model execution block with the fixed packing tile. Use the repository notes to derive allocation formulas for 8-row and 16-row blocks with a fixed 8-row tile and at most four lanes. Include overflow checks and tests at 16, 32, 48, and 64 rows.'),
 ('long_replay',16384,'An agent resumes after suspension and must rebuild state from emitted tokens without drawing another random sample or emitting those tokens again. Use the trace to design the replay state machine, identify invariants, and write a compact Python implementation with tests.'),
 ('long_tooljson',16384,'A tool returns JSON objects in chunks that may end inside an escaped string. Use the repository notes to implement a streaming object decoder with bounded buffering, correct escape handling, a final incomplete-input error, and tests for every split point of one object.'),
]
records=[];lines=[]
for index,(name,context_target,task) in enumerate(tasks):
 context=''
 if context_target:
  fragments=[]
  for n in range(1200):
   event=['reserve','dispatch','complete','cancel','publish','restore'][n%6]
   fragments.append(f'operation op_{index:02d}_{n:04d}: event={event}; request={n%17}; generation={n//17}; token_boundary={32*(n%127)}; reservation={(n%9+1)*4096}; owner=engine; terminal={str(n%6 in (2,3)).lower()}.\n')
   if n%13==0:fragments.append(f'repository module_{n%19}.py: validate the generation before consuming an event; release a reservation exactly once; publish only equal committed boundaries; preserve stable admission order.\n')
  ids=tokenizer.encode(''.join(fragments),add_special_tokens=False).ids
  context=tokenizer.decode(ids[:context_target],skip_special_tokens=False)
  context='Repository excerpts and tool trace (synthetic):\n'+context+'\nEnd of trace.\n'
 prompt='<|im_start|>user\n'+context+task+'\nGive the complete proposed implementation and explain the invariants.<|im_end|>\n<|im_start|>assistant\n<think>\n\n</think>\n\n'
 ids=tokenizer.encode(prompt,add_special_tokens=False).ids
 rec={'name':name,'category':'short' if context_target==0 else 'medium' if context_target==4096 else 'long','context_target_tokens':context_target,'output_cap':256,'prompt':prompt,'tokens':ids,'prompt_tokens':len(ids),'prompt_sha256':hashlib.sha256(prompt.encode()).hexdigest()}
 records.append(rec);lines.append(name+' 256 '+' '.join(map(str,ids)))
path=out/'agent12-v1.txt';path.write_text('\n'.join(lines)+'\n');(out/'agent12-v1.json').write_text(json.dumps(records,indent=2)+'\n')
protocol={'frozen_utc':dt.datetime.now(dt.timezone.utc).isoformat(),'cohort':'agent12-v1.txt','sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'cases':[{k:v for k,v in x.items() if k not in ('prompt','tokens')} for x in records],'provenance':'Twelve original synthetic software-agent tasks and generated repository/tool traces; no model outputs used to select them. These are performance and exact-target-output fixtures, not a scored agent-quality benchmark.','endpoint':'Report cold wall, TTFT and decode wall separately; all twelve cases retained, including EOS-shortened outputs. Category summaries predeclared short/medium/long (four each). Warm-prefix experiments use the same token prefix of each case and report seed cost separately.','qualification':'Freeze artifacts and exactly three ABBA groups before qualified comparison. Preserve every failed/noisy/incomplete group. Require identical complete greedy token arrays, valid accounting and continuously AC operating gates. Each paired endpoint must beat max(2%, twice the maximum within-arm spread); every included case after predeclared internal repetition aggregation has spread <=5%. No repeat-to-pass or dropping cases.','independence':'Historical cohort31 is calibration. This cohort remains held out from performance-driven source selection until a separately recorded nomination freeze.'}
(out/'agent12-v1.protocol.json').write_text(json.dumps(protocol,indent=2)+'\n');print(json.dumps({'path':str(path),'sha256':protocol['sha256'],'tokens':[x['prompt_tokens'] for x in records]}))

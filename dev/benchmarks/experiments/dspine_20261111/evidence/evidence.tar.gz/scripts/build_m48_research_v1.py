"""Build a fresh immutable source snapshot; never rebuild a timed artifact in place."""
from pathlib import Path
import hashlib,json,shutil,subprocess,sys
r=Path(__file__).resolve().parents[1]
name=sys.argv[1];patch=Path(sys.argv[2]) if len(sys.argv)>2 else None
tree=r/name;out=r/'artifacts'/name
assert not tree.exists() and not out.exists(),'Fresh artifact/source paths required'
base=json.loads((r/'session.json').read_text())['baseline_commit']
subprocess.run(['git','-C','/Users/linson/Documents/ai/splash','worktree','add','--detach',str(tree),base],check=True)
if patch:
 subprocess.run(['git','-C',str(tree),'apply','--check',str(patch)],check=True)
 subprocess.run(['git','-C',str(tree),'apply',str(patch)],check=True)
subprocess.run(['git','-C',str(tree),'diff','--check'],check=True)
def identity():
 names=subprocess.check_output(['git','-C',str(tree),'ls-files','-z','--cached','--others','--exclude-standard']).decode().split('\0')
 manifest={name:(hashlib.sha256((tree/name).read_bytes()).hexdigest() if (tree/name).is_file() else None) for name in sorted(set(names)) if name}
 return manifest
before=identity();tests=['backend-benchmark','weight-digests','decode-profile','dspine','draft-attention','gdn-decode','linear-plan','target-sampling','draft-selector','attention-variants','draft-attention16','gdn-decode16','draft-selector16','dspine16','target-sampling16','attention-variants16']
command=['make','-C',str(tree),'-j2','all','test-engine-cpu','BUILD_ID_PYTHON=/Users/linson/Documents/ai/splash/.venv/bin/python',*['build/engine-tests/'+t for t in tests]]
subprocess.run(command,check=True)
assert identity()==before,'Source changed during build'
out.mkdir()
for name in ['splash','splash.metallib','host-step.metallib']:shutil.copy2(tree/'build'/name,out/name)
for name in tests:shutil.copy2(tree/'build/engine-tests'/name,out/name)
record={'base':base,'source_manifest_sha256':hashlib.sha256(json.dumps(before,sort_keys=True).encode()).hexdigest(),'source_manifest':before,'patch':str(patch) if patch else None,'patch_sha256':hashlib.sha256(patch.read_bytes()).hexdigest() if patch else None,'command':command,'artifacts':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in out.iterdir()}}
(out/'build.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record,indent=2))

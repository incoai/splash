#pragma clang fp reassociate(off)
#include "metal/kernels/common/gguf_staged_tile.h"
#include "metal/kernels/common/split_reduce.h"

// The same K32 walk and half dequantization as the existing pair loop.
// Each SIMD lane stages one column of one operand; all lanes participate
// in both tensor operations and every barrier.
template<class F, ushort Rows, class Acc>
inline void af4_n16_pair_steps(device bfloat *input, device uchar *gw0, device uchar *gw1, device uchar *gmeta,
    device uchar *uw0, device uchar *uw1, device uchar *umeta, uint inputSize, uint origin,
    threadgroup half *stage, threadgroup half2 *table, uint lane,
    uint begin, uint end, uint first, thread Acc &gate, thread Acc &up) {
  constexpr ushort Columns=16, Step=32;
  auto a=tensor(input,dextents<int,2>{int(inputSize),Rows},array<int,2>{1,int(inputSize)});
  constexpr auto descriptor=matmul2d_descriptor(Rows,Columns,Step,false,true,false,
      matmul2d_descriptor::mode::multiply_accumulate);
  matmul2d<descriptor,execution_simdgroups<1>> operation;
  tensor<threadgroup half,dextents<int,2>,tensor_inline> gateTensor(stage,dextents<int,2>{Step,Columns},array<int,2>{1,Step});
  tensor<threadgroup half,dextents<int,2>,tensor_inline> upTensor(stage+Step*Columns,dextents<int,2>{Step,Columns},array<int,2>{1,Step});
  auto bg=gateTensor.slice<Step,Columns>(0,0),bu=upTensor.slice<Step,Columns>(0,0);
  const bool isGate=lane<Columns;
  const uint column=lane%Columns;
  StagedColumn<F> weight;
  weight.begin(isGate?gw0:uw0,isGate?gw1:uw1,isGate?gmeta:umeta,inputSize,origin,column,first,begin<end);
  const auto runStep=[&](uint step,uint next,bool more) __attribute__((always_inline)) {
    weight.stage(step,table,stage+(isGate?0:Step*Columns),column);
    simdgroup_barrier(mem_flags::mem_threadgroup);
    if(more)weight.load(step,next);
    auto slice=a.template slice<Step,Rows>(step*Step,0);
    operation.run(slice,bg,gate);operation.run(slice,bu,up);
    simdgroup_barrier(mem_flags::mem_threadgroup);
  };
  uint walked=0;
  for(uint run=0;run<2;++run){
    const uint from=run?begin:first,to=run?first:end;
    for(uint step=from;step<to;++step,++walked)
      runStep(step,step+1<to?step+1:begin,walked+1<end-begin);
  }
}
template <class F, ushort Rows>
kernel void gguf_decode_n16_gate_up(device bfloat *input [[buffer(0)]], device uchar *gw0 [[buffer(1)]],
                                device uchar *gw1 [[buffer(2)]], device uchar *gmeta [[buffer(3)]],
                                device uchar *uw0 [[buffer(4)]], device uchar *uw1 [[buffer(5)]],
                                device uchar *umeta [[buffer(6)]], device bfloat *output [[buffer(7)]],
                                device coherent(device) float *partials [[buffer(8)]],
                                device atomic_uint *counters [[buffer(9)]], constant GgufDecodeParams &p [[buffer(10)]],
                                uint2 group [[threadgroup_position_in_grid]], uint lane [[thread_index_in_simdgroup]]) {
  threadgroup half2 tl[F::Kind == QuantCodebook ? kQuantPairTableEntries : 1];
  quant_pair_table<F>(tl, lane, GGUF_GATE_UP_THREADS);
  threadgroup half stage[2 * 16u * GGUF_STAGED_STEP];
  threadgroup uint arrival;
  const uint per = p.input_size / GGUF_STAGED_STEP / p.splits, sb = group.y * per, se = sb + per,
             origin = group.x * 16u, column0 = p.out_offset + origin;
  auto gate = staged_accumulator<Rows, 16u, GGUF_STAGED_STEP>(input, p.input_size, stage);
  auto up = staged_accumulator<Rows, 16u, GGUF_STAGED_STEP>(input, p.input_size, stage);
  gguf_zero(gate);
  gguf_zero(up);
  af4_n16_pair_steps<F, Rows>(input, gw0, gw1, gmeta, uw0, uw1, umeta, p.input_size, origin, stage, tl, lane, sb,
                                  se, staged_first_step(group.x / 4, sb, se, p.spread), gate, up);
  const auto value = [](float g, float u) { return bfloat(float(bfloat(u)) * splash_silu(float(bfloat(g)))); };
  const auto out = [&](uint row, uint column) { return ulong(row) * p.out_stride + column0 + column; };
  if (p.splits == 1) {
#pragma unroll
    for (ushort i = 0; i < gate.get_capacity(); ++i) {
      if (!gate.is_valid_element(i)) continue;
      const auto index = gate.get_multidimensional_index(i);
      output[out(index[1], index[0])] = value(gate[i], up[i]);
    }
    return;
  }
  const auto at = [&](uint s, uint row, uint column) {
    return (ulong(s) * Rows + row) * (2 * p.out_stride) + column0 + column;
  };
#pragma unroll
  for (ushort i = 0; i < gate.get_capacity(); ++i) {
    if (!gate.is_valid_element(i)) continue;
    const auto index = gate.get_multidimensional_index(i);
    partials[at(group.y, index[1], index[0])] = gate[i];
    partials[at(group.y, index[1], index[0]) + p.out_stride] = up[i];
  }
  device atomic_uint *counter = counters + p.out_offset / 16u + group.x;
  if (!split_arrive_last(counter, p.splits, lane, &arrival)) return;
#pragma unroll
  for (ushort i = 0; i < gate.get_capacity(); ++i) {
    if (!gate.is_valid_element(i)) continue;
    const auto index = gate.get_multidimensional_index(i);
    const uint row = index[1], column = index[0];
    const float g = split_sum(float(gate[i]), group.y, p.splits, [&](uint s) { return partials[at(s, row, column)]; });
    const float u = split_sum(float(up[i]), group.y, p.splits,
                              [&](uint s) { return partials[at(s, row, column) + p.out_stride]; });
    output[out(row, column)] = value(g, u);
  }
  split_release(counter, lane);
}
using GgufDecodeGateUpKernel = void(device bfloat *, device uchar *, device uchar *, device uchar *, device uchar *,
                                    device uchar *, device uchar *, device bfloat *, device coherent(device) float *,
                                    device atomic_uint *, constant GgufDecodeParams &, uint2, uint);
template [[host_name("gguf_decode_af4g64_m16_gate_up_n16")]] kernel GgufDecodeGateUpKernel gguf_decode_n16_gate_up<FmtAF4G64,16>;
template [[host_name("gguf_decode_af4g64_m32_gate_up_n16")]] kernel GgufDecodeGateUpKernel gguf_decode_n16_gate_up<FmtAF4G64,32>;
template [[host_name("gguf_decode_af4g64_m64_gate_up_n16")]] kernel GgufDecodeGateUpKernel gguf_decode_n16_gate_up<FmtAF4G64,64>;

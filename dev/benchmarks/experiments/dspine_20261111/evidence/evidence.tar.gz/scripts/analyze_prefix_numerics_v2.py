"""Compare actual pre-policy rows only while their conditional prefixes match."""
from pathlib import Path
import hashlib
import json
import numpy as np
root = Path(__file__).resolve().parents[1]
tokenizer = None
try:
    from tokenizers import Tokenizer
    model = Path('/Users/linson/Documents/ai/splash/build/dspine/model-root.txt').read_text().strip()
    tokenizer = Tokenizer.from_file(model + '/tokenizer/tokenizer.json')
except (ImportError, OSError):
    pass  # Token text is optional; all numerical evidence uses token IDs.


def load(ident):
    receipt = json.loads((root / 'results' / f'{ident}.receipt.json').read_text())
    assert receipt['state'] == 'complete' and receipt['exit_code'] == 0, 'row mapping/capture did not validate'
    doc = json.loads((root / 'results' / f'{ident}.stdout').read_text())
    values = {m['scenario'].removeprefix('runtime_cache_'): m['output_tokens'] for m in doc['measurements']}
    captures = {}
    for phase in ['cold', 'hit']:
        base = root / 'logit-probes' / ident / f'runtime_cache_{phase}-s0'
        captures[phase] = {}
        for line in base.with_suffix('.jsonl').read_text().splitlines():
            row = json.loads(line)
            if row['binary_offset'] is None:
                continue
            array = np.fromfile(base.with_suffix('.f32'), dtype='<f4', count=row['vocabulary'], offset=row['binary_offset'])
            assert len(array) == row['vocabulary'] and np.isfinite(array).all()
            assert int(np.argmax(array)) == values[phase][row['prediction_index']], 'captured argmax differs'
            captures[phase][row['prediction_index']] = array
    return values, captures


def compare_rows(a, b):
    a, b = a.astype(np.float64), b.astype(np.float64)
    delta = b - a
    ea = np.exp(a - a.max()); eb = np.exp(b - b.max())
    loga = a - a.max() - np.log(ea.sum()); logb = b - b.max() - np.log(eb.sum())
    pa = np.exp(loga); pb = np.exp(logb)
    sa = np.argsort(a)[-2:][::-1]; sb = np.argsort(b)[-2:][::-1]
    return {'raw_rms_delta': float(np.sqrt(np.mean(delta**2))),
            'mean_delta': float(delta.mean()), 'maximum_absolute_delta': float(np.abs(delta).max()),
            'centered_relative_rms_delta': float(np.sqrt(np.mean((delta - delta.mean())**2)) / np.std(a)),
            'temperature1_full_vocab_total_variation': float(np.abs(pa - pb).sum() / 2),
            'temperature1_full_vocab_kl_a_to_b': float(np.sum(pa * (loga - logb))),
            'a_top2': [[int(i), tokenizer.decode([int(i)]) if tokenizer else None, float(a[i])] for i in sa],
            'b_top2': [[int(i), tokenizer.decode([int(i)]) if tokenizer else None, float(b[i])] for i in sb],
            'a_top2_margin': float(a[sa[0]] - a[sa[1]]),
            'b_top2_margin': float(b[sb[0]] - b[sb[1]])}


records = {}
loaded = {}
for ident in ['prefix-logit-probe-control8-v2', 'prefix-logit-probe-core8-v2',
              'prefix-logit-probe-core16-v2', 'prefix-logit-probe-dflash8-v2',
              'aligned-prefix-logit-probe-control8-v2', 'aligned-prefix-logit-probe-core16-v2',
              'full-seed-prefix-logit-probe-control8-v3', 'full-seed-prefix-logit-probe-core16-v3']:
    outputs, captures = load(ident)
    loaded[ident] = outputs, captures
    first = next((i for i, (a, b) in enumerate(zip(outputs['cold'], outputs['hit'])) if a != b), None)
    if first is None and len(outputs['cold']) != len(outputs['hit']):
        first = min(len(outputs['cold']), len(outputs['hit']))
    common = sorted(captures['cold'].keys() & captures['hit'].keys())
    valid = [i for i in common if first is None or i <= first]
    records[ident] = {'cold_hit_arrays_match': outputs['cold'] == outputs['hit'],
                      'first_different_output_index': first,
                      'positions_with_matching_conditional_prefix': valid,
                      'selected_rows_bitwise_identical': all(np.array_equal(captures['cold'][i], captures['hit'][i]) for i in valid),
                      'prefill_cache_metadata': [{k:m[k] for k in ['scenario','prompt_tokens','matched_tokens','target_prefill_rows','cache_status']} for m in json.loads((root/'results'/f'{ident}.stdout').read_text())['measurements']],
                      'rows': {str(i): compare_rows(captures['cold'][i], captures['hit'][i]) for i in valid}}

control_outputs, control = loaded['prefix-logit-probe-control8-v2']
new_outputs, new = loaded['prefix-logit-probe-core8-v2']
preservation = {}
for phase in ['cold', 'hit']:
    same = control_outputs[phase] == new_outputs[phase]
    assert same, 'default-width source arrays differ'
    indices = sorted(control[phase].keys() & new[phase].keys())
    preservation[phase] = {'arrays_match': same, 'rows_compared': indices,
                           'all_selected_full_vocabulary_rows_bitwise_match': all(
                               np.array_equal(control[phase][i], new[phase][i]) for i in indices)}
a_outputs, a_rows = loaded['full-seed-prefix-logit-probe-control8-v3']
b_outputs, b_rows = loaded['full-seed-prefix-logit-probe-core16-v3']
first_cross = next((i for i, (a, b) in enumerate(zip(a_outputs['cold'], b_outputs['cold'])) if a != b), None)
valid_cross = [i for i in sorted(a_rows['cold'].keys() & b_rows['cold'].keys()) if first_cross is None or i <= first_cross]
cross_width = {'cold_arrays_match': a_outputs['cold'] == b_outputs['cold'],
               'first_different_output_index': first_cross,
               'positions_with_matching_conditional_prefix': valid_cross,
               'rows': {str(i): compare_rows(a_rows['cold'][i], b_rows['cold'][i]) for i in valid_cross}}
result = {'scope': 'One historical 8,193-token prompt, 64 greedy outputs, actual pre-policy target rows; every captured argmax mapping validated against returned tokens. Differences are compared only before/at the first token divergence, while conditioning is identical. This is not a quality or distribution-equivalence proof.',
          'default8_source_preservation': preservation, 'runs': records,
          'cross_width_cold_target_numerics': cross_width,
          'seed_partition_note': 'The old aligned label denotes an 8,192-token seed, which actually restored 8,160 tokens and replayed 33. Full-seed v3 seeds the entire 8,193-token prompt; read actual matched_tokens and target_prefill_rows before claiming final-chunk alignment. Original fixed 64-token suffix mismatches remain retained.',
          'interpretation_rule': 'A flipped near tie plus different prefill partitions is consistent with chunk-dependent floating-point rounding. It does not identify a particular operator or prove all cache behavior correct. Aligned seeding is an additional diagnostic and never replaces the retained fixed64-suffix failure.'}
(root / 'results/prefix-numerics-v2.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'default8_rows_preserved': {k: len(v['rows_compared']) for k,v in preservation.items()},
    'full_seed': {k: {'arrays_match': v['cold_hit_arrays_match'], 'selected_rows_bitwise_identical': v['selected_rows_bitwise_identical'],
                     'matched_tokens': v['prefill_cache_metadata'][2]['matched_tokens'],
                     'replayed_rows': v['prefill_cache_metadata'][2]['target_prefill_rows']}
                  for k,v in records.items() if k.startswith('full-seed')},
    'cross_width_first_difference': first_cross}, indent=2))

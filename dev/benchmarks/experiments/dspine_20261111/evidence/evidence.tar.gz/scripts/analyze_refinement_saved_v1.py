"""Recompute the conditional-tail diagnostic from derived outputs, without weights."""

from pathlib import Path
import hashlib
import json

import numpy as np

root = Path(__file__).resolve().parents[1]
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
cases = []
for width in [8, 16]:
    receipt_path = root / 'results' / f'refinement-mlx-r{width}-v3.receipt.json'
    receipt = json.loads(receipt_path.read_text())
    assert receipt['exit_code'] == 0 and receipt['state'] == 'complete'
    assert receipt['artifact_sha256'] == receipt['artifact_sha256_after']
    capture = root / 'refinement-probes' / Path(receipt['job']['command'][-2]).name
    original_path = root / 'results' / Path(receipt['job']['command'][-1]).name
    original = json.loads(original_path.read_text())
    meta = json.loads((capture / 'capture.json').read_text())
    n, k = width - 1, meta['top_k_proposal']
    assert meta['rows'] == width and k == 16
    assert meta['temperature'] == 1 and meta['top_p_proposal'] == 1
    table_path = original_path.with_suffix('.table.f32')
    scores = np.fromfile(table_path, dtype='<f4').reshape(n, k, k).astype(np.float64)
    candidates = np.fromfile(capture / 'candidates.u32', dtype='<u4').reshape(n, k)
    native = np.fromfile(capture / 'probabilities.f32', dtype='<f4').reshape(n, k).astype(np.float64)
    tokens = np.fromfile(capture / 'proposed.u32', dtype='<u4')
    uniforms = np.fromfile(capture / 'uniforms.f32', dtype='<f4')
    for name in ['capture.json', 'candidates.u32', 'probabilities.f32', 'proposed.u32', 'uniforms.f32']:
        assert sha(capture / name) == original['capture_sha256'][name], name
    positions = []
    for pos in range(n):
        sender = 0 if pos == 0 else int(np.flatnonzero(candidates[pos - 1] == tokens[pos - 1]).item())
        row = scores[pos, sender]
        p = np.exp(row - row.max())
        p /= p.sum()
        q = native[pos]
        assert np.isfinite(p).all() and np.isfinite(q).all() and np.all(q >= 0)
        choice = min(int(np.searchsorted(np.cumsum(p), uniforms[1 + pos], side='right')), k - 1)
        current = {
            'position': pos,
            'native_predecessor': meta['anchor'] if pos == 0 else int(tokens[pos - 1]),
            'native_token': int(tokens[pos]),
            'reference_token_same_uniform': int(candidates[pos, choice]),
            'same_uniform_token_agrees': int(tokens[pos]) == int(candidates[pos, choice]),
            'argmax_agrees': int(p.argmax()) == int(q.argmax()),
            'total_variation': float(np.abs(p - q).sum() / 2),
            'max_probability_error': float(np.abs(p - q).max()),
            'native_mass': float(q.sum()),
            'reference_top_probability': float(p.max()),
        }
        expected = original['conditional_positions'][pos]
        assert current.keys() == expected.keys()
        for key, value in current.items():
            if isinstance(value, float):
                assert np.isclose(value, expected[key], rtol=1e-12, atol=1e-12), (width, pos, key)
            else:
                assert value == expected[key], (width, pos, key)
        positions.append(current)
    cases.append({
        'rows': width,
        'conditional_positions': positions,
        'maximum_total_variation': max(p['total_variation'] for p in positions),
        'all_same_uniform_tokens_agree': all(p['same_uniform_token_agrees'] for p in positions),
        'all_argmaxes_agree': all(p['argmax_agrees'] for p in positions),
        'original_json_sha256': sha(original_path),
        'derived_reference_table_sha256': sha(table_path),
        'receipt_sha256': sha(receipt_path),
    })

result = {
    'cases': cases,
    'all_original_metrics_reproduced': True,
    'scope': 'Reanalysis of saved derived reference scores, native probabilities/support/tokens/uniforms. Uses no model weights or MLX. It verifies saved arithmetic, not the original upstream implementation or a full model. Float report comparison uses 1e-12 tolerance; no retrospective numerical equivalence threshold is introduced.',
}
output = root / 'results/refinement-saved-check-v1.json'
assert not output.exists()
output.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'all_original_metrics_reproduced': True, 'positions': sum(len(c['conditional_positions']) for c in cases)}))

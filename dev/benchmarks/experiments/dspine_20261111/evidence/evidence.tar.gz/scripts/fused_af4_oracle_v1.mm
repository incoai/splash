#include "GgufFormatReference.hpp"
#include "metal/CommandGraph.hpp"
#include "metal/abi/Gguf.h"
#include <array>
#include <cstring>
#include <iostream>
#include <random>
#include <stdexcept>
using namespace splash;
using namespace gguf_reference;

struct Guarded {
  metal::MetalBuffer base, view;
  uint64_t bytes;
  Guarded(metal::MetalBackend &backend, uint64_t size, uint8_t fill = 0) : bytes(size) {
    base = backend.allocateBuffer(size + 256, metal::BufferStorage::Shared, "fused AF4 oracle");
    std::memset(base.contents(), fill, size);
    std::memset(static_cast<uint8_t *>(base.contents()) + size, 0xa5, 256);
    view = backend.view(base, 0, size);
  }
  void check() const {
    const auto *p = static_cast<const uint8_t *>(base.contents()) + bytes;
    if (!std::all_of(p, p + 256, [](uint8_t x) { return x == 0xa5; }))
      throw std::runtime_error("guard overwritten");
  }
};
struct Weight {
  metal::MetalBuffer code, other, meta;
  std::vector<float> reference;
};
Weight weight(metal::MetalBackend &backend, uint32_t n, uint32_t k, std::mt19937 &rng) {
  const auto native = makeNative(Fmt(GGUF_FMT_AF4G64), n, k, rng);
  Weight w;
  const auto packed = repack(Fmt(GGUF_FMT_AF4G64), native, n, k, &w.reference);
  const auto upload = [&](const auto &v) {
    auto b = backend.allocateBuffer(v.size(), metal::BufferStorage::Shared, "AF4 planes");
    std::memcpy(b.contents(), v.data(), v.size()); return b;
  };
  w.code = upload(packed.w0); w.other = upload(packed.w1); w.meta = upload(packed.meta);
  return w;
}
void run(metal::MetalBackend &backend, uint32_t rows, uint32_t live, uint32_t k, uint32_t segments) {
  std::mt19937 rng(91871 + rows + k + segments);
  const std::array<uint32_t, 3> columns{64, 128, 192}, offsets{64, 192, 384};
  constexpr uint32_t stride = 640;
  std::array<Weight, 3> weights;
  for (uint32_t s = 0; s < 3; ++s) weights[s] = weight(backend, columns[s], k, rng);
  Guarded input(backend, uint64_t(rows) * k * 2), output(backend, uint64_t(rows) * stride * 2, 0xcd),
      partials(backend, uint64_t(16) * rows * stride * 4, 0xff), counters(backend, stride / 64 * 4);
  auto *x = static_cast<uint16_t *>(input.view.contents());
  std::vector<float> xf(uint64_t(rows) * k);
  std::uniform_real_distribution<float> dist(-0.2f, 0.2f);
  for (uint32_t row = 0; row < rows; ++row) for (uint32_t col = 0; col < k; ++col) {
    const auto i = uint64_t(row) * k + col;
    x[i] = row < live ? test::floatToBf16(dist(rng)) : 0x7fc0;
    xf[i] = test::bf16ToFloat(x[i]);
  }
  uint64_t comparisons = 0, cpuChecks = 0;
  for (bool spread : {false, true}) for (uint32_t split : {1u, 2u, 4u, 8u, 16u}) {
    if ((k / 32) % split) continue;
    GgufDecodeFusedParams p{k, split, stride, {}, {}, {}, spread};
    std::vector<metal::MetalBuffer> bindings{input.view};
    uint32_t tiles = 0;
    for (uint32_t s = 0; s < 3; ++s) {
      if (s < segments) {
        p.cols[s] = columns[s]; p.fmt[s] = GGUF_FMT_AF4G64; p.offset[s] = offsets[s];
        tiles += columns[s] / 64;
      }
      bindings.insert(bindings.end(), {weights[s].code, weights[s].other, weights[s].meta});
    }
    bindings.insert(bindings.end(), {output.view, partials.view, counters.view});
    std::vector<uint16_t> generic;
    for (bool specialized : {false, true}) {
      std::memset(output.view.contents(), 0xcd, output.bytes);
      metal::CommandGraph graph;
      graph.add(std::string(specialized ? "gguf_decode_fused_af4g64_m" : "gguf_decode_fused_m") +
                    std::to_string(rows), bindings, p, {tiles, split, 1}, {64, 1, 1});
      backend.preparePipelines(graph.dispatches());
      (void)backend.submitCommandAsync(graph.dispatches()).wait();
      input.check(); output.check(); partials.check(); counters.check();
      const auto *count = static_cast<const uint32_t *>(counters.view.contents());
      if (!std::all_of(count, count + stride / 64, [](uint32_t v) { return v == 0; }))
        throw std::runtime_error("split counter not released");
      const auto *out = static_cast<const uint16_t *>(output.view.contents());
      if (!specialized) generic.assign(out, out + uint64_t(rows) * stride);
      else for (uint64_t i = 0; i < uint64_t(rows) * stride; ++i) {
        ++comparisons;
        if (out[i] != generic[i]) throw std::runtime_error("specialized/generic bits differ");
      }
      for (uint32_t row = 0; row < rows; ++row) for (uint32_t col = 0; col < stride; ++col) {
        bool written = false;
        for (uint32_t s = 0; s < segments; ++s)
          written |= col >= offsets[s] && col < offsets[s] + columns[s];
        const auto actual = out[uint64_t(row) * stride + col];
        if (!written && actual != 0xcdcd) throw std::runtime_error("destination gap overwritten");
        if (written && row >= live && !std::isnan(test::bf16ToFloat(actual)))
          throw std::runtime_error("NaN padding not isolated");
      }
      for (uint32_t s = 0; s < segments; ++s)
        for (uint32_t row : {0u, live / 2, live - 1}) for (uint32_t col : {0u, columns[s] / 2, columns[s] - 1}) {
          const auto d = dot(xf.data() + uint64_t(row) * k,
                             weights[s].reference.data() + uint64_t(col) * k, k);
          const double bound = projectionBound(d, true);
          const auto lo = test::bf16ToFloat(test::floatToBf16(float(d.value - bound)));
          const auto hi = test::bf16ToFloat(test::floatToBf16(float(d.value + bound)));
          const float actual = test::bf16ToFloat(out[uint64_t(row) * stride + offsets[s] + col]);
          ++cpuChecks;
          if (!std::isfinite(actual) || actual < lo || actual > hi)
            throw std::runtime_error("projection outside independent FP64 interval");
        }
    }
  }
  std::cout << "{\"case_passed\":true,\"rows\":" << rows << ",\"live_rows\":" << live
            << ",\"inputs\":" << k << ",\"segments\":" << segments
            << ",\"bitwise_comparisons\":" << comparisons << ",\"independent_fp64_checks\":" << cpuChecks << "}\n";
}
int main(int argc, char **argv) {
  try {
    if (argc != 2) throw std::invalid_argument("usage: fused-af4-oracle METALLIB");
    metal::MetalBackend backend(argv[1]);
    for (uint32_t rows : {16u, 32u, 64u}) for (uint32_t k : {512u, 1152u, 5120u})
      for (uint32_t live : {rows, rows * 3 / 4}) for (uint32_t segments : {2u, 3u})
        run(backend, rows, live, k, segments);
  } catch (const std::exception &e) { std::cerr << e.what() << '\n'; return 1; }
}

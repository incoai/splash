"""Commit only the locally validated boundary fix and its reproducible receipt."""
from pathlib import Path
import datetime as dt
import hashlib
import json
import subprocess

root = Path(__file__).resolve().parents[1]
tree = root / 'geometry'
manifest_path = root / 'artifacts/runtime16-v12/build.json'
manifest = json.loads(manifest_path.read_text())
for name, expected in manifest['source_manifest'].items():
    if name.startswith(('runtime/', 'dev/tests/engine/')) or name in ['Makefile', 'dev/native.mk', 'dev/tools/metal_verify_variant.py']:
        assert hashlib.sha256((tree / name).read_bytes()).hexdigest() == expected, 'validated source changed: ' + name
jobs = ['build-runtime16-v12', 'runtime16-v12-q8-flash-attention-shader',
        'runtime16-v12-q8-chunked-prefill-shader', 'runtime16-v12-linear-plan-shader',
        'runtime16-v12-target-sampling-shader', 'runtime16-v12-target-sampling16-shader',
        'runtime16-v12-gdn-decode16-shader', 'runtime16-v12-attention-variants-shader',
        'runtime16-v12-attention-variants16-shader', 'runtime16-v12-draft-attention16-shader',
        'runtime16-v12-vision-metal-shader', 'runtime16-v12-vision-attention-shader',
        'runtime16-v12-pressure-serving-shader', 'runtime16-v12-metal-backend-shader-v2',
        'runtime16-v12-handoff-shader-v2', 'register16-oracle-v1', 'core-v12-smoke-r8', 'core-v12-smoke-r16']
receipts = []
for name in jobs:
    p = root / 'results' / f'{name}.receipt.json'
    receipt = json.loads(p.read_text())
    assert receipt['exit_code'] == 0 and receipt['state'] == 'complete', name + ' did not pass'
    receipts.append({'job': name, 'receipt_sha256': hashlib.sha256(p.read_bytes()).hexdigest(),
                     'elapsed_seconds': receipt.get('elapsed_seconds')})


def outputs(name):
    d = json.loads((root / 'results' / f'{name}.stdout').read_text())
    return {m['scenario']: m['output_tokens'] for m in d['measurements']}


assert outputs('core-v12-smoke-r8') == outputs('calibration-baseline8-smoke3-v9')
assert outputs('core-v12-smoke-r16') == outputs('native-smoke-dspine16-v10')
record = {
    'schema_version': 1, 'utc': dt.datetime.now(dt.timezone.utc).isoformat(),
    'baseline_commit': '425ad7400f3a00d2a1e6745bdacfa2881922d544',
    'validated_patch_sha256': manifest['patch_sha256'],
    'source_manifest_sha256': manifest['source_manifest_sha256'],
    'fix': 'Separate active seven/fifteen-token physical KV limits from the maximum host allocation. Explicit sixteen-row validation cannot loosen the default eight-row limit. Reject forced register plans beyond four physical eight-row tiles after existing configuration checks.',
    'independent_checks': 'Full native CPU suite, explicit final logical/physical boundaries at both widths, forced register-height rejection, representative AF4G64/Q4K/IQ4XS/BF16 register16 FP64/guard/lane oracle, corrected full Q8 attention and chunked-prefill shader suites, affected sixteen-row suites and complete short native arrays.',
    'short_arrays': {'rows8_matches_committed_baseline': True, 'rows16_matches_prior16': True,
                     'cases': 3, 'output_cap': 64, 'scope': 'Finite historical calibration; not long-context or distributional equivalence.'},
    'retained_failures': [
        'v10 broad run reached40min timeout after projection and all three MoE suites passed; component continuation found default Q8 validation admitted fifteen scratch tokens instead of seven.',
        'v11 CPU linear-plan golden error check caught guard precedence for invalid prefill/register plans; v12 restores the previous validation order.',
        'Initial v12 backend/handoff jobs had missing standalone test libraries; the explicit library build and v2 jobs above completed the checks.'
    ],
    'limitations': ['Eight rows remain default; sixteen is experimental and restricted to supported dense DSpine configurations.',
                    'No speed qualification claimed here. Three-group comparisons and fresh sampling/agent screens are separate.',
                    'No general cold/warm token equivalence claim: an old long-prefix calibration diverges in the committed baseline too.',
                    'Register kernels were exercised on this M5 Pro; no physical Apple9 device was available.',
                    'The original broad-suite timeout/failure receipts remain; final combined-source broad validation is still planned.'],
    'receipts': receipts,
}
path = tree / 'dev/benchmarks/results/dspine-runtime-boundaries-2026-11-10.json'
path.write_text(json.dumps(record, indent=2) + '\n')
allowed = ['dev/tests/engine/execution_plans_test.cc', 'dev/tests/engine/linear_plan_test.mm',
           'runtime/metal/abi/ExecutionGeometry.h', 'runtime/model/KvHistoryStream.cpp',
           'runtime/model/RuntimeArenas.hpp', 'runtime/ops/LinearGguf.cpp',
           'runtime/ops/PagedAttention.cpp', 'runtime/ops/PagedAttention.hpp', 'runtime/ops/PagedKv.hpp',
           str(path.relative_to(tree))]
changed = subprocess.check_output(['git', '-C', str(tree), 'status', '--porcelain'], text=True).splitlines()
assert {line[3:] for line in changed} == set(allowed), 'unexpected files in the local core worktree'
subprocess.run(['git', '-C', str(tree), 'diff', '--check'], check=True)
subprocess.run(['git', '-C', str(tree), 'add', '--', *allowed], check=True)
subprocess.run(['git', '-C', str(tree), 'diff', '--cached', '--check'], check=True)
subprocess.run(['git', '-C', str(tree), 'commit', '-m', 'fix(ops): preserve per-geometry KV and register bounds'], check=True)
commit = subprocess.check_output(['git', '-C', str(tree), 'rev-parse', 'HEAD'], text=True).strip()
(root / 'notes/core-boundary-commit-v12.json').write_text(json.dumps({'commit': commit, 'report': str(path)}, indent=2) + '\n')
print(commit)

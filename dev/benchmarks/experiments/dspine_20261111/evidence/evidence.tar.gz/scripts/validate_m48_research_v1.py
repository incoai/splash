"""Require actual native selection and complete cloned arrays before timing M48."""
from pathlib import Path
import datetime as dt
import hashlib
import json
import re

root = Path(__file__).resolve().parents[1]
required = ['af4-m48-oracle-v3', 'af4-m48-diagnostic-v3', 'build-m48-research-v1',
            'build-study-m48-research-v1-v2', 'm48-research-b3-functional-v1',
            'm48-research-activity-v1', 'final-clone-b3-v1']
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
receipts = {}
for ident in required:
    path = root / 'results' / (ident + '.receipt.json')
    value = json.loads(path.read_text())
    assert value['state'] == 'complete' and value['exit_code'] == 0, ident
    assert value['artifact_sha256'] == value['artifact_sha256_after'], ident
    receipts[ident] = sha(path)


def arrays(ident):
    value = json.loads((root / 'results' / (ident + '.stdout')).read_text())
    cases = value['decode_throughput']['samples']
    assert len(cases) == 3 and all(v['width'] == 3 for v in cases)
    return {v['scenario']: v['lane_outputs'] for v in cases}


before, after = arrays('final-clone-b3-v1'), arrays('m48-research-b3-functional-v1')
assert before == after and len(before) == 3
assert all(len(v) == 3 and all(lane == v[0] and len(lane) == 64 for lane in v) for v in after.values())
profile = (root / 'results/m48-research-activity-v1.stdout').read_text()
blocks = re.split(r'^== B([1-4]) decode cycle:.*?==\s*$', profile, flags=re.MULTILINE)
assert len(blocks) == 9
activity = {}
for i in range(1, 9, 2):
    width, text = int(blocks[i]), blocks[i + 1]
    calls = {name: float(count) for name, count in re.findall(r'^(gguf_decode_af4g64_m48_[ag])\s+([0-9.]+)\s', text, re.MULTILINE)}
    if width == 3:
        assert calls == {'gguf_decode_af4g64_m48_a': 69.0, 'gguf_decode_af4g64_m48_g': 69.0}, calls
    else:
        assert not calls, (width, calls)
    activity[str(width)] = calls
build_path = root / 'artifacts/m48-research-v1/build.json'
build = json.loads(build_path.read_text())
assert build['patch_sha256'] == sha(root / 'patches/m48-research-v1.patch')
for relative, digest in build['source_manifest'].items():
    assert sha(root / 'm48-research-v1' / relative) == digest, relative
record = {'validated_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
    'variant': 'm48-research-v1', 'source_nominated_for_research_comparison': True,
    'required_receipts': required, 'receipt_sha256': receipts, 'all_nine_complete_lane_arrays_match': True,
    'actual_pipeline_activity_by_width': activity, 'profile_timing_usable': False,
    'profile_timing_limit': 'Unpaired diagnostic profile without registered ABBA/idle gates. Only pipeline names/counts are used as selection evidence.',
    'patch_sha256': build['patch_sha256'], 'source_manifest_sha256': build['source_manifest_sha256'],
    'build_manifest_sha256': sha(build_path),
    'scope': 'Separate research comparison eligibility only. Does not enter the final serving source or fresh agent12/sampling4 arms.'}
path = root / 'notes/m48-research-v1-comparison-eligibility.json'
assert not path.exists()
path.write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record, indent=2))

"""Derive a diagnostic instrumented driver; production timing code is unchanged."""
from pathlib import Path
root = Path(__file__).resolve().parents[1]
source = (root / 'scripts/study_driver_v2.mm').read_text()
source = source.replace('#ifndef SPLASH_BUILD_ID', '#include \"probe_support_v2.hpp\"\n\n#ifndef SPLASH_BUILD_ID')
source = source.replace('    ++batchSequence_;', '''    ++batchSequence_;
    if (activeLogitProbe) activeLogitProbe->batch(kind, width, outputTokens, acceptedDraftTokens);''')
needle = '  const auto began = Clock::now();\n  engine.submit(std::move(request));'
assert source.count(needle) == 1
source = source.replace(needle, '''  std::unique_ptr<LogitProbe> probe;
  if (const char *directory = std::getenv("SPLASH_LOGIT_PROBE")) {
    auto *runtime = dynamic_cast<model::Runtime *>(&executor);
    if (!runtime) throw std::runtime_error("no concrete runtime for diagnostic");
    probe = std::make_unique<LogitProbe>(*runtime, directory, scenario, sample, maxNewTokens,
        uint32_t(model::RuntimeInstrumentation::lastLogits(*runtime, 0).size() / activeRows(executor)));
    activeLogitProbe = probe.get();
  }
  const auto began = Clock::now();
  engine.submit(std::move(request));''')
needle = '  const Observation &observed = events.get(requestId);\n  if (!observed.completed'
assert source.count(needle) == 1
source = source.replace(needle, '''  const Observation &observed = events.get(requestId);
  activeLogitProbe = nullptr;
  if (probe) probe->validate(observed.outputTokens);
  if (!observed.completed''')
(root / 'scripts/study_logit_probe_v2.mm').write_text(source)
print('Prepared diagnostic source; capture/argmax mapping must validate before inference')

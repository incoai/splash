"""Freeze kernel-only comparisons before the first controlled timing output."""
from pathlib import Path
import datetime as dt
import hashlib
import json

root = Path(__file__).resolve().parents[1]
cohort = root / 'cohorts/kernel-smoke3-cap256-v1.txt'
assert not cohort.exists(), 'protocol already frozen'
lines = []
for raw in (root / 'cohorts/calibration-smoke3-v1.txt').read_text().splitlines():
    fields = raw.split()
    fields[1] = '256'
    lines.append(' '.join(fields))
cohort.write_text('\n'.join(lines) + '\n')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


queue = root / 'queue.jsonl'
jobs = [json.loads(x) for x in queue.read_text().splitlines()]
for label, candidate, width, requires in [
    ('wide-gateup-b3-v1', 'wide-gateup-v1', 3, ['gateup-same-split-oracle-v1']),
    ('wide-gateup-b4-v1', 'wide-gateup-v1', 4, ['gateup-same-split-oracle-v1']),
    ('fused-af4-b1-v1', 'fused-af4-v1', 1, ['fused-af4-oracle-v1']),
]:
    protocol = {
        'frozen_utc': dt.datetime.now(dt.timezone.utc).isoformat(), 'prefix': label,
        'groups': 3, 'order_each_group': ['control', 'candidate', 'candidate', 'control'],
        'control': 'runtime16-v10', 'candidate': candidate, 'geometry': 16, 'clone_width': width,
        'cohort': str(cohort), 'cohort_sha256': sha(cohort), 'cases': 3, 'output_cap': 256,
        'samples_per_round': 3, 'criterion': 'improvement', 'context_tokens': 32768,
        'ane_ffn_share': 0, 'temperature': 0, 'verify_rows': 'all',
        'primary_metric': 'serial (wall-TTFT)/(tokens-1) at B1; GPU-stream decode wall/decode outputs at clone B3/B4',
        'aggregation': 'Median across exactly three internal repetitions for each case, then token-weighted aggregate. All cases receive per-case ABBA and output checks.',
        'gates': 'Exactly three ABBA groups; all complete raw greedy arrays match; all per-case and aggregate spreads <=5%; aggregate MPT decrease > max(2%, 2*measured spread); all operating gates including sampled AC pass. No repeat-to-pass or subgroup deletion.',
        'operating_script_sha256': sha(root / 'scripts/controlled_round.py'),
        'analyzer_sha256': sha(root / 'scripts/analyze_abba_v1.py'),
        'abba_sha256': sha(root / 'scripts/abba.py'),
        'scope': 'Kernel-only comparison within the same sixteen-row runtime. Historical three software prompts are calibration data, not the fresh heldout agent or sampling cohorts.',
        'artifact_nomination': {},
    }
    for variant in ['runtime16-v10', candidate]:
        bundle = root / 'artifacts' / f'study-{variant}-v2'
        manifest = root / 'artifacts' / variant / 'build.json'
        # The fused build is still queued. Its immutable full patch and build
        # receipt are nominated now; an execution preflight freezes generated
        # artifact hashes before the first timed round is permitted.
        protocol['artifact_nomination'][variant] = {
            'patch': str(root / 'patches' / f'{variant}.patch'),
            'patch_sha256': sha(root / 'patches' / f'{variant}.patch'),
            'build_manifest': str(manifest),
            'driver': str(bundle / 'study-driver'), 'library': str(bundle / 'splash.metallib'),
            'host_step': str(bundle / 'host-step.metallib'),
        }
    path = root / 'notes' / f'{label}.protocol.json'
    path.write_text(json.dumps(protocol, indent=2) + '\n')
    preflight = 'freeze-artifacts-' + label
    jobs.append({'id': preflight,
                 'command': ['python3', str(root / 'scripts/freeze_abba_artifacts_v1.py'), str(path)],
                 'artifacts': [str(path), str(root / 'scripts/freeze_abba_artifacts_v1.py')],
                 'requires': requires + ['build-study-runtime16-v10-v2', f'build-study-{candidate}-v2'],
                 'timeout_seconds': 60})
    for group in range(1, 4):
        for suffix in ['a1', 'b1', 'b2', 'a2']:
            variant = 'runtime16-v10' if suffix.startswith('a') else candidate
            bundle = root / 'artifacts' / f'study-{variant}-v2'
            ident = f'{label}-g{group}-{suffix}'
            command = [str(bundle / 'study-driver'), str(bundle / 'splash.metallib'),
                       Path('/Users/linson/Documents/ai/splash/build/dspine/model-root.txt').read_text().strip(),
                       '--draft-block-size', '16', '--cohort', str(cohort), '--samples', '3',
                       '--study-width', str(width), '--ane-ffn-share', '0', '--max-context', '32768',
                       '--progress', str(root / 'results' / f'{ident}.progress.jsonl')]
            jobs.append({'id': ident,
                         'command': ['python3', str(root / 'scripts/run_frozen_abba_round_v1.py'), str(path), ident, *command],
                         'artifacts': [str(bundle / 'study-driver'), str(bundle / 'splash.metallib'), str(cohort),
                                       str(path), str(root / 'scripts/controlled_round.py'),
                                       str(root / 'scripts/run_frozen_abba_round_v1.py')],
                         'requires': [preflight], 'timeout_seconds': 1500,
                         'classification': 'controlled qualified comparison, no builds or other owned GPU jobs'})
    jobs.append({'id': 'analyze-' + label,
                 'command': ['/Users/linson/Documents/ai/splash/.venv/bin/python',
                             str(root / 'scripts/analyze_abba_v1.py'), str(path),
                             str(root / 'results' / f'{label}.comparison.json')],
                 'artifacts': [str(path), str(root / 'scripts/analyze_abba_v1.py'), str(root / 'scripts/abba.py')],
                 'timeout_seconds': 60})
temp = queue.with_suffix('.tmp')
temp.write_text(''.join(json.dumps(x) + '\n' for x in jobs))
temp.replace(queue)
print('Froze three kernel comparisons, exactly three ABBA groups each')

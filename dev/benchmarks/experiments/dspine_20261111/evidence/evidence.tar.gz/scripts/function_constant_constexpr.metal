#include <metal_stdlib>
using namespace metal;
constant uint width [[function_constant(201)]];
template<uint N> inline void use(device float *out,uint tid){out[tid]=N;}
kernel void probe(device float *out [[buffer(0)]], uint tid [[thread_index_in_threadgroup]]){constexpr uint rows=width; out[tid]=float(rows);}

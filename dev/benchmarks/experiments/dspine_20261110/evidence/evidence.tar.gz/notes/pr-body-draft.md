Tencent's Qwen3.8-27B DSpine checkpoint is rejected by the DFlash2-only loader. This adds an opt-in native Metal backend through `--draft-model`: causal draft attention, learned bridge writes, parallel final-write refinement, and the conditional proposal probabilities consumed by the existing verifier. Cache restore and window sizing preserve DSpine's 8,192-token draft window. The native benchmark now honors that configured window as serving already does.

**Experimental: the serving implementation uses eight rows of a checkpoint trained for sixteen. DFlash2 remains the default.** Sixteen-row execution is included as reproducible research patches, with explicit rollout blockers.

## Measured results

Apple M5 Pro, 20-core GPU, 48 GB, macOS 26.6; the same affine 4-bit Qwen3.8-27B target for both drafters. All 66 loaded target images are byte-identical. Draft backbones use affine 4-bit groups of 64; DSpine's bridge stays BF16. INT8 KV, FP32 recurrent state, ANE disabled, 32K configured context. DFlash2 retains its 2,048-token draft window; DSpine retains 8,192.

| Comparison | Measured result | Scope/verdict |
| --- | --- | --- |
| Parallel versus initial serial DSpine refinement | 77.0 → 82.4 tok/s, **+7.1%** | Four coding prompts, HTTP solo ABBA; outputs and cycle counts unchanged, 1.1% spread |
| Serving DS8 versus DF8 on the parallel build | 86.2 → 81.2 tok/s, **−5.8%** solo; **−12.4%** four-concurrent end-to-end | Earlier four-prompt comparison; exploratory workload, not a general ranking |
| Research DS16 versus DS8 with M16 policy | **+16.19%, +15.32%, +16.04%** native serial throughput | Three fixed ABBA groups, 30 primary short-prompt tasks plus a separate count control; all registered output/noise/thermal gates passed |
| Research DS16 versus DF8+M16, short native corpus | +18.3–18.9% aggregate TPS, descriptive | 30 primary short-prompt tasks; all outputs match, but groups 1/2 fail per-case noise gates; **not qualified** |
| Research DS16 versus DF8+M16, long native corpus | **+6.0–7.0%** aggregate decode TPS | Two frozen repository-source contexts (8K prose / 16K code); all three registered groups pass; prose −3.5%, code +17–19% |
| Research DS16 versus DF8+M16, HTTP | Inconclusive in all three groups | 11–46% endpoint spread and batch-width-dependent target outputs; all trials retained |

The eight-hour study ran November 10, 03:18:48–11:18:48 UTC, with serial owned GPU jobs and continuous hardware observations. Power source varied: the DS16/DS8 first group had AC/battery transitions; the following two groups stayed on AC at recorded boundaries. Registered native gates did not require AC, so results retain that additional limitation. The final direct drafter comparisons started on battery; detailed round-boundary power observations accompany their verdicts. No noisy/failed group was dropped or repeated to obtain a pass.

DS16 reduces the primary cycle count from 1,303 to 1,062 at identical outputs. Its recorded wall per cycle rises about 5.9%, while tokens per cycle rise about 22.7%. Some prose requests regress by about 3–6%; fresh twelve-case output agreement and acceptance screens are separate from throughput qualification. Higher draft precision changes acceptance little here (4-bit 1,303 cycles, native BF16 planes 1,289), and does not reproduce the upstream BF16 arithmetic/training target.

On 67 matched short primary prefixes, mean first-cycle output counts are DF8 **5.955**, DS8 **5.940**, DS16 **9.507**; all 71 full continuations including controls match. DS8 wins eight, loses eight and ties 51 prefixes. These overlapping calibration prefixes do not establish a general acceptance gap or forecast TPS. [Community feedback](https://github.com/incoai/splash/pull/731#issuecomment-6761876716) reports stronger DSpine acceptance on a different real-agent/reference setup; those external results are unverified here and motivate independent agent-history and conditional-probability parity checks.

At concurrency, 16 rows × four lanes exposes an expensive M64 gate/up path. The existing two-pass alternative is the simplest candidate to calibrate. Its descriptive HTTP gain did not qualify: two groups failed strict output equality. A same-binary diagnostic reproduces target output variation with physical batch width under both policies, while policy outputs agree at each fixed width. A separate forced target-logit probe shows an argmax flip at a small margin; it does not identify the exact original state or responsible operator. Smaller GDN storage and shared projection/gate-up experiments passed numerical checks but did not establish application throughput gains.

## Validation and limits

- Shipping eight-row implementation: production/native builds, CPU and architecture checks, independent GPU-validated bridge/refinement equations at widths 1–4, and focused Python suites (33 tests). Initial installer/launcher checks: 285 tests (8 skipped) and 54 tests.
- Shipping serving: greedy/sampled/schema output, four concurrent requests, long-prefix reuse, disk restore, cancellation and follow-up generation; relevant checks also ran under Metal validation.
- Research sixteen-row candidate: 9,000 cold B1 sampled requests, 78 tests with no rejection after Holm correction over the reserved 234-test family. This is a finite early-token regression screen, not equivalence; no EOS termination was exercised.
- Research lifecycle: Metal-validated 15,928-token cold/warm/suffix/disk restore and actual priority suspension/replay in five cases, all complete output arrays matching. The separate synthetic memory-pressure probe did not trigger suspension.
- Fresh portable wide-policy rebuild, DSpine/draft-attention/plain16 GDN shader oracles and model smoke passed. **The original prototype's full Table16 sixteen-row GDN test fails an out-of-bounds store.** A later packing-only follow-up passes the full sixteen-row GDN suite under Metal validation, with unchanged tolerances. Register selection remains disabled; consumers still require explicit eight-row tile dispatch/fallback and separate qualification.

The long native comparison measures decode only: summed cold request-wall means improve just **0.91% descriptively** (61.185→60.633 s), because 15–34 s prefill dominates. Its four original source prompts were narrowed to the 8K/16K pair before any of those prompts ran, to fit all three groups inside eight hours; both protocols are retained.

Next implementation: carry per-model geometry through planning, buffers, sampling and pipeline identities; adopt the packing repair and correct or reject unsupported register dispatch; account for about **260.7 MiB** extra capacity only on enabled DSpine models; calibrate wide gate/up; then qualify batch-dependent width selection on new workloads. Global macro replacement and research environment variables are not proposed serving defaults.

[Full eight-hour report and reproduction instructions](https://github.com/linson007/splash/blob/experimental/dspine/dev/benchmarks/experiments/dspine_20261110/README.md) · [Result index](https://github.com/linson007/splash/blob/experimental/dspine/dev/benchmarks/results/dspine-investigation-qwen38-27b-2026-11-10.json) · [Evidence manifest](https://github.com/linson007/splash/blob/experimental/dspine/dev/benchmarks/experiments/dspine_20261110/evidence/evidence-manifest.json) · [Earlier refinement results](https://github.com/linson007/splash/blob/experimental/dspine/docs/performance.md#parallel-dspine-refinement)

A single unrotated vocabulary projection is required.

```sh
./splash serve --model mlx-community/Qwen3.8-27B-4bit \
  --draft-model tencent/Qwen3.8-27B-DSpine-b16
```

Refs #724.

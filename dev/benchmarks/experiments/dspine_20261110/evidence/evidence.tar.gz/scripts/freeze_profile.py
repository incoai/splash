from pathlib import Path
import hashlib, json, shutil, sys
r = Path(__file__).resolve().parents[1]
name = sys.argv[1]; tree = r/name
out = r/'artifacts'/('profile-'+name+'-v1'); out.mkdir(exist_ok=False)
files = ['engine-tests/decode-profile', 'splash.metallib', 'host-step.metallib']
record = {}
for f in files:
    p = tree/'build'/f; dest = out/Path(f).name
    before = hashlib.sha256(p.read_bytes()).hexdigest(); shutil.copy2(p, dest)
    assert before == hashlib.sha256(dest.read_bytes()).hexdigest() == hashlib.sha256(p.read_bytes()).hexdigest()
    record[f] = before
(out/'manifest.json').write_text(json.dumps(record, indent=2)+'\n')
print(out)

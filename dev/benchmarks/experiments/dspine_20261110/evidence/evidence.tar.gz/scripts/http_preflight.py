"""Loopback-only native16 transport/mask/concurrency/cancellation preflight."""
from pathlib import Path
import concurrent.futures, hashlib, json, os, signal, subprocess, sys, threading, time, urllib.request
sys.path.insert(0, '/Users/linson/Documents/ai/splash')
from dev.tests import smoke_real as smoke
from dev.benchmarks.draft_comparison import PROMPTS
r = Path(__file__).resolve().parents[1]
ident, binary = sys.argv[1:]
directory = r/'http'/ident; directory.mkdir(parents=True, exist_ok=False)
root = Path('/Users/linson/Documents/ai/splash/build/dspine/model-root.txt').read_text().strip()
port = smoke.available_port(); model = 'local/dspine-preflight'
command = [sys.executable, '-m', 'server.server', root, '--binary', binary, '--model', model,
           '--host', '127.0.0.1', '--port', str(port), '--max-context', '32768', '--kv-format', 'int8',
           '--state-format', 'fp32', '--disable-ane', '--verify-rows', 'all', '--persistent-cache',
           '--cache-dir', str(directory/'cache'), '--max-cache-disk', '4G']
record = {'id': ident, 'binary': binary, 'command': command, 'shader_validation': os.environ.get('MTL_SHADER_VALIDATION'), 'checks': []}
record_lock = threading.RLock()
def save():
    with record_lock:
        tmp = directory/'result.json.tmp'; tmp.write_text(json.dumps(record, indent=2)+'\n'); tmp.replace(directory/'result.json')
def request(name, prompt, **options):
    body = smoke.chat_body(model, prompt, max_completion_tokens=96, seed=1729, cache_salt=ident+'-'+name)
    body.update(options)
    code, response = smoke.request(port, 'POST', '/v1/chat/completions', body, timeout=180)
    smoke.require(code == 200, f'{name}: HTTP {code}: {response}')
    text = response['choices'][0]['message']['content']; smoke.require(bool(text), name+': empty output')
    (directory/(name+'.json')).write_text(json.dumps(response, indent=2)+'\n')
    summary = {'name': name, 'output_sha256': hashlib.sha256(text.encode()).hexdigest(),
               'usage': response['usage'], 'speculation': response['metrics']['speculation']}
    with record_lock: record['checks'].append(summary); save()
    print(json.dumps(summary), flush=True)
    return response
with (directory/'server.log').open('w') as log:
    server = subprocess.Popen(command, cwd='/Users/linson/Documents/ai/splash', stdout=log, stderr=subprocess.STDOUT)
    record['server_pid'] = server.pid; save()
    try:
        deadline = time.monotonic()+300
        while time.monotonic() < deadline:
            smoke.require(server.poll() is None, 'preflight server exited during startup')
            try:
                code, status = smoke.request(port, 'GET', '/status', timeout=1)
                if code == 200 and status.get('ready'): break
            except (OSError, smoke.SmokeFailure): pass
            time.sleep(0.5)
        else: raise RuntimeError('startup timeout')
        smoke.validate_status(status, 'int8'); record['status_start'] = status; save()
        greedy = request('greedy', PROMPTS[0])
        spec = greedy['metrics']['speculation']
        smoke.require(spec['drafted_tokens'] > 7*spec['cycles'], 'did not observe wider-than8 proposal blocks')
        request('sampled', PROMPTS[0], temperature=0.8, top_p=0.95, top_k=20, max_completion_tokens=64)
        schema = {'type': 'object', 'properties': {'language': {'type': 'string', 'enum': ['python']},
                   'count': {'type': 'integer', 'enum': [3]}}, 'required': ['language', 'count'], 'additionalProperties': False}
        for temperature in [0, 1]:
            response = request('schema'+str(temperature), 'Return language python and count 3.', temperature=temperature,
                       response_format={'type': 'json_schema', 'json_schema': {'name': 'result', 'strict': True, 'schema': schema}})
            smoke.require(json.loads(response['choices'][0]['message']['content']) == {'language': 'python', 'count': 3}, 'schema value mismatch')
        with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
            futures = [pool.submit(request, 'concurrent'+str(i), prompt, max_completion_tokens=64) for i, prompt in enumerate(PROMPTS)]
            for f in futures: f.result()
        before = smoke.runtime_status(port)
        body = smoke.chat_body(model, 'Write a long tutorial about implementing a database in Python.',
                               max_completion_tokens=2048, temperature=0.7, stream=True, cache_salt=ident+'-cancel')
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
        req = urllib.request.Request(f'http://127.0.0.1:{port}/v1/chat/completions', data=json.dumps(body).encode(),
                                     headers={'Content-Type': 'application/json'})
        with opener.open(req, timeout=180) as response:
            for line in response:
                if not line.startswith(b'data: ') or line.startswith(b'data: [DONE]'): continue
                event = json.loads(line[6:])
                if any(c.get('delta', {}).get('content') for c in event.get('choices', [])): break
            else: raise RuntimeError('cancel stream produced no content')
        response = request('after_cancel', 'Reply with exactly OK.', max_completion_tokens=16)
        smoke.require('OK' in response['choices'][0]['message']['content'], 'request after cancellation failed')
        deadline = time.monotonic()+15
        while True:
            status = smoke.runtime_status(port)
            if status['requests']['cancelled'] > before['requests']['cancelled'] and status['transport']['pending'] == 0: break
            smoke.require(time.monotonic() < deadline, 'stream cancellation did not settle')
            time.sleep(0.25)
        smoke.validate_status(status, 'int8'); record['status_end'] = status; record['passed'] = True; save()
        print('HTTP16 preflight passed', flush=True)
    finally:
        if server.poll() is None: server.send_signal(signal.SIGINT)
        try: server.wait(timeout=30)
        except subprocess.TimeoutExpired:
            server.terminate()
            try: server.wait(timeout=10)
            except subprocess.TimeoutExpired: server.kill(); server.wait(timeout=10)
        record['server_exit_code'] = server.returncode; save()

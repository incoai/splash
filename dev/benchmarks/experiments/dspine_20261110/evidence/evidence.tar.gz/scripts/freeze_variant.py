from pathlib import Path
import hashlib,json,shutil,subprocess,sys
r=Path(__file__).resolve().parents[1];name=sys.argv[1];tree=r/name;out=r/'artifacts'/('frozen-'+name+'-v1');out.mkdir(exist_ok=False);record={}
# These are exactly the explicitly built targets for the phased variants.
for file in ['splash','splash.metallib','host-step.metallib','engine-tests/gdn-decode','engine-tests/weight-digests','engine-tests/decode-profile','engine-tests/backend-benchmark']:
 source=tree/'build'/file;dest=out/file;dest.parent.mkdir(parents=True,exist_ok=True);before=hashlib.sha256(source.read_bytes()).hexdigest();shutil.copy2(source,dest);assert before==hashlib.sha256(dest.read_bytes()).hexdigest()==hashlib.sha256(source.read_bytes()).hexdigest();record[file]=before
patch=subprocess.check_output(['git','-C',str(tree),'diff','--binary']);(out/'source.patch').write_bytes(patch);record['source_patch_sha256']=hashlib.sha256(patch).hexdigest();(out/'manifest.json').write_text(json.dumps(record,indent=2)+'\n');print(out)

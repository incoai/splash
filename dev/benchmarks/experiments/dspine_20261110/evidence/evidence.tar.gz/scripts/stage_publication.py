"""Copy only owned final research assets into the main checkout, preserving user work."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess

root=Path(__file__).resolve().parents[1]
repo=Path('/Users/linson/Documents/ai/splash')
package=root/'publication/experiments/dspine_20261110'
index=root/'publication/results/dspine-investigation-qwen38-27b-2026-11-10.json'
assert json.loads(index.read_text())['status']=='complete'
owned=json.loads((root/'notes/main-staging-manifest.json').read_text())['files']
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
for name, expected in owned.items():
    path=repo/name
    assert path.exists() and sha(path)==expected,'Unexpected edit to owned staging asset: '+name
paths=[]
for source in sorted(package.rglob('*')):
    if not source.is_file() or '__pycache__' in source.parts or '.ruff_cache' in source.parts:continue
    assert not source.is_symlink()
    name='dev/benchmarks/experiments/dspine_20261110/'+str(source.relative_to(package))
    destination=repo/name
    if destination.exists() and name not in owned:
        assert sha(source)==sha(destination),'Unexpected new destination: '+name
    destination.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(source,destination)
    assert sha(source)==sha(destination)
    paths.append(name)
name='dev/benchmarks/results/'+index.name
destination=repo/name
if destination.exists():assert sha(destination)==sha(index),'Unexpected existing result index'
shutil.copy2(index,destination)
paths.extend([name,'docs/performance.md'])
# Explicit file lists avoid accidentally adding preexisting desktop/ or another new file.
subprocess.run(['git','-C',str(repo),'add','--',*paths],check=True)
(root/'publication/commit-paths.json').write_text(json.dumps(paths,indent=2)+'\n')
print(json.dumps({'owned_files_copied_and_staged':len(paths),'source_head':subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),'preexisting_desktop_preserved':(repo/'desktop').exists()},indent=2))

"""Prepare source-only public reproduction assets; never touches model/binary artifacts."""
from pathlib import Path
import ast,difflib,hashlib,json,shutil,subprocess
r=Path(__file__).resolve().parents[1];out=r/'publication/experiments/dspine_20261110'
for directory in ['patches','sources','cohorts','protocols']:(out/directory).mkdir(parents=True,exist_ok=True)
variants=['m16-policy','precision','bridge-parity','head-quant','block16','wide-policy','gateup-tiles','gdn-compact','gdn-phased8','gdn-phased16','gateup-shared8','gateup-shared16','linear-shared16'];manifest={'base':'33a488d4bbb3978b32b34e8bfc6cefa92e350d7f','files':{}}
for name in variants:
 patch=subprocess.check_output(['git','-C',str(r/name),'diff','--binary']);(out/'patches'/(name+'.patch')).write_bytes(patch)
patch=subprocess.check_output(['git','-C','/Users/linson/Documents/ai/splash','diff','33a488d4bbb3978b32b34e8bfc6cefa92e350d7f','0a90d7b4caf725ee4f27afcd37f6d827d05a6300','--','dev/benchmarks/backend_benchmark.mm']);(out/'patches/control.patch').write_bytes(patch)
for name in ['study_driver.mm','gateup_tile_oracle.mm','gateup_shared_oracle.mm','linear_shared_oracle.mm','bridge_norm_oracle.mm','native_group_quantize.mm','pipeline_resources.mm','operating_state.mm']:
 shutil.copy2(r/'scripts'/name,out/'sources'/name)
p=out/'sources/gdn_plain16_oracle.mm';s=(r/'scripts/gdn_plain16_oracle.mm').read_text();first=next(line for line in s.splitlines() if line.startswith('#include "'));s=s.replace(first,'#include DSPINE_GDN_ORACLE_SOURCE');p.write_text(s)
for name in ['cohort31.txt','heldout12.txt','heldout12-prompts.json','sampling3-v2.txt','fixed-prefixes.txt','suspension5.txt','geometry-boundaries9.txt','long-code4.txt','long-code2-v2.txt']:
 shutil.copy2(r/'notes'/name,out/'cohorts'/name)
for name in ['cohort-protocol.json','m16-abba-protocol.json','block16-vs-m16-abba-protocol.json','heldout12-protocol.json','sampling-protocol.json','sampling-protocol-v1-archived.json','sampling-nominations.json','http-final-abba-protocol.json','native-dflash-vs-dspine16-protocol.json','fixed-prefixes-protocol.json','gateup-row-tiles-protocol.json','gdn-compact-protocol.json','gdn-compact-paired-protocol.json','gdn-phased-hypothesis.json','priority-preemption-protocol.json','target-feature-parity-protocol.json','improvement-plan-v2.json','improvement-plan-v3.json','gateup-shared-hypothesis.json','linear-shared-hypothesis.json','long-context-profile-protocol.json','geometry-boundaries-protocol.json','long-code4-protocol.json','long-code2-v2-protocol.json','external-feedback-20261110.json','matched-drafter-followup-protocol.json','table16-layout-followup-protocol.json','table16-consumer-audit.json']:
 shutil.copy2(r/'notes'/name,out/'protocols'/name)
followup=r/'patches/table16-layout-followup.patch'
if followup.exists():
 (out/'followups').mkdir(exist_ok=True);shutil.copy2(followup,out/'followups'/followup.name)
 files=['runtime/ops/Linear.cpp','runtime/metal/kernels/decode/gdn.metal','dev/tests/engine/LinearInputReference.hpp'];delta=[];pins={}
 for name in files:
  before=(r/'wide-policy'/name).read_bytes();after=(r/'table16-layout-followup'/name).read_bytes();pins[name]={'before_sha256':hashlib.sha256(before).hexdigest(),'after_sha256':hashlib.sha256(after).hexdigest()}
  delta.extend(difflib.unified_diff(before.decode().splitlines(keepends=True),after.decode().splitlines(keepends=True),fromfile='a/'+name,tofile='b/'+name))
 (out/'followups/table16-packing-only.patch').write_text(''.join(delta))
 (out/'followups/table16-packing-files.json').write_text(json.dumps({'base':'wide-policy variant before packing repair','files':pins,'scope':'Three-file review delta only; full rebuildable diff against33a is table16-layout-followup.patch. Register paths remain disabled.'},indent=2)+'\n')
for p in sorted(out.rglob('*')):
 if p.is_file() and p.name!='source-manifest.json' and '__pycache__' not in p.parts and '.ruff_cache' not in p.parts and 'evidence' not in p.relative_to(out).parts:manifest['files'][str(p.relative_to(out))]={'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
(out/'source-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
for p in out.rglob('*.py'):ast.parse(p.read_text())
print(json.dumps({'files':len(manifest['files']),'bytes':sum(x['bytes'] for x in manifest['files'].values())}))

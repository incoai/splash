"""Report predeclared long-context cold latency separately from decode qualification."""
from pathlib import Path
import hashlib,json,statistics
r=Path(__file__).resolve().parents[1]
a={};b={};totals={'DF8M16':[],'DS16':[]};sources={}
for group in range(1,4):
 for suffix in ['a1','b1','b2','a2']:
  p=r/f'results/native-long-dflash-vs-dspine16-abba-g{group}-{suffix}.stdout'
  d=json.loads(p.read_text());sources[str(p.relative_to(r))]=hashlib.sha256(p.read_bytes()).hexdigest()
  arm='DF8M16' if suffix.startswith('a') else 'DS16';target=a if arm=='DF8M16' else b
  totals[arm].append(sum(m['wall_ms'] for m in d['measurements']))
  for m in d['measurements']:target.setdefault(m['scenario'],[]).append(m['ttft_ms'])
means={k:statistics.mean(v) for k,v in totals.items()}
out={'scope':'Cold TTFT and summed recorded request-wall descriptive means, six requests per arm/case. Model initialization is outside recorded request wall. Decode is the registered qualified endpoint; no separate cold end-to-end qualification claim.',
 'cases':{k:{'DF8M16_ttft_mean_ms':statistics.mean(v),'DS16_ttft_mean_ms':statistics.mean(b[k]),'baseline_samples':v,'candidate_samples':b[k]} for k,v in a.items()},
 'summed_two_request_wall_mean_ms':means,'descriptive_total_request_throughput_change':means['DF8M16']/means['DS16']-1,'sources':sources}
(r/'results/long-context-ttft-descriptive.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k not in ['sources','cases']},indent=2))

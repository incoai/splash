"""Compare first-cycle acceptance at fixed shared prefixes; descriptive only."""
from collections import Counter, defaultdict
from pathlib import Path
import hashlib
import json
import statistics

r = Path(__file__).resolve().parents[1]
arms = {"dflash8": "fixed-prefix-dflash8-v1", "dspine8": "fixed-prefix-8m16-v1",
        "dspine16": "fixed-prefix-16twopass-v1"}
values, sources = {}, {}
for arm, ident in arms.items():
    path = r / f"results/{ident}.stdout"
    receipt = json.loads((r / f"results/{ident}.receipt.json").read_text())
    assert receipt["state"] == "complete" and receipt["exit_code"] == 0
    document = json.loads(path.read_text())
    assert document["study_temperature"] == 0
    values[arm] = {m["scenario"]: m for m in document["measurements"]}
    sources[arm] = {"id": ident, "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}
assert all(value.keys() == values["dflash8"].keys() for value in values.values())
metadata = {v["name"]: v for v in json.loads((r / "results/fixed-prefix-summary.json").read_text())["cases"]}
cases = []
for name in values["dflash8"]:
    entries = {arm: value[name] for arm, value in values.items()}
    first = {arm: entry["draft_cycles"][0] for arm, entry in entries.items()}
    eligible = all(first[arm]["drafted_tokens"] == (15 if arm == "dspine16" else 7) for arm in arms)
    cases.append({"name": name, "task": metadata[name]["scenario"], "primary": metadata[name]["primary"],
                  "full_width_first_cycles": eligible,
                  "all_output_arrays_match": all(v["output_tokens"] == entries["dflash8"]["output_tokens"] for v in entries.values()),
                  "first_cycle": first})
primary = [c for c in cases if c["primary"] and c["full_width_first_cycles"]]
summaries = {}
for arm in arms:
    accepted = [c["first_cycle"][arm]["accepted_draft_tokens"] for c in primary]
    by_task = defaultdict(list)
    for c in primary:
        by_task[c["task"]].append(1 + c["first_cycle"][arm]["accepted_draft_tokens"])
    summaries[arm] = {"mean_first_cycle_outputs_equal_prefix_weight": statistics.mean(1 + a for a in accepted),
                      "mean_first_cycle_outputs_equal_task_weight": statistics.mean(statistics.mean(v) for v in by_task.values()),
                      "accepted_prefix_histogram": dict(sorted(Counter(accepted).items())), "tasks": len(by_task)}
base = summaries["dflash8"]
for arm in ("dspine8", "dspine16"):
    for weight in ("equal_prefix_weight", "equal_task_weight"):
        metric = "mean_first_cycle_outputs_" + weight
        summaries[arm]["ratio_vs_dflash8_" + weight] = summaries[arm][metric] / base[metric]
pair = Counter("higher" if c["first_cycle"]["dspine8"]["accepted_draft_tokens"] > c["first_cycle"]["dflash8"]["accepted_draft_tokens"] else
               "lower" if c["first_cycle"]["dspine8"]["accepted_draft_tokens"] < c["first_cycle"]["dflash8"]["accepted_draft_tokens"] else "equal" for c in primary)
record = {"protocol": json.loads((r / "notes/matched-drafter-followup-protocol.json").read_text()),
          "sources": sources, "all71_output_arrays_match": all(c["all_output_arrays_match"] for c in cases),
          "eligible_primary_prefixes": len(primary), "summaries": summaries,
          "dspine8_first_cycle_acceptance_vs_dflash8_case_counts": dict(pair), "cases": cases,
          "scope": "Same short contexts and greedy anchors. Overlapping prefixes and historical calibration tasks; neither weighting represents production cycle frequency. No independent-sample CI, throughput forecast, or general drafter ranking. Both context windows cover every prefix."}
(r / "results/matched-drafter-prefix-comparison.json").write_text(json.dumps(record, indent=2) + "\n")
print(json.dumps({k: v for k, v in record.items() if k not in {"cases", "protocol", "sources"}}, indent=2))

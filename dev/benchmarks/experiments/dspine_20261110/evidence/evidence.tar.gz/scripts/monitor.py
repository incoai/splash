import datetime as dt,json,os,signal,subprocess,time,hashlib
from pathlib import Path
r=Path(__file__).resolve().parents[1]
binary=Path('/Users/linson/Documents/ai/splash-inference-lab-20261031/tools/macmon')
deadline=dt.datetime(2026,11,10,11,18,48,tzinfo=dt.timezone.utc).timestamp()
(r/'notes/telemetry-provenance.json').write_text(json.dumps({'binary':str(binary),'sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'sampling_interval_ms':2000,'deadline_unix':deadline},indent=2)+'\n')
p=subprocess.Popen([str(binary),'pipe','-i','2000'],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,start_new_session=True)
try:
 with (r/'results/hardware.jsonl').open('a') as out:
  for line in p.stdout:
   if time.time()>=deadline:break
   v=json.loads(line);v['recorded_unix']=time.time()
   try:v['investigation_phase']=json.loads((r/'session.json').read_text()).get('phase','review')
   except (OSError,ValueError):v['investigation_phase']='unknown'
   out.write(json.dumps(v)+'\n');out.flush()
finally:
 if p.poll() is None:os.killpg(p.pid,signal.SIGTERM);p.wait(timeout=10)
 (r/'logs/monitor.stderr').write_text(p.stderr.read())

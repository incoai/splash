"""Describe pinned target capture drift; no invented pass threshold."""
from pathlib import Path
import hashlib,json
import numpy as np
r=Path(__file__).resolve().parents[1];f=r/'features';layers=[1,16,31,46,61]
def metrics(a,b):
 a=np.asarray(a,dtype=np.float64).reshape(-1);b=np.asarray(b,dtype=np.float64).reshape(-1)
 assert a.shape==b.shape and np.isfinite(a).all() and np.isfinite(b).all()
 error=a-b;rms=float(np.sqrt(np.mean(b*b)))
 return {'values':len(a),'exact_fraction':float(np.mean(a==b)),'max_absolute_error':float(np.max(np.abs(error))),'rmse':float(np.sqrt(np.mean(error*error))),'reference_rms':rms,'relative_rmse':float(np.sqrt(np.mean(error*error))/rms),'cosine_similarity':float(np.dot(a,b)/np.sqrt(np.dot(a,a)*np.dot(b,b)))}
native={};files={}
for variant in ['m16-policy','wide-policy']:
 for kv in ['bf16','int8']:
  key=variant+'-'+kv;p=f/f'target-captures-{variant}-{kv}-v1-128.captures.f32';data=np.fromfile(p,dtype='<f4');assert data.size==96*5*5120;native[key]=data.reshape(96,5,5120);files[str(p.relative_to(r))]={'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
reference={i:np.fromfile(f/f'mlx-reference-v1/layer-{i}.f32',dtype='<f4').reshape(96,5120) for i in range(64) if (f/f'mlx-reference-v1/layer-{i}.f32').exists()}
rows=[]
for slot,layer in enumerate(layers):
 rows.append({'layer_zero_based':layer,'native8_vs16_BF16KV':metrics(native['m16-policy-bf16'][:,slot],native['wide-policy-bf16'][:,slot]),'native8_vs16_INT8KV':metrics(native['m16-policy-int8'][:,slot],native['wide-policy-int8'][:,slot]),'native8_INT8KV_vs_BF16KV':metrics(native['m16-policy-int8'][:,slot],native['m16-policy-bf16'][:,slot]),'native8_BF16KV_vs_MLX4bit_BF16KV':metrics(native['m16-policy-bf16'][:,slot],reference[layer]),'MLX_neighbor_cosines':{str(i):metrics(native['m16-policy-bf16'][:,slot],reference[i])['cosine_similarity'] for i in [layer-1,layer,layer+1]}})
mlx_logits=np.fromfile(f/'mlx-reference-v1/last-logits.f32',dtype='<f4');assert mlx_logits.size==248320
logits={}
for key in native:
 p=f/f'target-captures-{key}-v1-128.f32';a=np.fromfile(p,dtype='<f4').reshape(33,248320)[0];logits[key]={'native_argmax':int(a.argmax()),'MLX_argmax':int(mlx_logits.argmax()),'first_prefill_logit_row_vs_MLX':metrics(a,mlx_logits)};files[str(p.relative_to(r))]={'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
record={'protocol':json.loads((r/'notes/target-feature-parity-protocol.json').read_text()),'MLX_reference_record':json.loads((f/'mlx-reference-v1/record.json').read_text()),'layers':rows,'prefill_logits':logits,'raw_native_files':files,'scope':'96coldprefillpositions fromonefixedprompt/transcript,5post-layercaptures,identical4bit targetsourceweights. Numericaldrift andindexalignmentdiagnostic,not a BF16trainingtargetcomparison,fullDSpineacceptance comparison,orall-context equivalence proof.'};(r/'results/target-capture-comparison.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({'layers':rows,'prefill_logits':logits},indent=2))

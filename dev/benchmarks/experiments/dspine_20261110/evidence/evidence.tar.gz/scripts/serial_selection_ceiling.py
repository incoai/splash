"""Describe zero-overhead hindsight whole-task selection; not an adaptive policy."""
from pathlib import Path
import datetime as dt
import hashlib
import json
import statistics

r = Path(__file__).resolve().parents[1]
source = r / "results/block16-vs-m16-final.json"
comparison = json.loads(source.read_text())
raw = json.loads((r / "results/block16-vs-m16-abba-g1-a1.stdout").read_text())
tokens = {f"{m['scenario']}:{m['sample']}": len(m["output_tokens"]) - 1 for m in raw["measurements"]}
cases = []
for key in [c["key"] for c in comparison["groups"][0]["cases"] if not c["key"].startswith("count_secondary:")]:
    observations = [next(c for c in group["cases"] if c["key"] == key)["abba_milliseconds_per_token"]
                    for group in comparison["groups"]]
    a = statistics.mean(v["baseline"] for v in observations) * tokens[key]
    b = statistics.mean(v["candidate"] for v in observations) * tokens[key]
    cases.append({"key": key, "decode_tokens": tokens[key], "mean_8row_decode_ms": a,
                  "mean_16row_decode_ms": b, "oracle_chosen_rows": 8 if a < b else 16,
                  "descriptive_16row_throughput_change": a / b - 1})
a = sum(c["mean_8row_decode_ms"] for c in cases)
b = sum(c["mean_16row_decode_ms"] for c in cases)
oracle = sum(min(c["mean_8row_decode_ms"], c["mean_16row_decode_ms"]) for c in cases)
record = {
    "utc": dt.datetime.now(dt.timezone.utc).isoformat(),
    "source_sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
    "primary_decode_tokens": sum(c["decode_tokens"] for c in cases),
    "mean_8row_decode_ms": a, "mean_16row_decode_ms": b,
    "hindsight_per_task_oracle_decode_ms": oracle,
    "optimistic_additional_throughput_vs_fixed16": b / oracle - 1,
    "tasks_choosing8": sum(c["oracle_chosen_rows"] == 8 for c in cases), "cases": cases,
    "interpretation": "Descriptive hindsight whole-task selection on the same calibration data, with zero prediction/switching/storage overhead. Not an adaptive policy, performance qualification, or an upper bound on per-cycle switching or other workloads. This is only the observed ceiling of perfect whole-task selection on these means.",
}
(r / "results/serial-task-selection-ceiling.json").write_text(json.dumps(record, indent=2) + "\n")
print(json.dumps({k: v for k, v in record.items() if k != "cases"}, indent=2))
print("prefer8", [(c["key"], c["descriptive_16row_throughput_change"]) for c in cases if c["oracle_chosen_rows"] == 8])

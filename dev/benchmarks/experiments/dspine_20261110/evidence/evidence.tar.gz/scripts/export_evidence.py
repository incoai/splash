"""Export compact evidence without model tensors, executable files, or cache contents."""

from __future__ import annotations

import argparse
import gzip
import hashlib
import io
import json
import tarfile
from pathlib import Path


def digest(data):
    return hashlib.sha256(data).hexdigest()


def archive(path, records):
    with path.open("wb") as destination:
        with gzip.GzipFile(
            filename="", fileobj=destination, mode="wb", mtime=0
        ) as compressed:
            with tarfile.open(fileobj=compressed, mode="w|") as output:
                for name, data in records:
                    entry = tarfile.TarInfo(name)
                    entry.size, entry.mtime, entry.mode = len(data), 0, 0o644
                    output.addfile(entry, io.BytesIO(data))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--root", type=Path, default=Path(__file__).resolve().parents[1]
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    root = args.root.resolve()
    args.output.mkdir(parents=True, exist_ok=True)
    files = {}

    def include(path):
        name = str(path.relative_to(root))
        if path.is_symlink():
            raise ValueError("Unexpected evidence symlink: " + name)
        data = path.read_bytes()
        files[name] = {"bytes": len(data), "sha256": digest(data)}
        return name, data

    records = []
    for directory in ("results", "logs", "notes", "scripts", "patches"):
        for path in sorted((root / directory).rglob("*")):
            if not path.is_file() or "__pycache__" in path.parts:
                continue
            if path.name in {"hardware.jsonl", "publication-summaries.json"}:
                continue
            # A quantizer fixture subdirectory contains raw native arrays.
            if directory == "results" and path.parent != root / "results":
                continue
            records.append(include(path))
    for path in sorted((root / "http").rglob("*")):
        if path.is_file() and "cache" not in path.relative_to(root / "http").parts:
            if path.suffix in {".json", ".jsonl", ".log", ".txt", ".stderr", ".stdout"}:
                records.append(include(path))
    for path in sorted((root / "features").rglob("*.json")):
        records.append(include(path))
    for smoke in ("reproduction-smoke", "reproduction-smoke-v5"):
        for path in sorted((root / smoke / "runs").glob("*")):
            if path.is_file():
                records.append(include(path))
        for path in sorted((root / smoke / "artifacts").rglob("manifest.json")):
            records.append(include(path))
    for path in sorted((root / "artifacts").rglob("*.json")):
        if any(part.startswith("reproduction-source-") for part in path.parts):
            continue
        if path.name in {"build.json", "manifest.json", "record.json"}:
            records.append(include(path))
    for name in ("session.json", "queue.jsonl", "runner-stopped.json"):
        path = root / name
        if path.exists():
            records.append(include(path))
    archive(args.output / "evidence.tar.gz", sorted(records))
    hardware = root / "results/hardware.jsonl"
    raw = hardware.read_bytes()
    files["results/hardware.jsonl"] = {"bytes": len(raw), "sha256": digest(raw)}
    with (args.output / "hardware.jsonl.gz").open("wb") as destination:
        with gzip.GzipFile(
            filename="", fileobj=destination, mode="wb", mtime=0
        ) as compressed:
            compressed.write(raw)
    manifest = {
        "format": 1,
        "files": dict(sorted(files.items())),
        "archives": {
            name: {
                "bytes": (args.output / name).stat().st_size,
                "sha256": digest((args.output / name).read_bytes()),
            }
            for name in ("evidence.tar.gz", "hardware.jsonl.gz")
        },
        "scope": "All saved trial receipts and outputs, failures included; original collection scripts and notes; HTTP records exclude cache contents. Large native/MLX float captures, model tensors, executables, native quantizer fixtures and library binaries remain local with source/result digests. Hardware is separate. Some historical failed source versions have only retained receipts/digests; the published final variant patches are the rebuildable sources.",
    }
    (args.output / "evidence-manifest.json").write_text(
        json.dumps(manifest, indent=2) + "\n"
    )
    print(json.dumps({"files": len(files), "archives": manifest["archives"]}, indent=2))


if __name__ == "__main__":
    main()

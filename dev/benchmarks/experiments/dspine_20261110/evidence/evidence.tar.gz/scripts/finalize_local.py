"""Freeze the completed eight-hour record; validate before staging any files."""
from pathlib import Path
import datetime as dt
import json
import os
import signal
import subprocess

r=Path(__file__).resolve().parents[1]
assert dt.datetime.now(dt.timezone.utc)>=dt.datetime(2026,11,10,11,18,48,tzinfo=dt.timezone.utc)
assert json.loads((r/'runner-stopped.json').read_text())['deadline_reached']
cleanup=[]
for row in json.loads((r/'notes/owned-caffeinate-observation.json').read_text())['matches']:
    pid=row['pid']
    current=subprocess.run(['ps','-p',str(pid),'-o','command='],capture_output=True,text=True).stdout.strip()
    start=subprocess.run(['ps','-p',str(pid),'-o','lstart='],capture_output=True,text=True).stdout.strip()
    if current==row['command'] and start==row['start_local']:
        os.kill(pid,signal.SIGTERM);cleanup.append({'pid':pid,'action':'terminated owned caffeinate after eight-hour window'})
(r/'notes/owned-process-cleanup.json').write_text(json.dumps(cleanup,indent=2)+'\n')
s=json.loads((r/'session.json').read_text());s.update(phase='eight_hour_window_complete',completed_utc=dt.datetime.now(dt.timezone.utc).isoformat(),publication_state='Eight-hour research complete. Final archive/index validated before staging; commit/push and remote PR verification follow this frozen snapshot.')
(r/'session.json').write_text(json.dumps(s,indent=2)+'\n')
commands=[['python3',str(r/'scripts/audit_power_sources.py')],['python3',str(r/'scripts/audit_hardware_trace.py')],['python3',str(r/'scripts/export_sources.py')],['python3',str(r/'scripts/build_result_index.py'),'--output',str(r/'publication/results/dspine-investigation-qwen38-27b-2026-11-10.json'),'--final'],['python3',str(r/'scripts/export_evidence.py'),'--output',str(r/'publication/experiments/dspine_20261110/evidence')],['python3',str(r/'scripts/validate_publication.py')],['python3',str(r/'scripts/stage_publication.py')],['git','-C','/Users/linson/Documents/ai/splash','diff','--cached','--check']]
for command in commands:subprocess.run(command,check=True,cwd=r)
print('FINAL LOCAL VALIDATION AND OWNED-FILE STAGING: PASS',flush=True)

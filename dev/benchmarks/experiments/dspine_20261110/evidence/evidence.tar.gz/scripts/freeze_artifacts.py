from pathlib import Path
import hashlib, json, shutil, subprocess, sys
r = Path(__file__).resolve().parents[1]
variant, version = sys.argv[1:]
tree = r / variant
out = r / 'artifacts' / ('frozen-'+variant+'-'+version)
out.mkdir(exist_ok=False)
files = ['splash', 'splash.metallib', 'host-step.metallib', 'engine/BuildIdentity.hpp']
files += ['engine-tests/'+name for name in ['dspine', 'draft-attention', 'linear-plan', 'weight-digests', 'backend-benchmark', 'decode-profile']]
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
copied = {}
for name in files:
    source = tree/'build'/name
    if not source.exists(): continue
    dest = out/name; dest.parent.mkdir(parents=True, exist_ok=True)
    before = sha(source); shutil.copy2(source, dest); after = sha(dest)
    assert before == after == sha(source)
    copied[name] = after
diff = subprocess.check_output(['git', '-C', str(tree), 'diff', '--binary'])
(out/'source.patch').write_bytes(diff)
record = {'source_commit': subprocess.check_output(['git', '-C', str(tree), 'rev-parse', 'HEAD'], text=True).strip(),
          'source_patch_sha256': hashlib.sha256(diff).hexdigest(), 'files': copied}
(out/'manifest.json').write_text(json.dumps(record, indent=2)+'\n')
print(out)

from pathlib import Path
import json,subprocess,sys,hashlib,shutil
r=Path(__file__).resolve().parents[1]
name=sys.argv[1]
trees={'wide-policy':r/'wide-policy','control':Path('/Users/linson/Documents/ai/splash'),'precision':r/'precision','block16':r/'block16','m16-policy':r/'m16-policy','bridge-parity':r/'bridge-parity'}
tree=trees[name];build=tree/'build';out=r/'artifacts'/'study-batch-diagnostic';out.mkdir(exist_ok=False)
inputs=[r/'scripts/batch_diagnostic_driver.mm',build/'engine/libsplash.a',build/'engine/BuildIdentity.hpp',build/'splash.metallib',Path('/Users/linson/Documents/ai/splash/dev/benchmarks/PrefillWork.hpp'),Path('/Users/linson/Documents/ai/splash/dev/benchmarks/TranscriptPrompts.hpp')]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
before={str(p):sha(p) for p in inputs}
cmd=['xcrun','-sdk','macosx','clang++','-std=c++20','-O3','-Wall','-Wextra','-Werror','-I'+str(tree/'runtime'),'-I/Users/linson/Documents/ai/splash/dev/benchmarks','-mmacosx-version-min=26.4','-fobjc-arc','-include',str(build/'engine/BuildIdentity.hpp'),str(r/'scripts/batch_diagnostic_driver.mm'),str(build/'engine/libsplash.a'),'-framework','Foundation','-framework','Metal','-framework','IOKit','-framework','IOSurface','-o',str(out/'study-driver')]
subprocess.run(cmd,check=True)
for f in ['splash.metallib','host-step.metallib']:shutil.copy2(build/f,out/f)
after={str(p):sha(p) for p in inputs}
assert before==after,'Study build inputs changed'
(out/'build.json').write_text(json.dumps({'variant':name,'command':cmd,'inputs':before,'binary_sha256':sha(out/'study-driver')},indent=2)+'\n')
print(out)

"""Evaluate frozen controlled rounds without dropping noisy or failed runs."""
from pathlib import Path
import argparse, json, sys
sys.path.insert(0, '/Users/linson/Documents/ai/splash')
from dev.benchmarks.abba import compare
from analyze_study import metrics

def evaluate(root, prefix, groups):
    results = []
    for group in range(1, groups+1):
        ids = [f'{prefix}-g{group}-{name}' for name in ['a1', 'b1', 'b2', 'a2']]
        rows = []; problems = []
        for ident in ids:
            receipt = root/f'results/{ident}.receipt.json'
            if not receipt.exists(): problems.append(ident+': pending'); continue
            rr = json.loads(receipt.read_text())
            if rr['exit_code'] != 0: problems.append(ident+': exit '+str(rr['exit_code'])); continue
            operating = json.loads((root/f'results/{ident}.operating.json').read_text())
            for gate in ['operating_gate_passed', 'no_serious_or_critical_state', 'no_swap']:
                if not operating.get(gate): problems.append(ident+': '+gate+' failed')
            doc = json.loads((root/f'results/{ident}.stdout').read_text())
            rows.append(metrics(doc))
        result = {'group': group, 'rounds': ids, 'problems': problems, 'qualified': False}
        if len(rows) != 4:
            results.append(result); continue
        keys = rows[0].keys()
        if any(row.keys() != keys for row in rows):
            result['problems'].append('case sets differ'); results.append(result); continue
        cases = []
        for key in keys:
            rr = [row[key] for row in rows]
            same = len({v['token_sha256'] for v in rr}) == 1
            abba = compare(*(v['decode_wall_ms']/v['decode_tokens'] for v in rr))
            cases.append({'key': key, 'output_arrays_match': same,
                          'cycles': [v['cycles'] for v in rr], 'abba_milliseconds_per_token': abba})
        totals = []
        for row in rows:
            primary = [v for v in row.values() if v['scenario'] != 'count_secondary']
            totals.append(sum(v['decode_wall_ms'] for v in primary)/sum(v['decode_tokens'] for v in primary))
        overall = compare(*totals)
        same = all(c['output_arrays_match'] for c in cases)
        quiet = all(c['abba_milliseconds_per_token']['noise'] <= 0.05 for c in cases)
        improved = overall['regression'] < -overall['bound'] and overall['noise'] <= 0.05
        result.update(primary_abba_milliseconds_per_token=overall,
                      primary_throughput_change=overall['baseline']/overall['candidate']-1,
                      all_output_arrays_match=same, all_case_control_spreads_at_most_five_percent=quiet,
                      primary_improvement_exceeds_noise_allowance=improved, cases=cases,
                      qualified=not problems and same and quiet and improved)
        results.append(result)
    return {'prefix': prefix, 'groups_required': groups,
            'qualified': len(results) == groups and all(v['qualified'] for v in results), 'groups': results,
            'scope': 'Fixed cohort, native serial requests, one machine, exactly the saved groups. No repeat-to-pass. Qualification requires all operating, output, noise and aggregate improvement gates. Per-case effects are reported separately.'}

if __name__ == '__main__':
    p = argparse.ArgumentParser(); p.add_argument('prefix'); p.add_argument('--groups', type=int, default=3)
    p.add_argument('--root', type=Path, default=Path(__file__).resolve().parents[1]); p.add_argument('--output', type=Path, required=True)
    args = p.parse_args(); d = evaluate(args.root, args.prefix, args.groups)
    args.output.write_text(json.dumps(d, indent=2)+'\n')
    print(json.dumps({'prefix': d['prefix'], 'qualified': d['qualified'], 'groups': [{k: v for k, v in g.items() if k != 'cases'} for g in d['groups']]}, indent=2))

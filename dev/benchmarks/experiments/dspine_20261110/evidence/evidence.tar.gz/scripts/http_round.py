"""One loopback HTTP timing round; operating gates are supplied by controlled_round."""
from pathlib import Path
from types import SimpleNamespace
import json, sys
sys.path.insert(0, '/Users/linson/Documents/ai/splash')
from dev.benchmarks import draft_comparison as comparison
from dev.tests import smoke_real as smoke
r = Path(__file__).resolve().parents[1]
ident, binary, model_root = sys.argv[1:]
output = r/'http'/ident
output.mkdir(parents=True, exist_ok=False)
original_status = smoke.validate_status
statuses = []
def capture(status, kv):
    original_status(status, kv)
    statuses.append(status)
smoke.validate_status = capture
result = comparison.round_run(SimpleNamespace(output=output, max_tokens=192), ident, Path(binary), Path(model_root))
result['status_start'], result['status_end'] = statuses[0], statuses[-1]
result['decode_width_deltas'] = {key: statuses[-1]['scheduler']['decode_batches_by_width'][key]-count
                              for key, count in statuses[0]['scheduler']['decode_batches_by_width'].items()}
smoke.require(result['decode_width_deltas']['b4'] > 0, 'no physical batch4 work in HTTP round')
(output/(ident+'.json')).write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps({'id': ident, 'decode_width_deltas': result['decode_width_deltas']}), flush=True)

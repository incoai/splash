"""Verify portable sources, indexed evidence and compressed archive contents."""
from pathlib import Path
import argparse
import gzip
import hashlib
import json
import re
import subprocess
import tarfile


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    root=Path(__file__).resolve().parents[1]
    parser.add_argument('--package',type=Path,default=root/'publication/experiments/dspine_20261110')
    parser.add_argument('--index',type=Path,default=root/'publication/results/dspine-investigation-qwen38-27b-2026-11-10.json')
    args=parser.parse_args()
    package=args.package.resolve()
    sources=json.loads((package/'source-manifest.json').read_text())
    for name, expected in sources['files'].items():
        path=package/name
        assert path.is_file() and not path.is_symlink(),name
        data=path.read_bytes()
        assert len(data)==expected['bytes'] and sha(data)==expected['sha256'],name
    assert not any('.ruff_cache' in Path(name).parts or '__pycache__' in Path(name).parts for name in sources['files'])
    evidence=package/'evidence'
    manifest=json.loads((evidence/'evidence-manifest.json').read_text())
    for name,expected in manifest['archives'].items():
        data=(evidence/name).read_bytes()
        assert len(data)==expected['bytes'] and sha(data)==expected['sha256'],name
        assert len(data)<100*1024*1024,'GitHub file-size limit: '+name
    seen=set()
    with tarfile.open(evidence/'evidence.tar.gz','r:gz') as archive:
        for entry in archive:
            assert entry.isfile() and not entry.name.startswith('/') and '..' not in Path(entry.name).parts,entry.name
            assert entry.name not in seen,entry.name
            seen.add(entry.name)
            expected=manifest['files'][entry.name]
            data=archive.extractfile(entry).read()
            assert len(data)==expected['bytes'] and sha(data)==expected['sha256'],entry.name
    assert seen==set(manifest['files'])-{'results/hardware.jsonl'}
    raw=gzip.decompress((evidence/'hardware.jsonl.gz').read_bytes())
    expected=manifest['files']['results/hardware.jsonl']
    assert len(raw)==expected['bytes'] and sha(raw)==expected['sha256']
    index=json.loads(args.index.read_text())
    assert index['status']=='complete'
    for name,expected in index['indexed_source_files'].items():
        assert manifest['files'][name]==expected,name
    assert len(index['native_comparisons'])==4
    assert all(len(d['groups'])==3 for d in index['native_comparisons'].values())
    assert index['sampling']['informative_tests']==73
    assert index['matched_drafters']['eligible_primary_prefixes']==67
    assert index['hardware_trace_audit']['sha256']==sha(raw)
    assert not re.search(r'PENDING_[A-Z_]+',(package/'README.md').read_text())
    for label,target in re.findall(r'\[([^\]]*)\]\(([^)]+)\)',(package/'README.md').read_text()):
        if '://' not in target and not target.startswith('#'):
            assert (package/target.split('#')[0]).exists(),target
    validated=index['portable_reproduction']['validated_rebuild_source_sha256']
    for name,expected in validated.items():
        assert sha((package/name).read_bytes())==expected,name
    patches=list((package/'patches').glob('*.patch'))
    followup=package/'followups/table16-layout-followup.patch'
    if followup.exists():patches.append(followup)
    assert len(list((package/'patches').glob('*.patch')))==14
    for patch in patches:
        subprocess.run(['git','-C',str(root/'reproduction-apply-check'),'apply','--check',str(patch)],check=True,capture_output=True)
    narrow=package/'followups/table16-packing-only.patch'
    if narrow.exists():
        subprocess.run(['git','-C',str(root/'wide-policy'),'apply','--check',str(narrow)],check=True,capture_output=True)
    print(json.dumps({'narrow_review_delta_checked_on_wide_base':narrow.exists(),'source_files_verified':len(sources['files']),'archive_files_verified':len(manifest['files']),
                      'indexed_sources_verified':len(index['indexed_source_files']),'patches_apply_checked':len(patches),
                      'compressed_archive_bytes':sum(x['bytes'] for x in manifest['archives'].values()),
                      'fresh_reproduction_source_hashes_unchanged':True,'status':'PASS'},indent=2))


if __name__=='__main__':
    main()

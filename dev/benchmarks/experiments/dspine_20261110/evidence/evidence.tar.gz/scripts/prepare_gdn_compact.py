"""Generate a research-only compact operand variant; preserve the legacy entry."""
from pathlib import Path
import hashlib, json
r = Path(__file__).resolve().parents[1]
source = r/'m16-policy/runtime/metal/kernels/decode/gdn.metal'
dest = r/'gdn-compact/runtime/metal/kernels/decode/gdn.metal'
s = source.read_text()
def function(name, end):
    middle = s.index('inline void '+name+'(')
    return s[s.rfind('template <', 0, middle):s.index(end, middle)]

prologue = function('gdn_decode_prologue', '// Delta-rule recurrence')
scan = function('gdn_decode_scan', '// Gated RMSNorm')
gate = function('gdn_decode_gate', '// Grid {value heads, lanes}.')
phase = function('gdn_decode_batch_phase', '// W: the norm weights')
def compact(text):
    for name in ['gdn_decode_prologue', 'gdn_decode_scan', 'gdn_decode_gate', 'gdn_decode_batch_phase']:
        text = text.replace(name, name+'_compact')
    return text.replace('GdnDecodeShared<HeadDim>', 'GdnDecodeCompactShared<HeadDim>')
prologue, scan, gate, phase = map(compact, [prologue, scan, gate, phase])
start = prologue.index('  if (token < pending) {')
end = prologue.index('  float q[Groups], k[Groups];', start)
prologue = prologue[:start]+'  (void)pending_tape;\n  (void)pending;\n\n'+prologue[end:]
old = '    shared.beta[token] = gates.beta;\n    shared.decay[token] = gates.decay;\n'
assert old in prologue; prologue = prologue.replace(old, '')
scan = scan.replace('template <uint HeadDim, uint RowsInFlight, class State>',
                    'template <uint KeyHeads, uint ValueHeads, uint HeadDim, uint RowsInFlight, class State>')
old = 'threadgroup GdnDecodeCompactShared<HeadDim> &shared,\n                            uint pending'
assert old in scan; scan = scan.replace(old, 'threadgroup GdnDecodeCompactShared<HeadDim> &shared,\n                            GdnTape pending_tape, GdnTape step_tape,\n                            uint pending')
scan = scan.replace('  constexpr uint Tokens = SPLASH_TARGET_VERIFY_ROWS;',
                    '  constexpr uint KvWidth = (KeyHeads + ValueHeads) * HeadDim;\n'
                    '  const uint k_column = (value_head / (ValueHeads / KeyHeads)) * HeadDim;\n'
                    '  const uint v_column = KeyHeads * HeadDim + value_head * HeadDim;\n'
                    '  constexpr uint Tokens = SPLASH_TARGET_VERIFY_ROWS;')
for a,b in {
    'shared.pending_decay[token]':'pending_tape.decay[token * ValueHeads + value_head]',
    'shared.pending_beta[token]':'pending_tape.beta[token * ValueHeads + value_head]',
    'threadgroup const bfloat *key =\n          shared.pending_keys + token * HeadDim + lane * 4;':
        'device const bfloat *key =\n          pending_tape.kv + token * KvWidth + k_column + lane * 4;',
    'shared.pending_values[token * HeadDim + value_dim[r]]':
        'pending_tape.kv[token * KvWidth + v_column + value_dim[r]]',
    'shared.decay[token]':'step_tape.decay[token * ValueHeads + value_head]',
    'shared.beta[token]':'step_tape.beta[token * ValueHeads + value_head]',
}.items():
    assert a in scan, a; scan = scan.replace(a,b)
assert 'shared.pending_' not in scan and 'shared.decay' not in scan and 'shared.beta' not in scan
phase = phase.replace('gdn_decode_scan_compact<HeadDim, RowsInFlight, State>',
                       'gdn_decode_scan_compact<KeyHeads, ValueHeads, HeadDim, RowsInFlight, State>')
old = 'state_in, state_out, shared,\n                                                pending, group.x, lane,'
assert old in phase; phase = phase.replace(old, 'state_in, state_out, shared, pending_tape, step_tape,\n                                                pending, group.x, lane,')
phase = phase.replace('threadgroup_barrier(mem_flags::mem_threadgroup);',
                       'threadgroup_barrier(mem_flags::mem_threadgroup | mem_flags::mem_device);', 1)
shared = '''// Research: stable pending operands and newly written scalar gates live
// in the disjoint device tapes. Only the current vectors and outputs are shared.
template <uint HeadDim> struct GdnDecodeCompactShared {
  bfloat queries[SPLASH_TARGET_VERIFY_ROWS * HeadDim];
  bfloat keys[SPLASH_TARGET_VERIFY_ROWS * HeadDim];
  bfloat values[SPLASH_TARGET_VERIFY_ROWS * HeadDim];
  bfloat rows[SPLASH_TARGET_VERIFY_ROWS * HeadDim];
};

'''
block = shared+prologue+scan+gate+phase
assert 'shared.pending_' not in block
s = s.replace('constant uint kDecodeSimdgroups = 8;', 'constant uint kDecodeSimdgroups = SPLASH_TARGET_VERIFY_ROWS;')
marker = '// W: the norm weights'
s = s[:s.index(marker)]+block+s[s.index(marker):]
old = 'GDN_DECODE_ENTRY(verify_gdn_fused, 16, 48, 128, 10240, 16640, bfloat)'
assert s.count(old) == 1
entry = '''GDN_DECODE_KERNEL(verify_gdn_fused_legacy, 16, 48, 128, 10240, 16640, bfloat, float)
GDN_DECODE_KERNEL(verify_gdn_fused_bf16_state, 16, 48, 128, 10240, 16640, bfloat, bfloat)
kernel void verify_gdn_fused(GDN_DECODE_BUFFERS(bfloat),
    constant GDNDecodeBatchParams &params [[buffer(15)]], GDN_DECODE_THREADS) {
  threadgroup GdnDecodeCompactShared<128> shared;
  gdn_decode_batch_phase_compact<16, 48, 128, 10240, 16640, 2, gguf_sg::Table16, bfloat, float>(
      packed, conv_weights, current0, current1, current2, current3,
      next0, next1, next2, next3, tape, a_scale, dt_bias,
      gdn_norm_weight, gdn_hidden, params, group, lane, simd_group, shared, nullptr, nullptr);
}'''
s = s.replace(old, entry)
dest.write_text(s)
record = {'source_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
          'candidate_sha256': hashlib.sha256(dest.read_bytes()).hexdigest(),
          'scope': 'Research-only base 16-key/48-value-head BF16-norm/FP32-state plain decode entry. Other shapes, table preparation, F32 norms and BF16 state retain original paths. Existing host rejects all overlapping pending/step tapes.'}
(r/'notes/gdn-compact-source.json').write_text(json.dumps(record, indent=2)+'\n')
print(json.dumps(record))

"""Pinned4bit target reference captures; no DSpine capture wrapper or training claims."""
from pathlib import Path
import argparse,hashlib,importlib.metadata,inspect,json,os,time
os.environ['HF_HUB_OFFLINE']='1'
import mlx.core as mx
from mlx_lm import load
from mlx_lm.models.cache import make_prompt_cache
from mlx_lm.models import gated_delta
import numpy as np
parser=argparse.ArgumentParser();parser.add_argument('--tokens',type=Path,required=True);parser.add_argument('--output',type=Path,required=True);args=parser.parse_args()
r=Path(__file__).resolve().parents[1];model_root=Path(Path('/Users/linson/Documents/ai/splash/build/dspine/model-root.txt').read_text().strip());target=Path('/Users/linson/.cache/huggingface/hub/models--mlx-community--Qwen3.8-27B-4bit/snapshots/10c35caafbb80f7dc6a7a432cdd11af10a6d4818')
manifest=json.loads((model_root/'model.json').read_text());identity=[]
for name,value in manifest['files'].items():
 if name.startswith('target/'):
  source=target/Path(name).name
  assert source.samefile(model_root/name), 'reference/native source files differ'
  identity.append({'name':name,'manifest_sha256':value['digest'],'same_file':True,'bytes':value['bytes']})
args.output.mkdir(parents=True,exist_ok=False);started=time.perf_counter();mx.enable_compile();model,_=load(str(target),trust_remote_code=False);model.eval();language=model.language_model
ids=np.fromfile(args.tokens,dtype='<u4');prefix=96;inputs=mx.array(ids[:prefix][None],dtype=mx.uint32);layers=language.model.layers;wanted=[1,16,31,46,61];neighbors=sorted({j for i in wanted for j in [i-1,i,i+1]});mapping={id(layer):i for i,layer in enumerate(layers)};captures={};cls=type(layers[0]);original=cls.__call__
def wrapped(self,*a,**kw):
 out=original(self,*a,**kw);index=mapping[id(self)]
 if index in neighbors:captures[index]=out
 return out
cls.__call__=wrapped
try:
 cache=make_prompt_cache(model);hidden=language.model(inputs,cache=cache)
 logits=language.model.embed_tokens.as_linear(hidden[:,-1:,:]) if language.args.tie_word_embeddings else language.lm_head(hidden[:,-1:,:])
 mx.eval(logits,*captures.values())
finally:cls.__call__=original
assert set(captures)==set(neighbors)
rows=[]
for index in neighbors:
 array=np.asarray(captures[index].astype(mx.float32)).reshape(prefix,5120).astype('<f4');p=args.output/f'layer-{index}.f32';array.tofile(p);rows.append({'layer_zero_based':index,'shape':list(array.shape),'source_dtype':str(captures[index].dtype),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
p=args.output/'last-logits.f32';np.asarray(logits.astype(mx.float32)).reshape(-1).astype('<f4').tofile(p)
# Continue from the identical96-token cached prefix with32forced input tokens.
# Row0predicts token96; rows1..32predict tokens97..128, matching teacher-logits.
forced_logits=[np.asarray(logits.astype(mx.float32)).reshape(-1).astype('<f4')]
for index in range(prefix,128):
 step=language.model(mx.array(ids[index:index+1][None],dtype=mx.uint32),cache=cache)
 current=language.model.embed_tokens.as_linear(step) if language.args.tie_word_embeddings else language.lm_head(step)
 mx.eval(current)
 forced_logits.append(np.asarray(current.astype(mx.float32)).reshape(-1).astype('<f4'))
forced_path=args.output/'forced-logits33.f32';np.stack(forced_logits).tofile(forced_path)
record={'target_revision':target.name,'target_root':str(target),'target_files':identity,'mlx_version':importlib.metadata.version('mlx'),'mlx_lm_version':importlib.metadata.version('mlx-lm'),'tokens_sha256':hashlib.sha256(args.tokens.read_bytes()).hexdigest(),'prefix_rows':prefix,'wanted_layers':wanted,'neighbor_layers':neighbors,'captures':rows,'last_logits_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'peak_memory_bytes':mx.get_peak_memory(),'elapsed_seconds':time.perf_counter()-started,'source_sha256':{str(Path(inspect.getsourcefile(cls))):hashlib.sha256(Path(inspect.getsourcefile(cls)).read_bytes()).hexdigest(),str(Path(gated_delta.__file__)):hashlib.sha256(Path(gated_delta.__file__).read_bytes()).hexdigest()},'scope':'Reference uses identical4bit target source tensors, ordinary MLX-LM forward, BF16KV and its normal GDNstate. Captures post-layer residuals at0-based indices and neighbors. This does not compare against BF16training target weights, and is not an end-to-end DSpine acceptance benchmark.'}
record['forced_decode']={'rows':33,'input_positions':[96,127],'predicted_token_positions':[96,128],'sha256':hashlib.sha256(forced_path.read_bytes()).hexdigest(),'scope':'OrdinaryMLX-LM cachedone-tokenforwardswithidenticalforcedtokens; comparesnative8/16teacherforcinglogits,notdraftqualityorBF16trainingweights.'}
(args.output/'record.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True)

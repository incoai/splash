from pathlib import Path
import hashlib,json,shutil,sys
r=Path(__file__).resolve().parents[1];variant=sys.argv[1];tree=r/variant;out=r/'artifacts'/('teacher-'+variant+'-v1');out.mkdir(exist_ok=False);files=['engine-tests/teacher-logits','splash.metallib','host-step.metallib'];record={}
for name in files:
 source=tree/'build'/name;dest=out/Path(name).name;before=hashlib.sha256(source.read_bytes()).hexdigest();shutil.copy2(source,dest);assert before==hashlib.sha256(dest.read_bytes()).hexdigest()==hashlib.sha256(source.read_bytes()).hexdigest();record[name]=before
(out/'manifest.json').write_text(json.dumps(record,indent=2)+'\n');print(out)

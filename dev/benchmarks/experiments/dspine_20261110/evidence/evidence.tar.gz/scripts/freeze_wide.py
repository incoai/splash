from pathlib import Path
import shutil,hashlib,json
r=Path(__file__).resolve().parents[1]; t=r/'wide-policy/build'; out=r/'artifacts/frozen-gdn-compact-v1';out.mkdir(exist_ok=False)
files=['splash','splash.metallib','host-step.metallib','engine-tests/gdn-decode','engine-tests/dspine','engine-tests/draft-attention','engine-tests/weight-digests','engine-tests/backend-benchmark','engine-tests/decode-profile'];record={}
for name in files:
 p=t/name; d=out/name;d.parent.mkdir(parents=True,exist_ok=True);before=hashlib.sha256(p.read_bytes()).hexdigest();shutil.copy2(p,d);assert before==hashlib.sha256(d.read_bytes()).hexdigest()==hashlib.sha256(p.read_bytes()).hexdigest();record[name]=before
(out/'manifest.json').write_text(json.dumps(record,indent=2)+'\n');print(out)

"""Audit recorded round-boundary power sources without changing frozen verdicts."""
from pathlib import Path
import datetime as dt
import json
import subprocess

root = Path(__file__).resolve().parents[1]
observations = []
rounds = []
for path in sorted((root / 'results').glob('*.receipt.json')):
    record = json.loads(path.read_text())
    sources = {}
    for key, time_key in [('power_before', 'start_utc'), ('power_after', 'end_utc')]:
        if key not in record:
            continue
        raw = record[key]
        source = 'battery' if 'Battery Power' in raw else 'AC' if 'AC Power' in raw else 'unknown'
        sources[key] = source
        observations.append({'utc': record.get(time_key), 'job': record['id'], 'boundary': key, 'source': source, 'raw': raw})
    if sources and 'abba-g' in record['id']:
        rounds.append({'id': record['id'], 'start_utc': record.get('start_utc'), 'end_utc': record.get('end_utc'), **sources})
observations.sort(key=lambda row: row['utc'] or '')
transitions = []
previous = None
for row in observations:
    if previous is not None and previous['source'] != row['source']:
        transitions.append({'last_previous_source_observation': previous, 'first_changed_source_observation': row})
    previous = row
out = {'generated_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
       'scope': 'pmset receipts at owned job boundaries, not continuous power-source telemetry. Transitions are bracketed observations; no exact transition time or causal timing effect is established. Frozen native qualification did not gate on AC source. Its verdicts are preserved with this additional limitation; no runs excluded or repeated.',
       'observations': len(observations), 'power_source_changes': transitions,
       'controlled_rounds': sorted(rounds, key=lambda row: row['start_utc'] or ''),
       'current_pmset_custom': subprocess.check_output(['pmset', '-g', 'custom'], text=True),
       'power_mode_scope': 'Current snapshot only; both configured powermode values are 0. Historical mode changes were not continuously observed.'}
(root / 'results/power-source-audit.json').write_text(json.dumps(out, indent=2) + '\n')
print(json.dumps({'observations': len(observations), 'transitions': len(transitions), 'timed_rounds': len(rounds)}))
for prefix in ['block16-vs-m16-abba', 'native-dflash-vs-dspine16-abba', 'native-long-dflash-vs-dspine16-abba']:
    for group in range(1, 4):
        rows = [row for row in rounds if row['id'].startswith(f'{prefix}-g{group}-')]
        print(prefix, group, [(row['id'].rsplit('-', 1)[1], row.get('power_before'), row.get('power_after')) for row in rows])

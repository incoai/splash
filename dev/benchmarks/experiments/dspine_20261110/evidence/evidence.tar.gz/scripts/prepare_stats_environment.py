from pathlib import Path
import hashlib, json, subprocess
r = Path(__file__).resolve().parents[1]
env = r/'stats-venv'; wheels = r/'artifacts/python-wheels'
wheels.mkdir(exist_ok=False)
subprocess.run(['/Users/linson/Documents/ai/splash/.venv/bin/python', '-m', 'venv', str(env)], check=True)
python = env/'bin/python'
subprocess.run([str(python), '-m', 'pip', 'download', '--disable-pip-version-check', '--only-binary=:all:',
                '--dest', str(wheels), 'scipy==1.18.0'], check=True)
subprocess.run([str(python), '-m', 'pip', 'install', '--disable-pip-version-check', '--no-index',
                '--find-links', str(wheels), 'scipy==1.18.0'], check=True)
versions = subprocess.check_output([str(python), '-c',
              'import scipy,numpy,sys,json; print(json.dumps(dict(scipy=scipy.__version__,numpy=numpy.__version__,python=sys.version)))'], text=True)
record = {'versions': json.loads(versions), 'wheels': {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in wheels.glob('*.whl')},
          'documentation': 'https://docs.scipy.org/doc/scipy/reference/generated/scipy.stats.chi2_contingency.html'}
(r/'notes/stats-environment.json').write_text(json.dumps(record, indent=2)+'\n')
print(json.dumps(record))

"""Share one gate/up dequant stage across independent row SIMDgroups."""
from pathlib import Path
import hashlib,json
r=Path(__file__).resolve().parents[1]
helper='''
// Research: SG0 stages gate, SG1 stages up. All row SIMDgroups reuse
// the same two planes, preserving each accumulator's original K walk.
template <class F, ushort Rows, ushort Simdgroups, class Acc>
inline void gguf_staged_pair_shared_steps(device bfloat *input,
    device uchar *gw0, device uchar *gw1, device uchar *gmeta,
    device uchar *uw0, device uchar *uw1, device uchar *umeta, uint input_size,
    uint origin, threadgroup half *stage, threadgroup half2 *tl,
    uint lane, uint simd_group, uint step_begin, uint step_end,
    uint step_first, thread Acc &gate, thread Acc &up) {
  static_assert(Simdgroups == 2 || Simdgroups == 4);
  constexpr ushort Cols = GGUF_STAGED_COLUMNS, KS = GGUF_STAGED_STEP;
  auto a = tensor(input, dextents<int, 2>{int(input_size), Rows}, array<int, 2>{1, int(input_size)});
  constexpr auto descriptor = matmul2d_descriptor(Rows, Cols, KS, false, true, false, matmul2d_descriptor::mode::multiply_accumulate);
  matmul2d<descriptor, execution_simdgroups<1>> operation;
  tensor<threadgroup half, dextents<int, 2>, tensor_inline> bt0(stage, dextents<int, 2>{KS, Cols}, array<int, 2>{1, KS});
  tensor<threadgroup half, dextents<int, 2>, tensor_inline> bt1(stage + KS * Cols, dextents<int, 2>{KS, Cols}, array<int, 2>{1, KS});
  auto bg = bt0.slice<KS, Cols>(0, 0), bu = bt1.slice<KS, Cols>(0, 0);
  const bool loads = simd_group < 2;
  StagedColumn<F> column;
  if (loads) column.begin(simd_group == 0 ? gw0 : uw0, simd_group == 0 ? gw1 : uw1,
      simd_group == 0 ? gmeta : umeta, input_size, origin, lane, step_first, step_begin < step_end);
  const auto run_step = [&](uint step, uint next, bool more) __attribute__((always_inline)) {
    if (loads) column.stage(step, tl, stage + simd_group * KS * Cols, lane);
    threadgroup_barrier(mem_flags::mem_threadgroup);
    if (loads && more) column.load(step, next);
    auto a_slice = a.template slice<KS, Rows>(step * KS, 0);
    operation.run(a_slice, bg, gate);
    operation.run(a_slice, bu, up);
    threadgroup_barrier(mem_flags::mem_threadgroup);
  };
  uint walked = 0;
  for (uint run = 0; run < 2; ++run) {
    const uint from = run ? step_begin : step_first, to = run ? step_first : step_end;
    for (uint step = from; step < to; ++step, ++walked)
      run_step(step, step + 1 < to ? step + 1 : step_begin, walked + 1 < step_end - step_begin);
  }
}

'''
for name in ['gateup-shared8','gateup-shared16']:
 t=r/name;p=t/'runtime/metal/kernels/common/gguf_staged_tile.h';s=p.read_text();marker='// runtime dequantizer selection';assert s.count(marker)==1;s=s.replace(marker,helper+marker);p.write_text(s)
 p=t/'runtime/metal/kernels/shared/gguf_linear.metal';s=p.read_text();a='template <class F, ushort Rows, ushort PartRows = Rows>\nkernel void gguf_decode_gate_up';assert s.count(a)==1;s=s.replace(a,'template <class F, ushort Rows, ushort PartRows = Rows, bool SharedStage = false>\nkernel void gguf_decode_gate_up')
 s=s.replace('const uint row0 = simd_group * PartRows, thread_index = simd_group * 32 + lane;', 'const uint row0 = Simdgroups > 1 ? simd_group * PartRows : 0;\n  const uint thread_index = simd_group * 32 + lane;')
 a='threadgroup half stages[Simdgroups * 2 * GGUF_STAGED_COLUMNS * GGUF_STAGED_STEP];';assert a in s;s=s.replace(a,'threadgroup half stages[(SharedStage ? 1 : Simdgroups) * 2 * GGUF_STAGED_COLUMNS * GGUF_STAGED_STEP];')
 a='threadgroup half *stage = stages + simd_group * 2 * GGUF_STAGED_COLUMNS * GGUF_STAGED_STEP;';assert a in s;s=s.replace(a,'threadgroup half *stage = stages + (SharedStage ? 0 : simd_group) * 2 * GGUF_STAGED_COLUMNS * GGUF_STAGED_STEP;')
 a='  gguf_staged_pair_steps<F, PartRows>(input, gw0, gw1, gmeta, uw0, uw1, umeta, p.input_size, origin, stage, tl, lane, sb,\n                                  se, staged_first_step(group.x / 2, sb, se, p.spread), gate, up);';assert a in s
 b='''  if constexpr (SharedStage)
    gguf_staged_pair_shared_steps<F, PartRows, Simdgroups>(input, gw0, gw1, gmeta, uw0, uw1, umeta,
        p.input_size, origin, stage, tl, lane, simd_group, sb, se,
        staged_first_step(group.x / 2, sb, se, p.spread), gate, up);
  else
'''+a
 s=s.replace(a,b)
 marker='#undef GGUF_DECODE_GATE_UP_FORMAT';a=s.index(marker);s=s[:a]+'''template [[host_name("gguf_decode_af4g64_m32_gate_up_sg2_shared")]] kernel GgufDecodeGateUpKernel gguf_decode_gate_up<FmtAF4G64, 32, 16, true>;
template [[host_name("gguf_decode_af4g64_m64_gate_up_sg2_shared")]] kernel GgufDecodeGateUpKernel gguf_decode_gate_up<FmtAF4G64, 64, 32, true>;
template [[host_name("gguf_decode_af4g64_m64_gate_up_sg4_shared")]] kernel GgufDecodeGateUpKernel gguf_decode_gate_up<FmtAF4G64, 64, 16, true>;
'''+s[a:];p.write_text(s)
 p=t/'runtime/ops/LinearGguf.cpp';s=p.read_text();a='    const std::string suffix = groups > 1 ? "_sg" + std::to_string(groups) : "";';assert s.count(a)==1
 b='''    static const bool sharedStage = [] {
      const char *value = std::getenv("SPLASH_GATE_UP_SHARED");
      if (!value || std::string_view(value) == "0") return false;
      if (std::string_view(value) == "1") return true;
      throw std::invalid_argument("research shared gate/up stage must be0or1");
    }();
    const std::string suffix = groups > 1 ? "_sg" + std::to_string(groups) +
                                           (sharedStage ? "_shared" : "") : "";'''
 s=s.replace(a,b);p.write_text(s)
 print(json.dumps({'variant':name,'shader_sha256':hashlib.sha256((t/'runtime/metal/kernels/shared/gguf_linear.metal').read_bytes()).hexdigest(),'helper_sha256':hashlib.sha256((t/'runtime/metal/kernels/common/gguf_staged_tile.h').read_bytes()).hexdigest()}))

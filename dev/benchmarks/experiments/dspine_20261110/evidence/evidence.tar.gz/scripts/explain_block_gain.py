"""Decompose the completed 8/16 comparison; no new timing or selection."""
from pathlib import Path
import hashlib
import json
root=Path(__file__).resolve().parents[1]
p=root/'results/serial-task-selection-ceiling.json'
d=json.loads(p.read_text())
cycles8,cycles16=1303,1062
wall8,wall16=d['mean_8row_decode_ms'],d['mean_16row_decode_ms']
r={'source_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),
   'primary_decode_tokens':d['primary_decode_tokens'],
   'primary_cycles':{'eight_rows':cycles8,'sixteen_rows':cycles16},
   'mean_decode_wall_ms':{'eight_rows':wall8,'sixteen_rows':wall16},
   'recorded_decode_tokens_per_cycle':{'eight_rows':d['primary_decode_tokens']/cycles8,'sixteen_rows':d['primary_decode_tokens']/cycles16},
   'decode_wall_ms_per_recorded_cycle':{'eight_rows':wall8/cycles8,'sixteen_rows':wall16/cycles16},
   'cycle_count_ratio_8_over_16':cycles8/cycles16,
   'wall_per_cycle_ratio_16_over_8':(wall16/cycles16)/(wall8/cycles8),
   'throughput_ratio':wall8/wall16,
   'scope':'Algebraic decomposition of three completed controlled group means and fixed total cycle counts, not independent GPU-cycle timing or isolated kernel causation. Decode wall excludes TTFT; terminal/partial-cycle bookkeeping stays as recorded. The sixteen-row prototype also changes required path/partition choices; not a pure width-only intervention.'}
(root/'results/block-gain-decomposition.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps(r,indent=2))

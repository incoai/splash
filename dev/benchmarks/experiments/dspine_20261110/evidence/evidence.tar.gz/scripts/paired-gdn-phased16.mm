// Same-library legacy/compact comparison with stable state/tape inputs.
#define main full_gdn_suite_main
#include "/Users/linson/Documents/ai/splash-dspine-investigation-20261110/gdn-phased16/dev/tests/engine/gdn_decode_metal_test.mm"
#undef main
#include <iostream>
#include <string_view>
using splash::metal::ComputeDispatch;
std::vector<uint8_t> snapshot(const Fixture &f) {
  std::vector<uint8_t> result;
  const auto append=[&](const MetalBuffer &b) {
    const auto *p=static_cast<const uint8_t *>(b.contents());
    result.insert(result.end(),p,p+b.sizeBytes());
  };
  append(f.hidden);append(f.tape);
  for(const auto &b:f.next)append(b);
  return result;
}
int main(int argc,char **argv) {
 try {
  if(argc<2||argc>3)throw std::invalid_argument("usage: gdn-compact-benchmark METALLIB [--benchmark]");
  const bool timing=argc==3&&std::string_view(argv[2])=="--benchmark";
  MetalBackend backend(argv[1]);static_assert(kRows==8 || kRows==16);
  for(uint32_t lanes=1;lanes<=4;++lanes)for(uint32_t pending:{0u,1u,kRows/2,kRows}) {
   Fixture f(backend,kShapes.front(),lanes,false);
   CommandGraph seed;GDN::addDecode(seed,f.decodeBuffers(0),f.shape,lanes,0,f.cell.strides(),GdnHeadOrder::Grouped,LinearInput::Plain);
   std::vector<ComputeDispatch> seedOld(seed.dispatches().begin(),seed.dispatches().end());
   for(auto &d:seedOld)d.pipelineName="verify_gdn_fused_legacy";
   backend.preparePipelines(seedOld);
   static_cast<void>(backend.submitCommandAsync(seedOld).wait());
   std::array<uint32_t,kMaxLanes> retained{};retained.fill(pending);f.advance(retained);f.fillPacked();
   CommandGraph graph;GDN::addDecode(graph,f.decodeBuffers(0),f.shape,lanes,0,f.cell.strides(),GdnHeadOrder::Grouped,LinearInput::Plain);
   std::vector<ComputeDispatch> compact(graph.dispatches().begin(),graph.dispatches().end()),legacy=compact;
   for(auto &d:legacy)d.pipelineName="verify_gdn_fused_legacy";
   backend.preparePipelines(compact);backend.preparePipelines(legacy);
   const auto clear=[&] {
    f.clear();for(uint32_t l=0;l<lanes;++l)
     std::memset(static_cast<uint8_t *>(f.tape.contents())+f.tapeLanes[l].stepSlot,0xA5,f.tapeBytes);
   };
   clear();static_cast<void>(backend.submitCommandAsync(legacy).wait());const auto expected=snapshot(f);
   clear();static_cast<void>(backend.submitCommandAsync(compact).wait());
   if(snapshot(f)!=expected)throw std::runtime_error("legacy/compact hidden, state or tape differs bitwise");
   std::cout<<"{\"rows\":"<<kRows<<",\"lanes\":"<<lanes<<",\"pending_rows\":"<<pending<<",\"bitwise_bytes\":"<<expected.size()<<",\"pass\":true}"<<std::endl;
   if(!timing)continue;
   constexpr uint32_t repeats=512;
   const auto round=[&](bool candidate) {
    const auto &one=candidate?compact:legacy;std::vector<ComputeDispatch> many;many.reserve(repeats*one.size());
    for(uint32_t i=0;i<repeats;++i)many.insert(many.end(),one.begin(),one.end());
    return backend.submitCommandAsync(many).wait().gpuSeconds*1000/repeats;
   };
   for(uint32_t i=0;i<3;++i){static_cast<void>(round(false));static_cast<void>(round(true));}
   for(uint32_t group=1;group<=3;++group) {
    const double a1=round(false),b1=round(true),b2=round(true),a2=round(false);
    std::cout<<"{\"rows\":"<<kRows<<",\"lanes\":"<<lanes<<",\"pending_rows\":"<<pending<<",\"group\":"<<group
      <<",\"repeats\":"<<repeats<<",\"abba_gpu_ms_per_layer\":["<<a1<<','<<b1<<','<<b2<<','<<a2<<"]}"<<std::endl;
   }
  }
  return 0;
 }catch(const std::exception &e){std::cerr<<"gdn_compact_benchmark: FAIL: "<<e.what()<<'\n';return 1;}
}

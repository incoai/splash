from pathlib import Path
import hashlib,json,shutil,subprocess,sys
r=Path(__file__).resolve().parents[1];name=sys.argv[1];tree=r/name;build=tree/'build';out=r/'artifacts'/('study-'+name+'-v1');out.mkdir(exist_ok=False)
inputs=[r/'scripts/study_driver.mm',build/'engine/libsplash.a',build/'engine/BuildIdentity.hpp',build/'splash.metallib'];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();before={str(p):sha(p) for p in inputs}
command=['xcrun','-sdk','macosx','clang++','-std=c++20','-O3','-Wall','-Wextra','-Werror','-I'+str(tree/'runtime'),'-I/Users/linson/Documents/ai/splash/dev/benchmarks','-mmacosx-version-min=26.4','-fobjc-arc','-include',str(build/'engine/BuildIdentity.hpp'),str(inputs[0]),str(inputs[1]),'-framework','Foundation','-framework','Metal','-framework','IOKit','-framework','IOSurface','-o',str(out/'study-driver')]
subprocess.run(command,check=True)
for file in ['splash.metallib','host-step.metallib']:shutil.copy2(build/file,out/file)
assert before=={str(p):sha(p) for p in inputs}
(out/'build.json').write_text(json.dumps({'variant':name,'command':command,'inputs':before,'binary_sha256':sha(out/'study-driver')},indent=2)+'\n');print(out)

from pathlib import Path
import json,sys
r=Path(__file__).resolve().parents[1]
a=json.loads((r/'results/weights-stock4.stdout').read_text());b=json.loads((r/'results/weights-lab4-v2.stdout').read_text())
assert a==b, 'Default precision must preserve all target and draft images byte-for-byte'
print(json.dumps({'pass':True,'identical_images':len(a)}))

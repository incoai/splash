"""Describe count/quality screens. These timings are unpaired and unqualified."""
from pathlib import Path
import argparse, hashlib, json, sys
sys.path.insert(0, '/Users/linson/Documents/ai/splash')
from dev.benchmarks.draft_acceptance import prefix_profile

def metrics(document):
    result = {}
    positions = document['geometry']['verify_rows']-1
    for m in document['measurements']:
        tokens = m['output_tokens']
        key = m['scenario']+':'+str(m['sample'])
        dt = m['wall_ms']-m['ttft_ms']
        result[key] = {'scenario': m['scenario'], 'sample': m['sample'],
                       'tokens': len(tokens), 'token_sha256': hashlib.sha256(json.dumps(tokens, separators=(',', ':')).encode()).hexdigest(),
                       'decode_tokens': max(0, len(tokens)-1), 'decode_wall_ms': dt,
                       'gpu_ms': m['decode_gpu_ms'], 'cycles': len(m.get('draft_cycles', [])),
                       'profile': prefix_profile(m['draft_cycles'], positions) if m.get('draft_cycles') else None}
    return result

def compare(a, b):
    aa, bb = metrics(a), metrics(b)
    assert aa.keys() == bb.keys(), 'cohorts differ'
    rows = []
    for key in aa:
        av, bv = aa[key], bb[key]
        rows.append({'key': key, 'outputs_match': av['token_sha256'] == bv['token_sha256'],
                     'baseline': av, 'candidate': bv,
                     'cycle_change': bv['cycles']-av['cycles'],
                     'descriptive_wall_ratio': bv['decode_wall_ms']/av['decode_wall_ms']})
    def total(side):
        values = [row[side] for row in rows if row[side]['scenario'] != 'count_secondary']
        return {'decode_tokens': sum(v['decode_tokens'] for v in values),
                'cycles': sum(v['cycles'] for v in values),
                'decode_wall_ms': sum(v['decode_wall_ms'] for v in values)}
    return {'method': 'Single unpaired screening runs; descriptive counts and timings only. Exclude predeclared count_secondary from primary totals. Final and partial cycles censored in profiles.',
            'all_outputs_match': all(row['outputs_match'] for row in rows),
            'baseline': total('baseline'), 'candidate': total('candidate'), 'cases': rows}

if __name__ == '__main__':
    p = argparse.ArgumentParser(); p.add_argument('baseline', type=Path); p.add_argument('candidate', type=Path); p.add_argument('output', type=Path)
    args = p.parse_args(); result = compare(json.loads(args.baseline.read_text()), json.loads(args.candidate.read_text()))
    args.output.write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps({k: v for k, v in result.items() if k != 'cases'}))

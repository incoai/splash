"""Summarize every registered HTTP ABBA group without repeat-to-pass."""
from pathlib import Path
import json, sys
sys.path.insert(0, '/Users/linson/Documents/ai/splash')
from dev.benchmarks.draft_comparison import summarize, NAMES
r = Path(__file__).resolve().parents[1]
prefix, output = sys.argv[1:]
groups = []
for group in range(1, 4):
    names = [f'{prefix}-g{group}-{suffix}' for suffix in ('a1','b1','b2','a2')]
    rounds=[]; problems=[]
    for ident in names:
        receipt=json.loads((r/f'results/{ident}.receipt.json').read_text())
        if receipt['exit_code'] or receipt['state'] != 'complete': problems.append(ident+': incomplete job')
        d=json.loads((r/f'http/{ident}/{ident}.json').read_text()); rounds.append(d)
        state=json.loads((r/f'results/{ident}.operating.json').read_text())
        if not all(state.get(k,False) for k in ['operating_gate_passed','no_serious_or_critical_state','no_swap']): problems.append(ident+': operating gate')
    comparison=summarize(rounds)
    target_match=all(d['target_sources']==rounds[0]['target_sources'] for d in rounds)
    outputs_match=all(d[mode][name]['output_sha256']==rounds[0][mode][name]['output_sha256'] and d[mode][name]['usage']['completion_tokens']==rounds[0][mode][name]['usage']['completion_tokens'] for d in rounds for mode in ['solo','batch'] for name in NAMES)
    if not target_match: problems.append('target source identity differs')
    if not outputs_match: problems.append('greedy outputs or token counts differ')
    metrics=comparison['milliseconds_per_token']
    all_noise=all(v['noise']<=0.05 for v in metrics.values())
    if not all_noise: problems.append('at least one metric has >5% ABBA spread')
    effects={key:{**v,'throughput_change':v['baseline']/v['candidate']-1,
                 'positive_effect_pass':v['noise']<=0.05 and -v['regression']>v['bound']} for key,v in metrics.items()}
    groups.append({'group':group,'rounds':names,'problems':problems,'target_source_identity_matches':target_match,
                   'all_output_hashes_and_counts_match':outputs_match,'all_metric_noise_gates_pass':all_noise,
                   'metrics':effects,'round_decode_width_deltas':[d['decode_width_deltas'] for d in rounds]})
record={'prefix':prefix,'groups':groups,'interpretation':'All registered groups retained. Positive effect requires latency improvement strictly above max(2%,2x spread). Report solo and concurrent endpoints separately; neither implies universal workload improvement.'}
(r/output).write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps([{k:g[k] for k in ['group','problems']} | {'effects':{k:{f:v[f] for f in ['throughput_change','noise','positive_effect_pass']} for k,v in g['metrics'].items() if k in ['combined_solo','four_concurrent']}} for g in groups],indent=2))

"""Summarize complete retained telemetry after the requested window ends."""
from collections import Counter
from pathlib import Path
import datetime as dt
import hashlib
import json

root = Path(__file__).resolve().parents[1]
assert dt.datetime.now(dt.timezone.utc) >= dt.datetime(2026, 11, 10, 11, 18, 48, tzinfo=dt.timezone.utc)
path = root / 'results/hardware.jsonl'
h = hashlib.sha256()
first = last = previous = None
count = 0
phases = Counter()
gaps = []
maximum_gap = 0
maximum_swap = 0
maximum_temperature = 0
for raw in path.open('rb'):
    h.update(raw)
    row = json.loads(raw)
    timestamp = row['recorded_unix']
    if first is None:
        first = timestamp
    if previous is not None:
        gap = timestamp - previous
        maximum_gap = max(maximum_gap, gap)
        if gap > 10:
            gaps.append({'before_unix': previous, 'after_unix': timestamp, 'seconds': gap})
    previous = last = timestamp
    count += 1
    phases[row.get('investigation_phase', 'unknown')] += 1
    maximum_swap = max(maximum_swap, row['memory']['swap_usage'])
    maximum_temperature = max(maximum_temperature, row['temp']['gpu_temp_avg'])
record = {'first_utc': dt.datetime.fromtimestamp(first, dt.timezone.utc).isoformat(),
          'last_utc': dt.datetime.fromtimestamp(last, dt.timezone.utc).isoformat(),
          'records': count, 'bytes': path.stat().st_size, 'sha256': h.hexdigest(),
          'maximum_sample_gap_seconds': maximum_gap, 'sample_gaps_over_ten_seconds': gaps,
          'maximum_observed_swap_bytes': maximum_swap, 'maximum_observed_gpu_temperature_c': maximum_temperature,
          'records_by_phase': dict(sorted(phases.items())),
          'scope': 'Original macmon samples retained without exclusions. Telemetry starts about2m31s after the requested eight-hour window begins; initialization before that is not covered. Job-boundary pmset power observations are separate. Sampling is observational and is not proof of causal process attribution or constant GPU frequency.'}
(root/'results/hardware-trace-audit.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:v for k,v in record.items() if k!='records_by_phase'},indent=2))

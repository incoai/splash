"""Record a clean startup's memory plan with the same settings as HTTP comparisons."""
from pathlib import Path
import json,signal,subprocess,sys,time
sys.path.insert(0,'/Users/linson/Documents/ai/splash')
from dev.tests import smoke_real as smoke
r=Path(__file__).resolve().parents[1];ident,binary=sys.argv[1:];out=r/'http'/ident;out.mkdir(parents=True,exist_ok=False);root=Path('/Users/linson/Documents/ai/splash/build/dspine/model-root.txt').read_text().strip();port=smoke.available_port()
command=[sys.executable,'-m','server.server',root,'--binary',binary,'--host','127.0.0.1','--port',str(port),'--max-context','32768','--kv-format','int8','--state-format','fp32','--disable-ane','--verify-rows','all','--persistent-cache','--cache-dir',str(out/'cache'),'--max-cache-disk','4G']
with (out/'server.log').open('w') as log:
 p=subprocess.Popen(command,cwd='/Users/linson/Documents/ai/splash',stdout=log,stderr=subprocess.STDOUT)
 try:
  deadline=time.monotonic()+300
  while time.monotonic()<deadline:
   smoke.require(p.poll() is None,'server exited during startup')
   try:
    code,status=smoke.request(port,'GET','/status',timeout=1)
    if code==200 and status.get('ready'):break
   except (OSError,smoke.SmokeFailure):pass
   time.sleep(.25)
  else:raise RuntimeError('startup timeout')
  smoke.validate_status(status,'int8');(out/'status.json').write_text(json.dumps(status,indent=2)+'\n');print(json.dumps({'id':ident,'memory_plan':status['memory_plan'],'maximum_context_tokens':status['maximum_context_tokens']}),flush=True)
 finally:
  if p.poll() is None:p.send_signal(signal.SIGINT)
  try:p.wait(timeout=30)
  except subprocess.TimeoutExpired:p.terminate();p.wait(timeout=10)
  smoke.require(p.returncode==0,'server didnot close cleanly')

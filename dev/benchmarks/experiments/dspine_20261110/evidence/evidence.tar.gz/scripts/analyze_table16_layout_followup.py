"""Summarize every packing-follow-up attempt, including incomplete/failed jobs."""
from pathlib import Path
import hashlib,json
r=Path(__file__).resolve().parents[1]
rows={}
for ident in ['build-table16-layout-followup-v1','table16-layout-full-gdn-shader-v1']:
    p=r/f'results/{ident}.receipt.json'
    if not p.exists():
        rows[ident]={'status':'not_completed_in_window'}
        continue
    d=json.loads(p.read_text());o=r/f'results/{ident}.stdout';e=r/f'logs/{ident}.stderr'
    rows[ident]={k:d.get(k) for k in ['state','exit_code','elapsed_seconds','start_utc','end_utc']}
    rows[ident]['stdout_sha256']=hashlib.sha256(o.read_bytes()).hexdigest() if o.exists() else None
    rows[ident]['stderr_sha256']=hashlib.sha256(e.read_bytes()).hexdigest() if e.exists() else None
    if ident.startswith('table16-'):
        rows[ident]['output_tail']=o.read_text()[-2000:] if o.exists() else ''
d={'attempts':rows,'full_gdn_shader_pass':all(row.get('state')=='complete' and row.get('exit_code')==0 for row in rows.values()),
   'scope':'Narrow Table16 packing/producer repair only. Existing full16 suite, unchanged numerical tolerances and extent/replay checks. Does not enable or validate register consumers or qualify performance. Original failed global16 Table16 trial remains retained.'}
(r/'results/table16-layout-followup-summary.json').write_text(json.dumps(d,indent=2)+'\n')
print(json.dumps(d,indent=2))

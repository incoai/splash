"""Exercise real scheduler preemption with four background clones and one foreground request."""
from pathlib import Path
r=Path(__file__).resolve().parents[1];s=(r/'scripts/study_driver.mm').read_text();s=s.replace('#include <algorithm>','#include <algorithm>\n#include <cstdlib>')
insert=s.index('\nvoid emitMeasurement')
helper=r'''
void priorityPreemptionCase(engine::Engine &engine, Driver &driver, model::RuntimeModel &executor,
                           Events &events, uint64_t &nextId, const StudyCase &c) {
  // Exactly as the native fixed-width benchmark, publish the shared prefix
  // before submitting clones so the first decode starts at physical B4.
  static_cast<void>(runRequest(engine, driver, executor, events, nullptr, nextId++,
                              c.name+"_warm", 0, c.tokens, 1));
  const EngineSnapshot before=engine.snapshot();
  const double began=milliseconds(Clock::now());
  std::array<uint64_t,4> ids{};
  for(uint32_t lane=0;lane<4;++lane) {
    EngineRequest request;request.id=ids[lane]=nextId++;request.prompt=c.tokens;
    request.maxNewTokens=c.cap;request.priority=RequestPriority::Background;
    request.sampling.temperature=0;request.sampling.topP=1;
    request.deadlineMilliseconds=began+600000;
    engine.submit(std::move(request));
  }
  bool injected=false;uint64_t foreground=0;std::vector<uint32_t> widths;
  driver.untilIdle([&](const BatchObservation &batch) {
    if(batch.kind!=WorkKind::Decode)return;
    widths.push_back(batch.width);
    if(!injected&&batch.width==4) {
      if(engine.commandInFlight())throw std::logic_error("priority probe crossed a command");
      EngineRequest urgent;urgent.id=foreground=nextId++;
      const auto prompt=benchmark::kDraftComparisonPrompts[0];urgent.prompt.assign(prompt.begin(),prompt.end());
      urgent.maxNewTokens=1;urgent.priority=RequestPriority::Foreground;
      urgent.sampling.temperature=0;urgent.sampling.topP=1;
      urgent.deadlineMilliseconds=began+600000;engine.submit(std::move(urgent));injected=true;
    }
  });
  const EngineSnapshot after=engine.snapshot();
  if(!injected||after.prioritySuspensions<=before.prioritySuspensions||
     after.resourceResumptions<=before.resourceResumptions||after.resourceReplayTokens<=before.resourceReplayTokens)
    throw std::runtime_error("priority probe observed no complete suspension/replay/resumption");
  const auto &reference=events.get(ids[0]);
  for(uint64_t id:ids) {
    const auto &actual=events.get(id);
    if(!actual.completed||!actual.failure.empty()||actual.outputTokens.size()!=c.cap||actual.outputTokens!=reference.outputTokens)
      throw std::runtime_error("preempted and uninterrupted clones differ or failed");
  }
  if(!events.get(foreground).completed||!events.get(foreground).failure.empty())
    throw std::runtime_error("foreground probe failed");
  const char *path=std::getenv("SPLASH_TEST_PREEMPT_LOG");if(!path)throw std::runtime_error("probe needs result log");
  std::ofstream out(path,std::ios::app);
  out<<"{\"scenario\":\""<<c.name<<"\",\"prompt_tokens\":"<<c.tokens.size()
     <<",\"priority_suspensions\":"<<after.prioritySuspensions-before.prioritySuspensions
     <<",\"resumptions\":"<<after.resourceResumptions-before.resourceResumptions
     <<",\"replay_tokens\":"<<after.resourceReplayTokens-before.resourceReplayTokens
     <<",\"all_four_output_arrays_match\":true,\"decode_widths\":[";
  for(size_t i=0;i<widths.size();++i){if(i)out<<',';out<<widths[i];}
  out<<"],\"outputs\":[";
  for(size_t lane=0;lane<ids.size();++lane){if(lane)out<<',';out<<'[';const auto &tokens=events.get(ids[lane]).outputTokens;
    for(size_t i=0;i<tokens.size();++i){if(i)out<<',';out<<tokens[i];}out<<']';}
  out<<"]}\n";if(!out)throw std::runtime_error("cannot write priority probe result");
}
'''
s=s[:insert]+helper+s[insert:]
start=s.index('    if (selected.study) {');end=s.index('\n    // The full-vocabulary logits',start)
s=s[:start]+'''    if (selected.study) {
      if (!cohort) throw std::invalid_argument("priority probe requires --cohort");
      for (const auto &c : readStudy(*cohort)) {
        evictAllCache(resources->cache());
        priorityPreemptionCase(engine, driver, *executor, events, requestId, c);
      }
    }
'''+s[end:]
(r/'scripts/priority_driver.mm').write_text(s)
s=(r/'scripts/build_study_wide.py').read_text().replace("f'study-{name}'","'study-priority16'").replace('scripts/study_driver.mm','scripts/priority_driver.mm');(r/'scripts/build_priority_study.py').write_text(s)
print('Generated priority_driver.mm')

"""Check the public standalone analyzer against every final saved native verdict."""
from pathlib import Path
import hashlib
import math
import json
import subprocess

r=Path(__file__).resolve().parents[1]
script=r/'publication/experiments/dspine_20261110/analyze_native.py'
rows=[]
maximum_absolute_difference=0.0
def equivalent(a,b):
    global maximum_absolute_difference
    if isinstance(a,bool) or isinstance(b,bool):return type(a)==type(b) and a==b
    if isinstance(a,(float,int)) and isinstance(b,(float,int)):
        maximum_absolute_difference=max(maximum_absolute_difference,abs(a-b))
        return math.isclose(a,b,rel_tol=1e-12,abs_tol=1e-12)
    if isinstance(a,dict) and isinstance(b,dict):return a.keys()==b.keys() and all(equivalent(a[k],b[k]) for k in a)
    if isinstance(a,list) and isinstance(b,list):return len(a)==len(b) and all(equivalent(x,y) for x,y in zip(a,b))
    return a==b
for name,prefix in [('m16-abba-final','m16-abba'),('block16-vs-m16-final','block16-vs-m16-abba'),('native-dflash-vs-dspine16-abba-final','native-dflash-vs-dspine16-abba'),('native-long-dflash-vs-dspine16-abba-final','native-long-dflash-vs-dspine16-abba')]:
    source=r/f'results/{name}.json'
    destination=r/f'results/{name}-portable.json'
    subprocess.run(['/Users/linson/Documents/ai/splash/.venv/bin/python',str(script),str(r),prefix,'--output',str(destination)],check=True,stdout=subprocess.DEVNULL)
    a=json.loads(source.read_text());b=json.loads(destination.read_text())
    assert a['qualified']==b['qualified'] and equivalent(a['groups'],b['groups']),name
    rows.append({'prefix':prefix,'qualified':a['qualified'],'all_gate_decisions_exact':True,'metrics_equivalent_1e12':True,'original_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'portable_sha256':hashlib.sha256(destination.read_bytes()).hexdigest()})
record={'script_sha256':hashlib.sha256(script.read_bytes()).hexdigest(),'comparisons':rows,'maximum_absolute_numeric_difference':maximum_absolute_difference,'scope':'Every output/operating/noise decision and three-group verdict is exact. All numeric fields agree within1e-12 relative/absolute audit tolerance; Verified Python3.9 versus3.14 built-in float summation causes last-bit aggregate differences. This audit tolerance does not change any qualification gate. Explanatory scope text is not compared.'}
(r/'notes/portable-native-analyzer-validation.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))

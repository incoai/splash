"""Build a compact public index; original evidence remains independently hashed."""

from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--root", type=Path, default=Path(__file__).resolve().parents[1]
    )
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--final", action="store_true")
    args = parser.parse_args()
    root = args.root
    sources = {}

    def read(relative):
        path = root / relative
        if not path.exists():
            return {"status": "pending", "source": relative}
        data = path.read_bytes()
        sources[relative] = {
            "bytes": len(data),
            "sha256": hashlib.sha256(data).hexdigest(),
        }
        return json.loads(data)

    def result(name):
        return read("results/" + name + ".json")

    def native(name):
        record = result(name)
        if "groups" not in record:
            return record
        groups = [
            {k: v for k, v in g.items() if k != "cases"} for g in record["groups"]
        ]
        for original, group in zip(record["groups"], groups):
            if "cases" in original:
                primary = [c for c in original["cases"] if not c["key"].startswith("count_secondary:")]
                group["primary_cycle_counts_by_round"] = [sum(c["cycles"][i] for c in primary) for i in range(4)]
            if "primary_abba_milliseconds_per_token" in group:
                metric = group["primary_abba_milliseconds_per_token"]
                group["baseline_decode_tokens_per_second"] = 1000 / metric["baseline"]
                group["candidate_decode_tokens_per_second"] = 1000 / metric["candidate"]
        return {k: v for k, v in record.items() if k != "groups"} | {"groups": groups}

    def counts(name):
        record = result(name)
        return {k: v for k, v in record.items() if k != "cases"}

    def paired(name, width):
        record = result(name)
        if "results" not in record:
            return record
        chosen = [
            row
            for row in record["results"]
            if row["lanes"] == 4 and row["pending_rows"] == width
        ]
        return {
            "method": record["method"],
            "selected_scope": f"B4, pending {width}",
            "selected_groups": chosen,
            "all_groups_in_original_evidence": True,
        }

    sampling = result("sampling-comparison")
    if "results" in sampling:
        tests = sampling.pop("results")
        sampling.update(
            informative_tests=sum(t["informative"] for t in tests),
            uninformative_tests=sum(not t["informative"] for t in tests),
            minimum_raw_pvalue=min(t["pvalue"] for t in tests),
            minimum_holm_adjusted_pvalue=min(t["holm_adjusted_pvalue"] for t in tests),
        )
    failed = []
    receipts = []
    for path in sorted((root / "results").glob("*.receipt.json")):
        record = json.loads(path.read_text())
        receipts.append(record)
        if record["exit_code"] == 0:
            continue
        annotation = "See retained receipt, stdout and stderr."
        if record["exit_code"] == 125:
            annotation = "Prerequisite failed; job did not run."
        elif record["exit_code"] in (123, 124):
            annotation = (
                "Invalid artifact identity; excluded from performance conclusions."
            )
        else:
            stdout = root / "results" / (record["id"] + ".stdout")
            if stdout.exists():
                try:
                    document = json.loads(stdout.read_text())
                    if (
                        isinstance(document, dict)
                        and document.get("performance_pass") is False
                    ):
                        annotation = "Complete numerical output; native performance/scaling gate failed."
                except (ValueError, UnicodeError):
                    pass
        failed.append(
            {
                "id": record["id"],
                "state": record["state"],
                "exit_code": record["exit_code"],
                "annotation": annotation,
            }
        )

    lifecycle_document = read("http/block16-long-lifecycle-shader-v1/result.json")
    lifecycle = {k: v for k, v in lifecycle_document.items() if k != "server_runs"}
    lifecycle["server_exit_codes"] = [
        run.get("exit_code") for run in lifecycle_document.get("server_runs", [])
    ]
    priority_path = root / "results/priority16-preemption-shader-v1.events.jsonl"
    priority = []
    if priority_path.exists():
        data = priority_path.read_bytes()
        sources[str(priority_path.relative_to(root))] = {
            "bytes": len(data),
            "sha256": hashlib.sha256(data).hexdigest(),
        }
        for event in map(json.loads, data.decode().splitlines()):
            row = {
                k: v for k, v in event.items() if k not in {"outputs", "decode_widths"}
            }
            row["output_array_sha256"] = [
                hashlib.sha256(
                    json.dumps(tokens, separators=(",", ":")).encode()
                ).hexdigest()
                for tokens in event["outputs"]
            ]
            priority.append(row)
    memory8_document = read("http/dspine8-memory-status-v2/status.json")
    memory16_document = lifecycle_document.get("server_runs", [{}])[0].get(
        "status_start", {}
    )
    http_memory = {}
    for key, document in [
        ("dspine8", memory8_document),
        ("dspine16", memory16_document),
    ]:
        if "memory_plan" in document:
            plan = document["memory_plan"]
            http_memory[key] = {
                "configured_context_tokens": document["maximum_context_tokens"],
                "intrinsic_context_tokens": plan["maximum_context_tokens"],
                "model_memory": plan["model"]["memory"],
                "budget": plan["budget"],
            }

    record = {
        "schema_version": 1,
        "status": "complete" if args.final else "work_in_progress",
        "generated_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
        "requested_research_window_utc": [
            "2026-11-10T03:18:48Z",
            "2026-11-10T11:18:48Z",
        ],
        "machine": {
            "chip": "Apple M5 Pro",
            "cpu_cores": 18,
            "gpu_cores": 20,
            "memory_gib": 48,
            "macos": "26.6",
            "metal": "4",
            "power": "AC and battery; see round-boundary audit",
        },
        "source": {
            "research_base": "33a488d4bbb3978b32b34e8bfc6cefa92e350d7f",
            "shipping_source_commit": "0a90d7b4caf725ee4f27afcd37f6d827d05a6300",
            "shipping_scope": "Eight-row DSpine with previously committed parallel refinement. The only additional shipping code in this eight-hour study is the benchmark draft-window fix; wider geometry and kernel alternatives are source-only research patches.",
            "pull_request": "https://github.com/incoai/splash/pull/731",
            "issue": "https://github.com/incoai/splash/issues/724",
        },
        "models": {
            "target": {
                "repository": "mlx-community/Qwen3.8-27B-4bit",
                "revision": "10c35caafbb80f7dc6a7a432cdd11af10a6d4818",
            },
            "dflash": {
                "repository": "incoai/Qwen3.8-27B-DFlash2",
                "revision": "015e795645c74b1a0eeef3b570031fb62e769bc5",
                "draft_context_tokens": 2048,
            },
            "dspine": {
                "repository": "tencent/Qwen3.8-27B-DSpine-b16",
                "revision": "5f54174d301dbca65d9aa4448dc47e56732d9a12",
                "draft_context_tokens": 8192,
            },
            "target_identity_scope": "All 66 loaded target images agree byte for byte across drafter installs. Prepared-installation target_model_sha256 includes draft provenance and is not a pure tensor hash.",
        },
        "settings": {
            "target_context_tokens": 32768,
            "target_precision": "affine 4-bit, group 64",
            "default_draft_precision": "affine 4-bit, group 64; BF16 DSpine bridge",
            "kv_format": "int8",
            "recurrent_state": "fp32",
            "ane_ffn_share": 0,
        },
        "method": {
            "short_corpus": "31 historical tasks, 30 primary plus count_secondary control; prompts 33-78 tokens, caps 384-1024. Reused calibration corpus, not independent validation.",
            "heldout": "12 fresh prompts, 46-85 input tokens, caps 256-512. Frozen before use, used once. Output agreement only; no human quality grading.",
            "long_corpus": "Two repository-source excerpts, 8193/16385 tokens, 256/384 caps. Original four-case protocol narrowed before any long run/output to fit three groups inside8h, preserving prose/code and length endpoints. Distinct native serial comparison; not a rerun of failed HTTP groups.",
            "native_positive_gate": "Exactly three fixed ABBA groups; full output equality, all per-case/control spreads <=5%, operating checks, aggregate latency improvement strictly >max(2%, twice endpoint spread), every group required.",
            "telemetry": "Continuous macmon plus NSProcessInfo observations; one GPU job at a time. No heavy builds during controlled timing groups. Foreign applications were not stopped. Nominal thermal state alone does not establish constant GPU frequency.",
            "sampling": "Independent seeds, 1500 per context per arm, three contexts, 18-token cap. All candidate configurations frozen before candidate dataset outputs. Pearson chi-square with symmetric pooling and Holm across 234 reserved tests; finite regression screen, not equivalence proof.",
        },
        "native_comparisons": {
            "m16_vs_stock8": native("m16-abba-final"),
            "trained16_vs_m16_8": native("block16-vs-m16-final"),
            "dflash8_vs_dspine16_short": native("native-dflash-vs-dspine16-abba-final"),
            "dflash8_vs_dspine16_long": native(
                "native-long-dflash-vs-dspine16-abba-final"
            ),
        },
        "cycle_cost_decomposition": result("block-gain-decomposition"),
        "table16_packing_followup": result("table16-layout-followup-summary"),
        "precision_and_fidelity_screens": {
            name: counts(name)
            for name in [
                "all3-cohort31-v1-summary",
                "all8-cohort31-v1-summary",
                "bf16-cohort31-v1-summary",
                "bridge-parity-cohort31-v1-summary",
                "head2-cohort31-v2-summary",
                "head3-cohort31-v2-summary",
                "head4-cohort31-v1-summary",
            ]
        },
        "heldout_screens": {
            name: counts(name)
            for name in [
                "heldout-dspine8-vs16-summary",
                "heldout-dflash-vs-dspine16-summary",
            ]
        },
        "matched_prefix": {
            k: v
            for k, v in result("fixed-prefix-summary").items()
            if k not in {"cases", "protocol"}
        },
        "http_comparisons": {
            name: result(name)
            for name in ["http-wide-policy-final", "http-dflash-vs-dspine16-final"]
        },
        "power_source_audit": result("power-source-audit"),
        "hardware_trace_audit": result("hardware-trace-audit"),
        "external_feedback": read("notes/external-feedback-20261110.json"),
        "matched_drafters": counts("matched-drafter-prefix-comparison"),
        "batch_width_diagnostic": result("batch-width-output-diagnostic"),
        "kernel_screens": {
            "gdn_compact": paired("gdn-compact-paired-summary", 8),
            "gdn_phased8": paired("gdn-phased8-paired-summary", 8),
            "gdn_phased16": paired("gdn-phased16-paired-summary", 16),
            "gateup_shared8": result("gateup-shared8-native-screen-summary"),
            "gateup_shared16": result("gateup-shared16-native-screen-summary"),
            "ordinary_projection_rows": result("linear-shared16-native-screen-summary"),
            "inactive_mlp_scope_control": result(
                "linear-mlp64-inactive-screen-summary"
            ),
        },
        "sampling": sampling,
        "sampling_data_audit": result("sampling-data-audit"),
        "functional": {
            "long_http_lifecycle": lifecycle,
            "priority_suspension_replay": priority,
            "scope": "Priority replay passed five cases; the distinct earlier synthetic memory-pressure probe failed to trigger suspension and is not validated.",
        },
        "http_memory_comparison": http_memory,
        "portable_reproduction": result("portable-reproduction-validation"),
        "portable_analysis_validations": {"native": read("notes/portable-native-analyzer-validation.json"), "sampling": read("notes/portable-sampling-analyzer-validation.json")},
        "feature_diagnostic": result("target-capture-comparison"),
        "batch_target_logits": result("batch-target-logit-comparison"),
        "long_context_profiles": result("long-context-profile-summary"),
        "long_context_cold_latency_descriptive": result("long-context-ttft-descriptive"),
        "geometry_boundaries": counts("geometry-boundaries-dspine16-v1-summary"),
        "rollout_blockers": [
            "Global sixteen-row prototype; supported per-model geometry is still required.",
            "Original global16 Table16 GDN suite has an out-of-bounds store. The narrow packing-only repair passes the full sixteen-row GDN shader suite; register consumer tile counts/selection and per-model geometry remain unsupported. Register paths stay disabled in measured prototypes.",
            "Concurrent performance/scaling and width-dependent target numerics require separate qualification.",
            "Only one GPU, model target, precision and KV/state configuration measured.",
        ],
        "memory": {
            "native8_dynamic_budget_bytes": 20551060608,
            "native16_dynamic_budget_bytes": 20277722240,
            "dynamic_budget_reduction_bytes": 273338368,
            "scope": "Native no-ANE configured32K comparison. About260.7MiB; dynamic budget is not a fixed allocation. HTTP persistent-cache staging is separate. Intrinsic capacity is not the configured context limit.",
        },
        "plan": read("notes/improvement-plan-v3.json"),
        "receipt_inventory": {
            "count": len(receipts),
            "nonzero_or_skipped": failed,
            "scope": "Includes builds, analyses and functional/performance trials. A nonzero native performance gate is distinguished from numerical failure; skipped jobs did not run.",
        },
        "evidence": {
            "report": "../experiments/dspine_20261110/README.md",
            "source_manifest": "../experiments/dspine_20261110/source-manifest.json",
            "raw_manifest": "../experiments/dspine_20261110/evidence/evidence-manifest.json",
            "raw_archive": "../experiments/dspine_20261110/evidence/evidence.tar.gz",
            "hardware_archive": "../experiments/dspine_20261110/evidence/hardware.jsonl.gz",
        },
        "indexed_source_files": sources,
    }
    if args.final:
        deadline = dt.datetime(2026, 11, 10, 11, 18, 48, tzinfo=dt.timezone.utc)
        assert dt.datetime.now(dt.timezone.utc) >= deadline, (
            "Eight-hour window is not finished"
        )
        assert "results" not in record["sampling"], "Sampling index should be compact"
        for key, value in record["native_comparisons"].items():
            assert "groups" in value, "Missing final native verdict: " + key
        assert "summaries" in record["matched_drafters"], "Missing matched-prefix analysis"
        assert record["portable_reproduction"].get("fresh_model_checks"), "Missing fresh reproduction validation"
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(record, indent=2) + "\n")
    print(
        json.dumps(
            {
                "status": record["status"],
                "indexed_sources": len(sources),
                "receipts": len(receipts),
                "retained_nonzero_or_skipped": len(failed),
            }
        )
    )


if __name__ == "__main__":
    main()

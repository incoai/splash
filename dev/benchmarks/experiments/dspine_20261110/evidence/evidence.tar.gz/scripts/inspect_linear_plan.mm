#include "ops/KernelSelection.hpp"
#include <array>
#include <iostream>
using namespace splash::ops;
int main() {
  KernelCalibration calibration{20, kApple10Projection, kApple10FloatTile, kApple10Moe, kAttention};
  UnitFormats tensor{.weightBits16=72};
  UnitFormats pair=tensor;pair.oneFormat=true;
  std::array<UnitFormats,2> tensors{tensor,tensor};
  for(uint32_t rows:{16u,32u,48u,64u}) {
    LinearWorkload workload{{17408,5120},rows};workload.epilogue=LinearEpilogue::GateUp;
    const auto config=selectProjection(calibration,workload,pair,tensors);
    std::cout<<"{\"rows\":"<<rows<<",\"splits\":"<<config.splits<<",\"one_pass\":"<<(config.oneGateUpPass?"true":"false")<<",\"spread\":"<<(config.spread?"true":"false")<<"}\n";
  }
}

"""Check selected rows of the frozen draft-head source against MLX dequantize."""
from pathlib import Path
import json, struct
import mlx.core as mx
import numpy as np
r = Path(__file__).resolve().parents[1]
record = json.loads((r/'results/head-source.json').read_text())
root = Path(record['source_root'])
def tensors(path):
    with path.open('rb') as f:
        n = struct.unpack('<Q', f.read(8))[0]; header = json.loads(f.read(n))
    return header, 8+n
found = {}
for path in (root/'target').glob('*.safetensors'):
    header, start = tensors(path)
    for name, meta in header.items():
        if name.startswith('language_model.lm_head.'):
            found[name.rsplit('.', 1)[-1]] = np.memmap(path, mode='r', offset=start+meta['data_offsets'][0],
                 dtype='<u4' if meta['dtype'] == 'U32' else '<u2', shape=tuple(meta['shape']))
indices = [0, 1, 31, 64, 1023, 31337, 127999, 248319]
w = mx.array(found['weight'][indices])
s = mx.array((found['scales'][indices].astype(np.uint32)<<16).view(np.float32)).astype(mx.bfloat16)
b = mx.array((found['biases'][indices].astype(np.uint32)<<16).view(np.float32)).astype(mx.bfloat16)
actual = np.asarray(mx.dequantize(w, s, b, group_size=64, bits=4).astype(mx.float32))
header, start = tensors(Path(record['output']))
meta = header['lm_head.weight']
raw = np.memmap(record['output'], mode='r', offset=start, dtype='<u2', shape=tuple(meta['shape']))
expected = (raw[indices].astype(np.uint32)<<16).view(np.float32)
result = {'rows': indices, 'elements': actual.size, 'different_elements': int(np.count_nonzero(actual != expected)),
          'mlx_version': mx.__version__, 'source_sha256': record['sha256']}
(r/'results/head-source-reference.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps(result))
assert result['different_elements'] == 0

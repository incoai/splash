#!/usr/bin/env python3
"""Compare the experiment's CPU affine quantizer with MLX on real BF16 draft weights."""
import json
from pathlib import Path
import struct
import subprocess
import numpy as np
import mlx.core as mx

ROOT=Path(__file__).resolve().parents[1]
SOURCE=Path('/Users/linson/Documents/ai/splash/build/dspine/checkpoint/model.safetensors')

def main():
    groups=[]
    tensors=[]
    with SOURCE.open('rb') as stream:
        size=struct.unpack('<Q',stream.read(8))[0]
        header=json.loads(stream.read(size));start=8+size
        for name,entry in sorted(header.items()):
            if name=='__metadata__' or entry['dtype']!='BF16' or len(entry['shape'])!=2 or entry['shape'][-1]%64:continue
            if 'codebook' in name:continue
            low,high=entry['data_offsets']
            count=min((high-low)//128,64)
            stream.seek(start+low)
            groups.append(np.frombuffer(stream.read(count*128),dtype='<u2').reshape(-1,64).copy())
            tensors.append(name)
    values=np.concatenate(groups)
    directory=ROOT/'results/quantizer-reference';directory.mkdir(exist_ok=True)
    fixture=directory/'groups.bf16';values.tofile(fixture)
    prefix=directory/'native'
    subprocess.run([str(ROOT/'artifacts/native-group-quantize'),str(fixture),str(prefix)],check=True)
    x=mx.array(values).view(mx.bfloat16)
    rows=[]
    passed=True
    for bits in [2,3,4,5,6,8]:
        q,s,b=mx.quantize(x,group_size=64,bits=bits)
        mx.eval(q,s,b)
        native=np.fromfile(str(prefix)+f'-{bits}.bin',dtype=np.uint8).reshape(len(values),-1)
        scale=np.array(s.view(mx.uint16)).reshape(len(values),1).view(np.uint8)
        bias=np.array(b.view(mx.uint16)).reshape(len(values),1).view(np.uint8)
        code=np.array(q).view(np.uint8).reshape(len(values),-1)
        expected=np.concatenate([scale,bias,code],axis=1)
        equal=np.all(native==expected,axis=1)
        row={'bits':bits,'groups':len(values),'exact_groups':int(equal.sum()),
             'different_bytes':int((native!=expected).sum()),'exact':bool(equal.all())}
        passed &= row['exact'];rows.append(row)
    result={'test':'CPU draft quantizer versus MLX affine reference','passed':passed,
            'source':str(SOURCE),'tensors':tensors,'results':rows}
    print(json.dumps(result))
    raise SystemExit(0 if passed else 1)

if __name__=='__main__':main()

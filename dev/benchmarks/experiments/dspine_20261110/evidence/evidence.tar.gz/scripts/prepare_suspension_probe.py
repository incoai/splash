"""Generate a local-only synthetic governor pressure probe; never changes OS pressure."""
from pathlib import Path
r=Path(__file__).resolve().parents[1]
s=(r/'scripts/study_driver.mm').read_text()
s=s.replace('#include <algorithm>','#include <algorithm>\n#include <cstdlib>')
a='using Clock = std::chrono::steady_clock;'
b='''using Clock = std::chrono::steady_clock;
// Only this process's owned governor sees synthetic pressure.
bool syntheticHostPressure = false;
MemoryGovernor *probeGovernor = nullptr;
std::function<void()> safePointProbe;
const bool forceSuspensionProbe = [] {
  const char *value = std::getenv("SPLASH_TEST_FORCE_SUSPEND");
  return value && std::string_view(value) == "1";
}();'''
assert s.count(a)==1;s=s.replace(a,b)
a='    while (!drained()) {\n';assert s.count(a)==1;s=s.replace(a,a+'      if (!engine_.commandInFlight() && safePointProbe) safePointProbe();\n')
a='    auto &config = bootstrapConfig.resources;\n';assert s.count(a)==1;s=s.replace(a,a+'''    config.hostMemory = []() -> std::optional<HostMemory> {
      return syntheticHostPressure ? std::optional<HostMemory>(HostMemory{}) : queryHostMemory();
    };
''')
a='    MemoryGovernor &governor = resources->memoryGovernor();\n';assert s.count(a)==1;s=s.replace(a,a+'    probeGovernor = &governor;\n')
a='  const auto began = Clock::now();\n  engine.submit(std::move(request));\n';assert s.count(a)==1
b='''  bool injected = false, released = false;
  uint64_t releasedIdleBytes = 0;
  Clock::time_point pressureBegan;
  const uint64_t initialSequence = events.batchSequence();
  struct ProbeReset {
    ~ProbeReset() {
      safePointProbe = {};
      syntheticHostPressure = false;
      if (probeGovernor) probeGovernor->setPressure(MemoryPressure::Normal);
    }
  } probeReset;
  if (forceSuspensionProbe) {
    safePointProbe = [&] {
      const EngineSnapshot snapshot = engine.snapshot();
      if (!injected && events.batchSequence() > initialSequence &&
          events.lastBatch().kind == WorkKind::Decode && !events.get(requestId).completed) {
        if (engine.commandInFlight()) throw std::logic_error("pressure probe crossed a command");
        injected = true;
        pressureBegan = Clock::now();
        syntheticHostPressure = true;
        probeGovernor->setPressure(MemoryPressure::Critical);
        engine.collectLandings(milliseconds(Clock::now()));
        static_cast<void>(probeGovernor->controlPass(milliseconds(Clock::now())));
        // Release only unused owned model buffers, as the critical control
        // pass may. Active buffers retain their ordinary lifetimes.
        while (const uint64_t bytes = executor.releaseIdleBuffer(false)) releasedIdleBytes += bytes;
      } else if (injected && !released) {
        if (snapshot.resourceSuspensions > engineBefore.resourceSuspensions) {
          syntheticHostPressure = false;
          probeGovernor->setPressure(MemoryPressure::Normal);
          static_cast<void>(probeGovernor->evaluate());
          engine.collectLandings(milliseconds(Clock::now()));
          static_cast<void>(probeGovernor->controlPass(milliseconds(Clock::now())));
          released = true;
        } else if (Clock::now()-pressureBegan > std::chrono::seconds(5)) {
          throw std::runtime_error("synthetic pressure caused no actual resource suspension within5s");
        }
      }
    };
  }
  const auto began = Clock::now();
  engine.submit(std::move(request));
'''
s=s.replace(a,b)
a='  const engine::EngineSnapshot engineAfter = engine.snapshot();\n';assert s.count(a)==1
s=s.replace(a,a+'''  if (forceSuspensionProbe) {
    if (!injected || !released || engineAfter.resourceSuspensions <= engineBefore.resourceSuspensions ||
        engineAfter.resourceResumptions <= engineBefore.resourceResumptions)
      throw std::runtime_error("synthetic pressure probe did not observe both suspension and resumption");
    const char *path = std::getenv("SPLASH_TEST_SUSPENSION_LOG");
    if (!path) throw std::runtime_error("pressure probe requires its own result log");
    std::ofstream log(path, std::ios::app);
    log << "{\\"scenario\\":\\"" << scenario << "\\",\\"suspensions\\":"
        << engineAfter.resourceSuspensions-engineBefore.resourceSuspensions
        << ",\\"resumptions\\":" << engineAfter.resourceResumptions-engineBefore.resourceResumptions
        << ",\\"replayed_tokens\\":" << engineAfter.resourceReplayTokens-engineBefore.resourceReplayTokens
        << ",\\"released_idle_bytes\\":" << releasedIdleBytes << "}\\n";
    if (!log) throw std::runtime_error("cannot write suspension probe receipt");
  }
''')
(r/'scripts/suspension_driver.mm').write_text(s)
print('Generated suspension_driver.mm')

"""Freeze a BF16 draft-only head source from the unchanged target's affine4 values."""
from pathlib import Path
import hashlib, json, struct, time
import numpy as np

r = Path(__file__).resolve().parents[1]
root = Path(Path('/Users/linson/Documents/ai/splash/build/dspine/model-root.txt').read_text().strip())
out = r / 'head-source'
out.mkdir(exist_ok=False)
prefix = 'language_model.lm_head.'
tensors = {}
for file in (root / 'target').glob('*.safetensors'):
    with file.open('rb') as f:
        n = struct.unpack('<Q', f.read(8))[0]
        header = json.loads(f.read(n))
    for name, item in header.items():
        if name.startswith(prefix):
            tensors[name[len(prefix):]] = (file, 8+n, item)
assert set(tensors) == {'weight', 'scales', 'biases'}
stat = {str(p): (p.stat().st_size, p.stat().st_mtime_ns) for p, _, _ in tensors.values()}
def source(name, dtype):
    file, start, meta = tensors[name]
    assert meta['dtype'] == ('U32' if name == 'weight' else 'BF16')
    return np.memmap(file, mode='r', dtype=dtype,
                     offset=start+meta['data_offsets'][0], shape=tuple(meta['shape']))
q = source('weight', '<u4'); scales = source('scales', '<u2'); biases = source('biases', '<u2')
rows, groups = scales.shape; columns = groups*64
assert q.shape == (rows, columns//8) and biases.shape == scales.shape
header = json.dumps({'lm_head.weight': {'dtype': 'BF16', 'shape': [rows, columns],
                    'data_offsets': [0, rows*columns*2]}}, separators=(',', ':')).encode()
header += b' ' * (-len(header)%8)
path = out / 'model.safetensors'
started = time.monotonic(); digest = hashlib.sha256(); shift = np.arange(8, dtype=np.uint32)*4
with path.open('xb') as f:
    prefix_bytes = struct.pack('<Q', len(header))+header
    f.write(prefix_bytes); digest.update(prefix_bytes)
    for first in range(0, rows, 128):
        last = min(first+128, rows)
        codes = ((q[first:last, :, None] >> shift) & 15).reshape(last-first, columns).astype(np.float32)
        s = (scales[first:last].astype(np.uint32)<<16).view(np.float32)
        b = (biases[first:last].astype(np.uint32)<<16).view(np.float32)
        values = codes*s.repeat(64, axis=1)+b.repeat(64, axis=1)
        assert np.isfinite(values).all()
        u = values.view(np.uint32)
        raw = ((u+0x7fff+((u>>16)&1))>>16).astype('<u2').tobytes()
        f.write(raw); digest.update(raw)
assert stat == {str(p): (p.stat().st_size, p.stat().st_mtime_ns) for p, _, _ in tensors.values()}
record = {'output': str(path), 'sha256': digest.hexdigest(), 'shape': [rows, columns],
          'source_root': str(root), 'source_stat': stat, 'elapsed_seconds': time.monotonic()-started,
          'meaning': 'Draft-only approximation source: BF16-rounded affine4 target head. No target source or target projection is replaced.'}
(r/'results/head-source.json').write_text(json.dumps(record, indent=2)+'\n')
print(json.dumps(record))

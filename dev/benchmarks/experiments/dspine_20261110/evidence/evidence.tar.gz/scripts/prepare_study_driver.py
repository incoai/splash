from pathlib import Path
r=Path(__file__).resolve().parents[1]
s=Path('/Users/linson/Documents/ai/splash/dev/benchmarks/backend_benchmark.mm').read_text()
s=s.replace('#include <fstream>','#include <fstream>\n#include <sstream>\n#include <cctype>',1)
marker='struct Measurement final {'
helper='''struct StudyCase final { std::string name; uint32_t cap; std::vector<uint32_t> tokens; };
std::vector<StudyCase> readStudy(const std::filesystem::path &path) {
  std::ifstream stream(path);
  if (!stream) throw std::runtime_error("cannot open study cohort");
  std::vector<StudyCase> cases;
  for (std::string line; std::getline(stream, line);) {
    if (line.empty() || line[0] == '#') continue;
    std::istringstream row(line);
    StudyCase c;
    uint64_t cap, token;
    if (!(row >> c.name >> cap) || !cap || cap > 8192 ||
        !std::all_of(c.name.begin(), c.name.end(), [](unsigned char v) { return std::isalnum(v) || v == '_'; }))
      throw std::runtime_error("invalid cohort name/cap");
    c.cap = static_cast<uint32_t>(cap);
    while (row >> token) {
      if (token > UINT32_MAX) throw std::runtime_error("cohort token overflow");
      c.tokens.push_back(static_cast<uint32_t>(token));
    }
    if (!row.eof() || c.tokens.empty()) throw std::runtime_error("invalid cohort token list");
    cases.push_back(std::move(c));
  }
  if (cases.empty()) throw std::runtime_error("empty cohort");
  return cases;
}

'''
s=s.replace(marker,helper+marker,1)
s=s.replace('uint32_t maxNewTokens = 1, bool traceDrafts = false) {','uint32_t maxNewTokens = 1, bool traceDrafts = false, const SamplingParameters *policy = nullptr) {',1)
s=s.replace('  request.sampling.topP = 1.0F;','  request.sampling.topP = 1.0F;\n  if (policy) request.sampling = *policy;',1)
s=s.replace('  bool acceptance = false;','  bool acceptance = false;\n  bool study = false;',1)
s=s.replace('BenchmarkScenarios selected{false, false, false, false, false, false, false, false, false};','BenchmarkScenarios selected{false, false, false, false, false, false, false, false, false, false};',1)
s=s.replace(': name == "acceptance"  ? &selected.acceptance',': name == "acceptance"  ? &selected.acceptance\n                     : name == "study"       ? &selected.study',1)
s=s.replace('    bool logitsOptions = false;','    bool logitsOptions = false;\n    std::optional<std::filesystem::path> cohort;\n    float studyTemperature = 0;\n    uint64_t seedBase = 20261110;',1)
s=s.replace('      } else if (option == "--progress") {','''      } else if (option == "--cohort") {
        cohort = std::filesystem::path(argv[index + 1]);
      } else if (option == "--temperature") {
        size_t used = 0;
        const std::string value(argv[index + 1]);
        studyTemperature = std::stof(value, &used);
        if (used != value.size() || !std::isfinite(studyTemperature) || studyTemperature < 0)
          throw std::invalid_argument("invalid study temperature");
      } else if (option == "--seed-base") {
        size_t used = 0;
        const std::string value(argv[index + 1]);
        seedBase = std::stoull(value, &used);
        if (used != value.size() || seedBase > UINT64_MAX - samples)
          throw std::invalid_argument("invalid study seed base");
      } else if (option == "--progress") {''',1)
s=s.replace('    if (selected.logits != logitsDirectory.has_value())','    if (cohort) selected = parseScenarios("study");\n    if (selected.logits != logitsDirectory.has_value())',1)
marker='    // The full-vocabulary logits after prefixes of greedy transcripts of the'
block='''    if (selected.study) {
      if (!cohort) throw std::invalid_argument("study requires --cohort");
      const auto cases = readStudy(*cohort);
      for (uint32_t sample = 0; sample < samples; ++sample) {
        SamplingParameters policy;
        policy.temperature = studyTemperature;
        policy.topP = studyTemperature > 0 ? 0.95f : 1.0f;
        policy.topK = studyTemperature > 0 ? 20 : 0;
        policy.seed = seedBase + sample;
        if (const auto error = policy.validationError()) throw std::invalid_argument(std::string(*error));
        for (const auto &c : cases) {
          evictAllCache(resources->cache());
          measurements.push_back(runRequest(engine, driver, *executor, events, progress.get(), requestId++,
              c.name, sample, c.tokens, c.cap, true, &policy));
        }
      }
    }

'''
assert marker in s;s=s.replace(marker,block+marker,1)
s=s.replace('std::cout << "{\\"schema_version\\":2,\\"build_id\\":\\""', 'std::cout << "{\\"study_temperature\\":" << studyTemperature << ",\\"study_seed_base\\":" << seedBase << ",\\"schema_version\\":2,\\"build_id\\":\\""',1)
# More than 100 seeds are meaningful for the dedicated distribution study.
s=s.replace('if (parsed > 100)','if (parsed > 2000)').replace('samples must not exceed 100','samples must not exceed 2000')
(r/'scripts/study_driver.mm').write_text(s)
print('Wrote generic frozen-cohort native driver')

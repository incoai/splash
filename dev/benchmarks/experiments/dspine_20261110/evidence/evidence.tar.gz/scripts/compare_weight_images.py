from pathlib import Path
import json, sys
a, b, scope = sys.argv[1:]
def read(p):
    return {v['component']: (v['bytes'], v['sha256']) for v in json.loads(Path(p).read_text())
            if scope == 'all' or v['component'].startswith(scope+'/')}
aa, bb = read(a), read(b)
print(json.dumps({'scope': scope, 'baseline_images': len(aa), 'candidate_images': len(bb),
                  'identical': aa == bb, 'different': [k for k in aa.keys()|bb.keys() if aa.get(k) != bb.get(k)]}))
assert aa == bb and aa

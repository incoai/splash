#include "TranscriptPrompts.hpp"
#include <iostream>
int main() { for (auto token : splash::benchmark::kDraftComparisonPrompts[1]) std::cout << token << ' '; }

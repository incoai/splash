"""Describe raw teacher-forced batch-width differences, without a speed/quality verdict."""
import os
os.environ["VECLIB_MAXIMUM_THREADS"] = "1"
os.environ["OPENBLAS_NUM_THREADS"] = "1"
os.environ["OMP_NUM_THREADS"] = "1"
from pathlib import Path
import hashlib
import json
import numpy as np

r = Path(__file__).resolve().parents[1]
vocabulary = 248320
widths = {}
files = {}
for width in range(1, 5):
    arrays = []
    for lane in range(width):
        p = r / f"features/batch-logits-v1-w{width}-lane{lane}.f32"
        arrays.append(np.fromfile(p, dtype="<f4").reshape(17, vocabulary))
        files[str(p.relative_to(r))] = {"bytes": p.stat().st_size, "sha256": hashlib.sha256(p.read_bytes()).hexdigest()}
    assert all(np.isfinite(a).all() for a in arrays)
    widths[width] = arrays

def metrics(a, b):
    af, bf = a.astype(np.float64), b.astype(np.float64)
    delta = af - bf
    return {"exact_fraction": float(np.mean(a == b)), "max_absolute_error": float(np.abs(delta).max()),
            "relative_rmse": float(np.sqrt(np.mean(delta * delta) / np.mean(bf * bf))),
            "argmax_agreement_rows": int(np.sum(a.argmax(axis=1) == b.argmax(axis=1))),
            "differing_argmax_rows_zero_based": np.flatnonzero(a.argmax(axis=1) != b.argmax(axis=1)).tolist()}

records = []
for width, arrays in widths.items():
    a = arrays[0]
    selected = []
    for row in range(17):
        ids = np.argsort(a[row])[-2:][::-1]
        selected.append({"row": row, "prediction_output_index": 175 + row,
                         "top2_ids": ids.tolist(), "top2_logits": a[row, ids].astype(float).tolist(),
                         "margin": float(a[row, ids[0]] - a[row, ids[1]])})
    records.append({"width": width, "lane0_vs_width1": metrics(a, widths[1][0]),
                    "other_lanes_vs_lane0": [metrics(b, a) for b in arrays[1:]], "top2_by_row": selected})
record = {"protocol": json.loads((r / "notes/batch-logits-protocol.json").read_text()),
          "records": records, "raw_files": files,
          "scope": "Raw target logits captured before policy rewrites, same forced inputs and individual cold prefill per lane. One fixed continuation, no performance or human-quality verdict. Prefill recomputes preceding GDN state; these are not the exact original natural-decode states."}
(r / "results/batch-target-logit-comparison.json").write_text(json.dumps(record, indent=2) + "\n")
for row in records:
    print(json.dumps({"width": row["width"], "comparison": row["lane0_vs_width1"],
                      "observed_disagreement_position": row["top2_by_row"][14]}))

"""After all timed groups, test the narrow Table16 packing repair only."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess

root = Path(__file__).resolve().parents[1]
tree = root / 'table16-layout-followup'
bundle = root / 'artifacts/table16-layout-followup-v1'
patch = root / 'publication/experiments/dspine_20261110/patches/wide-policy.patch'
assert not tree.exists() and not bundle.exists(), 'Fresh owned paths required'
subprocess.run(['git', '-C', '/Users/linson/Documents/ai/splash', 'worktree', 'add', '--detach', str(tree), '33a488d4bbb3978b32b34e8bfc6cefa92e350d7f'], check=True)
subprocess.run(['git', '-C', str(tree), 'apply', str(patch)], check=True)

def replace(relative, old, new):
    p = tree / relative
    data = p.read_text()
    assert data.count(old) == 1, relative
    p.write_text(data.replace(old, new))

replace('runtime/ops/Linear.cpp', 'rows / SPLASH_TARGET_VERIFY_ROWS * table16_sums_per_tile(width)', 'rows / 8 * table16_sums_per_tile(width)')
replace('runtime/metal/kernels/decode/gdn.metal',
'''      Table::write(table + ulong(batch) * ValueWidth * Rows,
                   sums + ulong(batch) * Table::sums_per_tile(ValueWidth), ValueWidth,
                   column / 64, simd_group, lane, shared.rows[local], shared.rows[local + 1]);''',
'''      // Table16 packs eight rows independently of the request verify width.
      const uint table_row = batch * Rows + simd_group;
      const uint table_tile = table_row / gguf_sg::kRows;
      Table::write(table + ulong(table_tile) * ValueWidth * gguf_sg::kRows,
                   sums + ulong(table_tile) * Table::sums_per_tile(ValueWidth), ValueWidth,
                   column / 64, table_row % gguf_sg::kRows, lane, shared.rows[local], shared.rows[local + 1]);''')
replace('dev/tests/engine/LinearInputReference.hpp', '{width / 32, lanes, 1}', '{width / 32, lanes * SPLASH_TARGET_VERIFY_ROWS / 8, 1}')
subprocess.run(['git', '-C', str(tree), 'diff', '--check'], check=True)
full_patch = subprocess.check_output(['git', '-C', str(tree), 'diff', '--binary'])
(root / 'patches/table16-layout-followup.patch').write_bytes(full_patch)
bundle.mkdir()
command = ['make', '-C', str(tree), '-j6', 'all', 'build/engine-tests/gdn-decode']
subprocess.run(command, check=True)
for source, name in [(tree/'build/engine-tests/gdn-decode','gdn-decode'), (tree/'build/splash.metallib','splash.metallib'), (tree/'build/host-step.metallib','host-step.metallib')]:
    shutil.copy2(source, bundle/name)
record = {'base':'33a488d4bbb3978b32b34e8bfc6cefa92e350d7f', 'command':command,
          'patch_sha256':hashlib.sha256(full_patch).hexdigest(),
          'artifacts':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in bundle.iterdir()},
          'scope':'Packing-only follow-up to observed Table16 failure. Register selection remains disabled. Full sixteen-row GDN suite is run separately under shader validation; no throughput or production-readiness claim.'}
(bundle/'build.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))

"""Reuse typed shared arrays across pending commit/current scan, FP32 state only."""
from pathlib import Path
import hashlib,json
r=Path(__file__).resolve().parents[1]
for name,base in [('gdn-phased8','m16-policy'),('gdn-phased16','wide-policy')]:
 source=r/base/'runtime/metal/kernels/decode/gdn.metal';dest=r/name/'runtime/metal/kernels/decode/gdn.metal';s=source.read_text()
 def function(name,end):
  middle=s.index('inline void '+name+'(')
  return s[s.rfind('template <',0,middle):s.index(end,middle)]
 prologue=function('gdn_decode_prologue','// Delta-rule recurrence');original_scan=function('gdn_decode_scan','// Gated RMSNorm');gate=function('gdn_decode_gate','// Grid {value heads, lanes}.');phase=function('gdn_decode_batch_phase','// W: the norm weights')
 prologue=prologue.replace('gdn_decode_prologue','gdn_decode_prologue_phased').replace('GdnDecodeShared<HeadDim>','GdnPhasedShared<HeadDim>')
 a=prologue.index('  if (token < pending) {');b=prologue.index('  float q[Groups], k[Groups];',a);prologue=prologue[:a]+'  (void)pending_tape; (void)pending;\n\n'+prologue[b:]
 a='    shared.beta[token] = gates.beta;\n    shared.decay[token] = gates.decay;\n';assert a in prologue;prologue=prologue.replace(a,'')
 def common_scan(text,name):
  text=text.replace('gdn_decode_scan',name).replace('GdnDecodeShared<HeadDim>','GdnPhasedShared<HeadDim>')
  text=text.replace('template <uint HeadDim, uint RowsInFlight, class State>','template <uint ValueHeads, uint HeadDim, uint RowsInFlight>')
  text=text.replace('device const State *state_in','device const float *state_in').replace('device State *state_out','device float *state_out').replace('State(state[r][i])','state[r][i]')
  return text
 commit=common_scan(original_scan,'gdn_decode_commit_phased')
 commit=commit.replace('threadgroup GdnPhasedShared<HeadDim> &shared,\n                            uint pending','threadgroup GdnPhasedShared<HeadDim> &shared,\n                            GdnTape pending_tape, uint pending')
 commit=commit.replace('  constexpr uint Tokens = SPLASH_TARGET_VERIFY_ROWS;\n','')
 commit=commit.replace('shared.pending_keys','shared.queries').replace('shared.pending_values','shared.keys').replace('shared.pending_decay[token]','pending_tape.decay[token * ValueHeads + value_head]').replace('shared.pending_beta[token]','pending_tape.beta[token * ValueHeads + value_head]')
 a=commit.index('    for (uint token = 0; token < Tokens; ++token) {');b=commit.index('    for (uint r = 0; r < RowsInFlight; ++r)\n      for (uint i = 0; i < 4; ++i)\n        state[r][i] = upcoming[r][i];',a);commit=commit[:a]+commit[b:]
 current=common_scan(original_scan,'gdn_decode_current_phased')
 current=current.replace('                            device float *state_out,\n','')
 current=current.replace('                            uint pending, uint value_head, uint lane,','                            GdnTape step_tape, uint value_head, uint lane,')
 a=current.index('    for (uint token = 0; token < pending; ++token) {');b=current.index('    float upcoming[RowsInFlight][4] = {};',a);current=current[:a]+current[b:]
 a='    for (uint r = 0; r < RowsInFlight; ++r)\n      for (uint i = 0; i < 4; ++i)\n        state_out[base(batch, r) + i] = state[r][i];\n';assert a in current;current=current.replace(a,'')
 current=current.replace('shared.decay[token]','step_tape.decay[token * ValueHeads + value_head]').replace('shared.beta[token]','step_tape.beta[token * ValueHeads + value_head]')
 gate=gate.replace('gdn_decode_gate','gdn_decode_gate_phased').replace('GdnDecodeShared<HeadDim>','GdnPhasedShared<HeadDim>')
 phase=phase.replace('gdn_decode_batch_phase','gdn_decode_batch_phase_phased').replace('GdnDecodeShared<HeadDim>','GdnPhasedShared<HeadDim>').replace('class Table, class W, class State','class W, class State')
 a='    threadgroup GdnPhasedShared<HeadDim> &shared,\n    device bfloat *table, device float *sums) {';assert a in phase;phase=phase.replace(a,'    threadgroup GdnPhasedShared<HeadDim> &shared) {\n  static_assert(sizeof(State) == 4, "phased scan requires FP32 state");')
 a=phase.index('  gdn_decode_prologue<');b=phase.index('  const bool tiled',a)
 phase=phase[:a]+'''  // Phase1: arrays queries/keys temporarily hold pending keys/values.
  gdn_load_pending_phased<KeyHeads, ValueHeads, HeadDim>(
      pending_tape, pending, shared, group.x, lane, simd_group);
  threadgroup_barrier(mem_flags::mem_threadgroup);
  gdn_decode_commit_phased<ValueHeads, HeadDim, RowsInFlight>(
      state_in, state_out, shared, pending_tape, pending, group.x, lane, simd_group);
  // All pending reads finish before their arrays become current Q/K.
  threadgroup_barrier(mem_flags::mem_threadgroup | mem_flags::mem_device);
  gdn_decode_prologue_phased<KeyHeads, ValueHeads, HeadDim, ConvDim, PackedWidth>(
      packed, conv_weights, history, conv_state_out, pending_tape, pending,
      step_tape, a_scale, dt_bias, shared, group.x, lane, simd_group);
  threadgroup_barrier(mem_flags::mem_threadgroup | mem_flags::mem_device);
  // FP32 store/reload preserves the exact committed state values. BF16
  // state retains the legacy kernel because reloading it would round here.
  gdn_decode_current_phased<ValueHeads, HeadDim, RowsInFlight>(
      state_out, shared, step_tape, group.x, lane, simd_group);
  threadgroup_barrier(mem_flags::mem_threadgroup);
'''+phase[b:]
 phase=phase.replace('gdn_decode_gate<','gdn_decode_gate_phased<');a=phase.index('  if (table) {');phase=phase[:a]+'}\n\n'
 shared='''// Research: peak shared lifetime is current Q/K/V/output, not the sum
// of pending and current vectors. Phase1 uses queries/keys as pending K/V;
// the whole threadgroup finishes the commit before Phase2 overwrites them.
template <uint HeadDim> struct GdnPhasedShared {
  bfloat queries[SPLASH_TARGET_VERIFY_ROWS * HeadDim];
  bfloat keys[SPLASH_TARGET_VERIFY_ROWS * HeadDim];
  bfloat values[SPLASH_TARGET_VERIFY_ROWS * HeadDim];
  bfloat rows[SPLASH_TARGET_VERIFY_ROWS * HeadDim];
};
template <uint KeyHeads, uint ValueHeads, uint HeadDim>
inline void gdn_load_pending_phased(GdnTape tape, uint pending,
    threadgroup GdnPhasedShared<HeadDim> &shared, uint head, uint lane, uint token) {
  constexpr uint KvWidth = (KeyHeads + ValueHeads) * HeadDim;
  const uint key = head / (ValueHeads / KeyHeads) * HeadDim;
  const uint value = KeyHeads * HeadDim + head * HeadDim;
  if (token < pending) for (uint g = 0; g < HeadDim / 32; ++g) {
    const uint dim = 32 * g + lane;
    shared.queries[token * HeadDim + dim] = tape.kv[token * KvWidth + key + dim];
    shared.keys[token * HeadDim + dim] = tape.kv[token * KvWidth + value + dim];
  }
}

'''
 block=shared+prologue+commit+current+gate+phase
 assert 'shared.pending_' not in block
 assert 'state_out' not in current
 s=s.replace('constant uint kDecodeSimdgroups = 8;','constant uint kDecodeSimdgroups = SPLASH_TARGET_VERIFY_ROWS;');a=s.index('// W: the norm weights');s=s[:a]+block+s[a:]
 a='GDN_DECODE_ENTRY(verify_gdn_fused, 16, 48, 128, 10240, 16640, bfloat)';assert s.count(a)==1
 entry='''GDN_DECODE_KERNEL(verify_gdn_fused_legacy, 16, 48, 128, 10240, 16640, bfloat, float)
GDN_DECODE_KERNEL(verify_gdn_fused_bf16_state, 16, 48, 128, 10240, 16640, bfloat, bfloat)
kernel void verify_gdn_fused(GDN_DECODE_BUFFERS(bfloat),
    constant GDNDecodeBatchParams &params [[buffer(15)]], GDN_DECODE_THREADS) {
  threadgroup GdnPhasedShared<128> shared;
  gdn_decode_batch_phase_phased<16, 48, 128, 10240, 16640, 2, bfloat, float>(
      packed, conv_weights, current0, current1, current2, current3,
      next0, next1, next2, next3, tape, a_scale, dt_bias,
      gdn_norm_weight, gdn_hidden, params, group, lane, simd_group, shared);
}'''
 s=s.replace(a,entry);dest.write_text(s)
 print(json.dumps({'variant':name,'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'candidate_sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'shared_bytes':8192 if name.endswith('8') else 16384}))

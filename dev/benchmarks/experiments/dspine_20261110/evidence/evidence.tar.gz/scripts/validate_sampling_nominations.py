"""Open the internal sampling barrier only for fully frozen, pre-data nominations."""
from pathlib import Path
import datetime as dt
import hashlib
import json

r = Path(__file__).resolve().parents[1]
nomination_path = r / "notes/sampling-nominations.json"
nomination = json.loads(nomination_path.read_text())
jobs = {j["id"]: j for j in map(json.loads, (r / "queue.jsonl").read_text().splitlines())}
observations = []
assert 1 <= len(nomination["candidates"]) <= 2
for arm in [nomination["control"], *nomination["candidates"]]:
    assert len(arm["jobs"]) == 3
    candidate = arm in nomination["candidates"]
    for chunk, ident in enumerate(arm["jobs"]):
        job = jobs[ident]
        command = job["command"]
        assert command[command.index("--seed-base") + 1] == str(arm["seed_start"] + chunk * 500)
        assert command[command.index("--samples") + 1] == "500"
        assert command[command.index("--temperature") + 1] == "1"
        assert job.get("env", {}) == arm.get("runtime_env", {})
        if candidate:
            assert not (r / "results" / f"{ident}.receipt.json").exists()
            assert not (r / "results" / f"{ident}.stdout").exists()
            assert not (r / "results" / f"{ident}.progress.jsonl").exists()
            assert "sampling-nominations-ready-v2" in job["requires"]
            for path, expected in arm["artifact_sha256"].items():
                actual = hashlib.sha256(Path(path).read_bytes()).hexdigest()
                assert actual == expected, (ident, path, "artifact changed")
                assert job["expected_sha256"][path] == expected
            patch = Path(arm["source_patch_path"])
            assert hashlib.sha256(patch.read_bytes()).hexdigest() == arm["source_patch_sha256"]
        else:
            receipt = json.loads((r / "results" / f"{ident}.receipt.json").read_text())
            assert receipt["state"] == "complete" and receipt["exit_code"] == 0
    observations.append({"name": arm["name"], "candidate": candidate, "jobs": arm["jobs"]})
record = {
    "utc": dt.datetime.now(dt.timezone.utc).isoformat(),
    "nomination_sha256": hashlib.sha256(nomination_path.read_bytes()).hexdigest(),
    "validated": observations,
    "candidate_dataset_outputs_started": False,
    "scope": "Freeze source, binary, shader, cohort, seeds and runtime settings before candidate distribution data. Baseline receipt status only was checked here; no nomination uses positive-temperature outputs.",
}
(r / "results/sampling-nomination-validation.json").write_text(json.dumps(record, indent=2) + "\n")
print(json.dumps(record, indent=2))
